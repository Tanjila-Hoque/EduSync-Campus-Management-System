# EduSync Student Success Radar — Setup and Verification

## What changed
- Removed SMTP/email delivery, its API controller, service, configuration, setup prompts, and People-page test-email UI.
- Posting a campus notice now creates in-app notifications for the intended audience.
- Added `GET /api/student-success/radar` with explainable attendance and coursework signals, a Gemini-based student study plan, and a rule-based fallback.
- Added `POST /api/student-success/notify` for Admin/Teacher to create deduplicated daily support notifications.
- Added a JWT-protected notification center with unread counts, mark-read actions, mark-all-read, and pagination.
- Added the radar to the dashboard and navigation without replacing existing pages.

## Setup (Windows PowerShell)
1. Extract the ZIP to a folder you control.
2. Configure PostgreSQL connection string and JWT signing key in local configuration/User Secrets. Do not commit production secrets.
3. From `StudentManagement`, run:
   ```powershell
   dotnet restore
   .\SETUP_LOCAL_SECRETS.ps1
   dotnet build
   dotnet run
   ```
   The script asks for a Gemini API key using hidden input and stores it in .NET User Secrets. Model default: `gemini-3.5-flash-lite`.
4. In a second terminal:
   ```powershell
   cd ClientApp
   npm install
   npm run dev
   ```
5. Sign in using an existing EduSync account. Existing database records and authentication are retained. `SchemaPatcher` adds the notification table/index at backend startup without dropping existing tables or records.

## Verification checklist
- Sign in separately as Admin, Teacher, Student and Staff.
- Admin/Teacher/Student can open Student Success Radar; Staff is denied by API and UI route policy.
- Student sees only their own radar/study plan. Teacher sees only students enrolled in their taught classes. Admin sees active students.
- Check missing-data messages when attendance sessions or result records do not exist.
- Publish a notice and confirm audience members see it in `/notifications`.
- As Admin/Teacher, run **Notify at-risk students**; verify new support notifications and confirm a second run on the same day does not duplicate the same alert.
- Test notification pagination, unread count, mark one read and mark all read.
- Confirm existing login, refresh-token behavior, classes, attendance/QR, results, routine, notices, people management and audit log still work.

## Risk logic
- Attendance below 75% adds 45 risk points; attendance from 75% to below 85% adds 20.
- Available coursework average below 40% adds 45 points; average from 40% to below 60% adds 25.
- Score >=45 is **At risk**, >=20 is **Needs attention**, otherwise **On track**.
- Reasons are returned alongside every score. Missing attendance/results are explicitly called out and are not treated as zero academic performance.
- The signals are early-warning heuristics, not diagnoses or guaranteed predictions. Review the underlying records before acting.

## API contracts
- `GET /api/student-success/radar`
- `POST /api/student-success/notify` (Admin/Teacher)
- `GET /api/notifications?page=1&pageSize=10`
- `POST /api/notifications/{id}/read`
- `POST /api/notifications/read-all`

All endpoints require the existing JWT authentication. Notification reads/updates are scoped to the signed-in user's own notification records.
