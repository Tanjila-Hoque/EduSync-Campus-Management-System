using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using StudentManagement.Data;
using StudentManagement.Models;
using StudentManagement.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

// ------------------------------------------------------------------
// PostgreSQL
// ------------------------------------------------------------------
builder.Services.AddDbContext<AppDbContext>(o =>
    o.UseNpgsql(builder.Configuration.GetConnectionString("Default")));

builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IAuditLogger, AuditLogger>();
builder.Services.AddScoped<CampusDataService>();
builder.Services.AddScoped<CampusContextService>();
builder.Services.AddScoped<CampusToolService>();
builder.Services.AddHttpClient<GeminiService>();
builder.Services.AddSingleton<IJwtService, JwtService>();
builder.Services.AddSingleton<QrService>();

// ------------------------------------------------------------------
// CUSTOM AUTHENTICATION  (our own Users table + hand-issued JWT, no ASP.NET Identity,
// no external identity provider). The React app sends the token back as
// "Authorization: Bearer <token>" on every request.
// ------------------------------------------------------------------
var jwtSection = builder.Configuration.GetSection("Jwt");
var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSection["Key"]!));

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwtSection["Issuer"],
            ValidateAudience = true,
            ValidAudience = jwtSection["Audience"],
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = signingKey,
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromSeconds(30)
        };

        // Every request: is this user still active and is the role still the one in the
        // token? If an admin disables a user or changes a role, old tokens stop working
        // as soon as they are checked (they still expire naturally at worst within
        // AccessTokenMinutes, same safety net the old cookie version had).
        options.Events = new JwtBearerEvents
        {
            OnTokenValidated = async ctx =>
            {
                var idText = ctx.Principal?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
                var role = ctx.Principal?.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;

                if (!int.TryParse(idText, out var id))
                {
                    ctx.Fail("Invalid token.");
                    return;
                }

                var db = ctx.HttpContext.RequestServices.GetRequiredService<AppDbContext>();
                var current = await db.Users.AsNoTracking()
                    .Where(u => u.Id == id)
                    .Select(u => new { u.IsActive, u.Role })
                    .FirstOrDefaultAsync();

                if (current == null || !current.IsActive || current.Role != role)
                    ctx.Fail("Account disabled or role changed.");
            }
        };
    });

// ------------------------------------------------------------------
// CUSTOM AUTHORIZATION  (role based policies)
// ------------------------------------------------------------------
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy(Policies.AdminOnly, p => p.RequireRole(Roles.Admin));
    options.AddPolicy(Policies.StaffOrAdmin, p => p.RequireRole(Roles.Admin, Roles.Staff));
    options.AddPolicy(Policies.TeacherStaffAdmin, p => p.RequireRole(Roles.Admin, Roles.Staff, Roles.Teacher));
    options.AddPolicy(Policies.TeacherOrAdmin, p => p.RequireRole(Roles.Admin, Roles.Teacher));
});

// ------------------------------------------------------------------
// CORS - allow the React dev server / production origin to call this API
// ------------------------------------------------------------------
// BUG FIX: vite.config.js's basicSsl() plugin serves the dev frontend over
// https://localhost:5173 (needed for camera access on a phone), but
// appsettings.json's Cors:AllowedOrigins only listed "http://localhost:5173".
// The browser's real Origin header (https://...) never matched, so CORS silently
// blocked EVERY request - including login and signup, not just attendance.
var allowedOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? Array.Empty<string>();
builder.Services.AddCors(options =>
{
    options.AddPolicy("Frontend", policy =>
    {
        if (builder.Environment.IsDevelopment())
        {
            // Dev convenience: accept the Vite dev server on http OR https, on
            // localhost OR any LAN IP/port (e.g. a phone hitting the PC's IP to test
            // the camera QR scanner) without having to keep editing an allow-list.
            // Safe to be this permissive here because no cookies/credentials are used -
            // the JWT goes in the Authorization header, not a cookie.
            policy.SetIsOriginAllowed(_ => true).AllowAnyHeader().AllowAnyMethod();
        }
        else
        {
            policy.WithOrigins(allowedOrigins).AllowAnyHeader().AllowAnyMethod();
        }
    });
});

var app = builder.Build();

// create the PostgreSQL tables (if they don't exist yet) + seed demo users on startup.
// For a real project, switch this to proper EF Core migrations
// (dotnet ef migrations add InitialCreate / dotnet ef database update) - see README.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();
    // EnsureCreated does nothing when the database already has tables, so tables added in
    // newer builds (AuditLogs, Notices, AttendanceSessions, UsedQrTokens...) would be missing
    // and their endpoints would return 500. This creates whatever is missing - see SchemaPatcher.
    SchemaPatcher.Apply(db, scope.ServiceProvider.GetRequiredService<ILoggerFactory>().CreateLogger("SchemaPatcher"));
    DbSeeder.Seed(db);
}

app.UseStaticFiles(); // serves wwwroot: the built React app + wwwroot/uploads/photos/*
app.UseRouting();
app.UseCors("Frontend");
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

// SPA fallback: any route that isn't an API call or an existing static file
// (e.g. a React Router path like "/dashboard" hit with a hard refresh) is served
// index.html so React Router can take over client-side.
app.MapFallbackToFile("index.html");

app.Run();
