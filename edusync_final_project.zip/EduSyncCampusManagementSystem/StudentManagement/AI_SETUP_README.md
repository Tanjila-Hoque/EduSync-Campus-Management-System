# Gemini AI Integration

Added: Notice Generator (`POST /api/ai/notice`, Admin/Teacher) and role-scoped Campus Chatbot (`POST /api/ai/chat`, authenticated users).

## Setup (Windows CMD)

From the folder containing `StudentManagement.csproj`, run the secure setup script in PowerShell:

```powershell
.\SETUP_LOCAL_SECRETS.ps1
```

It stores both the Gmail App Password and Gemini API key in .NET User Secrets with hidden input. Generate new credentials first; never use the secrets that were included in an earlier ZIP or message. Then run `dotnet restore` and `dotnet run`.

In another terminal:

```cmd
cd ClientApp
npm install
npm run dev
```

Log in, open **AI Assistant** from the sidebar. Admin/Teacher can draft notices; use **Use in Notice Composer** to review/publish with the existing permissions. All authenticated roles can ask the chatbot, but database context is restricted by server-side JWT identity.

## What the chatbot can do (v4)
- **General & study questions** - explains topics, solves problems, writes study plans, exam tips, programming/math/science help, everyday questions. Never replies "unavailable" for these.
- **Your own campus data** (always loaded, role-scoped): profile, enrolled classes, real attendance % per class (same maths as the Insights page, incl. "can miss N more" / "must attend N in a row"), results with attendance marks + grade, today's classes, weekly routine, notices you may see.
- **Lookups on demand (Gemini function calling)** - the model calls read-only server tools:
  - Student: routine filters, older notices, list/browse classes.
  - Teacher: find students on *their own* rosters, student report (attendance + results), class summary, class attendance on a date, class results, at-risk (<75%) students.
  - Admin: all of the above for any class/student + people directory, campus stats, teacher/staff daily attendance, recent audit activity.
  - Staff: routine and notices.
- **Mixed questions** - e.g. "make me a study plan" uses your real routine and weakest course; "how much do I need in final for an A?" uses the campus grading scale (total out of 110).
- Chat remembers the last 10 messages, answers in the language you write (Bangla / English / Banglish), renders Markdown (lists, tables, code).

## Security model
- User id and role come only from the verified JWT - never from the browser or from the AI.
- Every tool re-checks role and ownership on the server (a teacher can only reach their own classes/students). Out-of-scope requests return an error and the bot explains it.
- Read-only: no tool writes data, accepts SQL, or returns password hashes / QR tokens.
- Notices and routine use the same visibility rules as the Notices and Routine pages.

## Limitations
- Gemini model defaults to `gemini-3.8-flash`; if this model returns 404, the backend discovers available text Flash/Flash-Lite models for that key. Free-tier quota limits may show "AI is busy".
- Attendance % counts a class as "held" on every day a session was opened or a record exists (same as the Insights page).
- Teacher results/attendance lookups are limited to students enrolled in that teacher's own active classes.
- AI answers can be wrong - verify important marks/dates in the app. Notice drafts stay in browser session storage until taken to the Notice composer.
- Check Google's current model list at https://ai.google.dev/gemini-api/docs/models. The default is `gemini-3.8-flash`; availability still depends on the API key/project and quota.
- No database migrations required. No API key included. After pulling this version run `npm install` in `ClientApp` (new deps: `react-markdown`, `remark-gfm`).
