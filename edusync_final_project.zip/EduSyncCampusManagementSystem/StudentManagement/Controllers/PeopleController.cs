using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using StudentManagement.Data;
using StudentManagement.Dtos;
using StudentManagement.Models;
using StudentManagement.Services;

namespace StudentManagement.Controllers;

/// <summary>
/// Access rule (by explicit requirement): Staff can NEVER see Teacher/Student personal
/// details here - not list, not detail, not photo, nothing. Only Admin manages accounts.
/// Teacher gets read-only access, and only to Students (e.g. to look someone up before
/// entering a result) - never to other Teachers/Staff/Admin accounts.
/// </summary>
[ApiController]
[Route("api/people")]
[Authorize]
public class PeopleController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IAuditLogger _audit;
    public PeopleController(AppDbContext db, IAuditLogger audit) { _db = db; _audit = audit; }

    private static PersonDto ToDto(User u) => new()
    {
        Id = u.Id,
        FullName = u.FullName,
        Username = u.Username,
        Email = u.Email,
        Phone = u.Phone,
        Role = u.Role,
        IdNumber = u.IdNumber,
        Department = u.Department,
        PhotoPath = u.PhotoPath,
        IsActive = u.IsActive,
        CreatedAt = u.CreatedAt
    };

    /// <summary>Admin: any role. Teacher: Students only. Staff/Student: forbidden.</summary>
    private ActionResult? CheckViewAllowed(string queriedRole)
    {
        var callerRole = User.GetRole();
        if (callerRole == Roles.Admin) return null;
        if (callerRole == Roles.Teacher && queriedRole == Roles.Student) return null;
        return Forbid();
    }

    [HttpGet]
    public async Task<ActionResult<List<PersonDto>>> Index([FromQuery] string role = Roles.Student, [FromQuery] string? q = null)
    {
        var denied = CheckViewAllowed(role);
        if (denied != null) return denied;

        var query = _db.Users.Where(u => u.Role == role);

        // Teachers only see students assigned to one of their own classes. This keeps the
        // People screen focused on their actual teaching roster instead of exposing every student.
        if (User.GetRole() == Roles.Teacher && role == Roles.Student)
        {
            var teacherId = User.GetUserId();
            query = query.Where(u => _db.ClassEnrollments.Any(e => e.StudentId == u.Id && e.Class.TeacherId == teacherId && e.Class.IsActive));
        }

        if (!string.IsNullOrWhiteSpace(q))
            query = query.Where(u => u.FullName.Contains(q) || u.Username.Contains(q) || (u.IdNumber != null && u.IdNumber.Contains(q)));

        // Optional server-side DataTable paging. Legacy callers that omit page/pageSize
        // continue to receive the complete list (e.g. dropdowns in the Classes screen).
        if (Request.Query.ContainsKey("page") || Request.Query.ContainsKey("pageSize"))
        {
            var page = Math.Max(1, int.TryParse(Request.Query["page"], out var p) ? p : 1);
            var pageSize = Math.Clamp(int.TryParse(Request.Query["pageSize"], out var ps) ? ps : 10, 5, 100);
            var totalCount = await query.CountAsync();
            var items = await query.OrderBy(u => u.FullName).ThenBy(u => u.Id)
                .Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
            return Ok(new { items = items.Select(ToDto), page, pageSize, totalCount,
                totalPages = (int)Math.Ceiling(totalCount / (double)pageSize) });
        }

        var allItems = await query.OrderBy(u => u.FullName).ToListAsync();
        return Ok(allItems.Select(ToDto));
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<PersonDto>> Get(int id)
    {
        var user = await _db.Users.FindAsync(id);
        if (user == null) return NotFound();

        var denied = CheckViewAllowed(user.Role);
        if (denied != null) return denied;

        return Ok(ToDto(user));
    }

    /// <summary>Account management (create/update/delete/photo/QR) is Admin-only.</summary>
    [HttpPost, Authorize(Policy = Policies.AdminOnly)]
    public async Task<ActionResult<PersonDto>> Create(PersonCreateDto dto)
    {
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var username = dto.Username.Trim();
        var fullName = dto.FullName.Trim();
        var password = dto.Password; // no restrictions on admin-set passwords

        if (!new[] { Roles.Teacher, Roles.Staff, Roles.Student, Roles.Admin }.Contains(dto.Role))
            return BadRequest(new { message = "Choose a valid account role." });

        if (await _db.Users.AnyAsync(u => u.Username == username))
            return BadRequest(new { message = "That username is already taken." });

        if (!string.IsNullOrWhiteSpace(dto.IdNumber) && await _db.Users.AnyAsync(u => u.IdNumber == dto.IdNumber))
            return BadRequest(new { message = "That ID / roll number is already registered." });

        if (string.IsNullOrEmpty(password))
            return BadRequest(new { message = "Enter a password." });

        var user = new User
        {
            FullName = fullName,
            Username = username,
            Email = dto.Email,
            Phone = dto.Phone,
            Role = dto.Role,
            IdNumber = dto.IdNumber,
            Department = dto.Department,
            PasswordHash = PasswordHasher.Hash(password),
            IsActive = dto.IsActive
        };

        _db.Users.Add(user);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Person.Create", $"Created {user.Role} account for {user.FullName}");

        return CreatedAtAction(nameof(Get), new { id = user.Id }, ToDto(user));
    }

    [HttpPost("password-reset-code"), Authorize(Policy = Policies.AdminOnly)]
    public async Task<IActionResult> GeneratePasswordResetCode(PasswordResetCodeDto dto)
    {
        var user = await _db.Users.FindAsync(dto.UserId);
        if (user == null) return NotFound(new { message = "Account not found." });
        if (!user.IsActive) return BadRequest(new { message = "Activate the account before generating a reset code." });
        var code = RandomNumberGenerator.GetInt32(100000, 1000000).ToString();
        user.PasswordResetCodeHash = PasswordHasher.Hash(code);
        user.PasswordResetCodeExpiresAt = DateTime.UtcNow.AddMinutes(15);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Person.PasswordResetCode", $"Generated a password reset code for {user.FullName}");
        return Ok(new { code, expiresAt = user.PasswordResetCodeExpiresAt, message = "Give this code to the user. It expires in 15 minutes and can be used once." });
    }

    [HttpPut("{id:int}"), Authorize(Policy = Policies.AdminOnly)]
    public async Task<IActionResult> Update(int id, PersonUpdateDto dto)
    {
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var user = await _db.Users.FindAsync(id);
        if (user == null) return NotFound();

        if (!string.IsNullOrWhiteSpace(dto.IdNumber) &&
            await _db.Users.AnyAsync(u => u.IdNumber == dto.IdNumber && u.Id != id))
            return BadRequest(new { message = "That ID / roll number is already registered." });

        user.FullName = dto.FullName.Trim();
        user.Email = dto.Email;
        user.Phone = dto.Phone;
        user.Role = dto.Role;
        user.IdNumber = dto.IdNumber;
        user.Department = dto.Department;
        user.IsActive = dto.IsActive;

        if (!string.IsNullOrEmpty(dto.Password))
            user.PasswordHash = PasswordHasher.Hash(dto.Password); // any characters, any length

        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Person.Update", $"Updated {user.Role} account for {user.FullName}");
        return NoContent();
    }

    [HttpDelete("{id:int}"), Authorize(Policy = Policies.AdminOnly)]
    public async Task<IActionResult> Delete(int id)
    {
        var user = await _db.Users.FindAsync(id);
        if (user == null) return NotFound();

        _db.Users.Remove(user);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Person.Delete", $"Deleted {user.Role} account for {user.FullName}");
        return NoContent();
    }

    /// <summary>Upload / replace a person's photo (used on the ID card).</summary>
    [HttpPost("{id:int}/photo"), Authorize(Policy = Policies.AdminOnly)]
    public async Task<ActionResult<PersonDto>> UploadPhoto(int id, IFormFile photo)
    {
        var user = await _db.Users.FindAsync(id);
        if (user == null) return NotFound();

        if (photo.Length == 0) return BadRequest(new { message = "No file uploaded." });
        if (photo.Length > 5 * 1024 * 1024) return BadRequest(new { message = "Photo must be under 5 MB." });

        var allowedExt = new[] { ".jpg", ".jpeg", ".png", ".webp" };
        var ext = Path.GetExtension(photo.FileName).ToLowerInvariant();
        if (!allowedExt.Contains(ext)) return BadRequest(new { message = "Use a JPG, PNG or WEBP image." });

        var uploadsDir = Path.Combine("wwwroot", "uploads", "photos");
        Directory.CreateDirectory(uploadsDir);

        var fileName = $"{user.Id}_{Guid.NewGuid():N}{ext}";
        var fullPath = Path.Combine(uploadsDir, fileName);

        await using (var stream = System.IO.File.Create(fullPath))
            await photo.CopyToAsync(stream);

        user.PhotoPath = $"/uploads/photos/{fileName}";
        await _db.SaveChangesAsync();

        return Ok(ToDto(user));
    }

    /// <summary>PNG (base64) of the person's QR code, for the printable ID card.
    /// Same view rule as above: Admin any role, Teacher Students only, Staff none.</summary>
    [HttpGet("{id:int}/qr")]
    public async Task<ActionResult> GetQrCode(int id, [FromServices] QrService qr)
    {
        var user = await _db.Users.FindAsync(id);
        if (user == null) return NotFound();

        // Viewing your OWN QR/ID card (e.g. to print it, or show it at the gate) is always
        // allowed, even for Staff/Student who otherwise can't browse other People records.
        if (id != User.GetUserId())
        {
            var denied = CheckViewAllowed(user.Role);
            if (denied != null) return denied;
        }

        var base64 = qr.GeneratePngBase64(user.QrToken);
        return Ok(new { imageBase64 = base64, mimeType = "image/png" });
    }

    /// <summary>Issue a brand-new QR secret (e.g. lost ID card).</summary>
    [HttpPost("{id:int}/qr/regenerate"), Authorize(Policy = Policies.AdminOnly)]
    public async Task<ActionResult> RegenerateQr(int id)
    {
        var user = await _db.Users.FindAsync(id);
        if (user == null) return NotFound();

        user.QrToken = Guid.NewGuid().ToString("N");
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
