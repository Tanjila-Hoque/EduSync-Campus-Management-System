using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Dtos;
using StudentManagement.Models;
using StudentManagement.Services;

namespace StudentManagement.Controllers;

[ApiController]
[Route("api/classes")]
[Authorize]
public class ClassController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IAuditLogger _audit;

    public ClassController(AppDbContext db, IAuditLogger audit)
    {
        _db = db;
        _audit = audit;
    }

    [HttpGet]
    public async Task<IActionResult> Index([FromQuery] int? page = null, [FromQuery] int? pageSize = null, [FromQuery] string? search = null)
    {
        var role = User.GetRole();
        var q = _db.AcademicClasses
            .Include(c => c.Teacher)
            .Select(c => new AcademicClassDto
            {
                Id = c.Id,
                CourseName = c.CourseName,
                Section = c.Section,
                Department = c.Department,
                Room = c.Room,
                TeacherId = c.TeacherId,
                TeacherName = c.Teacher.FullName,
                IsActive = c.IsActive,
                StudentCount = _db.ClassEnrollments.Count(e => e.ClassId == c.Id)
            });

        if (role == Roles.Teacher)
            q = q.Where(c => c.TeacherId == User.GetUserId());
        else if (role == Roles.Student)
            q = q.Where(c => _db.ClassEnrollments.Any(e => e.ClassId == c.Id && e.StudentId == User.GetUserId()));
        else if (role != Roles.Admin)
            return Forbid();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            var searchTerm = term;
            // Filter at the database before counting/paging.
            var lowered = searchTerm.ToLower();
            // EF translates these predicates to SQL; no complete list is loaded in memory.
            q = q.Where(c => c.CourseName.ToLower().Contains(lowered)
                || (c.Section != null && c.Section.ToLower().Contains(lowered))
                || (c.Department != null && c.Department.ToLower().Contains(lowered))
                || (c.Room != null && c.Room.ToLower().Contains(lowered))
                || (role != Roles.Student && c.TeacherName != null && c.TeacherName.ToLower().Contains(lowered))); // students never see teacher names, so they cannot search by them
        }
        var totalCount = await q.CountAsync();
        if (page.HasValue || pageSize.HasValue || !string.IsNullOrWhiteSpace(search))
        {
            var currentPage = Math.Max(1, page ?? 1);
            var currentSize = Math.Clamp(pageSize ?? 10, 5, 100);
            var resultPage = await q.OrderBy(c => c.CourseName).ThenBy(c => c.Section).ThenBy(c => c.Id)
                .Skip((currentPage - 1) * currentSize).Take(currentSize).ToListAsync();
            if (role == Roles.Student) foreach (var c in resultPage) { c.TeacherId = 0; c.TeacherName = ""; }
            return Ok(new { items = resultPage, page = currentPage, pageSize = currentSize, totalCount,
                totalPages = (int)Math.Ceiling(totalCount / (double)currentSize) });
        }
        var result = await q.OrderBy(c => c.CourseName).ThenBy(c => c.Section).ToListAsync();
        if (role == Roles.Student) foreach (var c in result) { c.TeacherId = 0; c.TeacherName = ""; }
        return Ok(result);
    }

    /// <summary>Student: every active class, with a flag for the ones they have joined. This is how a
    /// student (including someone who just signed up) picks the classes they attend, so that each
    /// Teacher's attendance list contains exactly their own students.</summary>
    [HttpGet("browse")]
    public async Task<ActionResult<List<AcademicClassDto>>> Browse()
    {
        if (User.GetRole() != Roles.Student) return StatusCode(403, new { message = "Only Students pick their classes." });
        var me = User.GetUserId();

        var list = await _db.AcademicClasses
            .Where(c => c.IsActive)
            .OrderBy(c => c.CourseName).ThenBy(c => c.Section)
            .Select(c => new AcademicClassDto
            {
                Id = c.Id,
                CourseName = c.CourseName,
                Section = c.Section,
                Department = c.Department,
                Room = c.Room,
                TeacherId = c.TeacherId,
                TeacherName = c.Teacher.FullName,
                IsActive = c.IsActive,
                StudentCount = _db.ClassEnrollments.Count(e => e.ClassId == c.Id),
                Enrolled = _db.ClassEnrollments.Any(e => e.ClassId == c.Id && e.StudentId == me)
            })
            .ToListAsync();
        return Ok(list);
    }

    /// <summary>Student: join a class (so it counts them in that Teacher's attendance).</summary>
    [HttpPost("{id:int}/join")]
    public async Task<IActionResult> Join(int id)
    {
        if (User.GetRole() != Roles.Student) return StatusCode(403, new { message = "Only Students pick their classes." });
        var c = await _db.AcademicClasses.FirstOrDefaultAsync(x => x.Id == id && x.IsActive);
        if (c == null) return NotFound(new { message = "Class not found." });

        var me = User.GetUserId();
        if (await _db.ClassEnrollments.AnyAsync(e => e.ClassId == id && e.StudentId == me))
            return Ok(new { message = "You're already in this class." });

        _db.ClassEnrollments.Add(new ClassEnrollment { ClassId = id, StudentId = me });
        try { await _db.SaveChangesAsync(); }
        catch (DbUpdateException) { /* double tap - already joined */ }

        await _audit.LogAsync(User, "Class.Join", $"Joined {c.CourseName} {c.Section}");
        return Ok(new { message = $"You joined {c.CourseName}." });
    }

    /// <summary>Student: leave a class (past attendance stays).</summary>
    [HttpDelete("{id:int}/join")]
    public async Task<IActionResult> Leave(int id)
    {
        if (User.GetRole() != Roles.Student) return StatusCode(403, new { message = "Only Students pick their classes." });
        var me = User.GetUserId();
        var e = await _db.ClassEnrollments.FirstOrDefaultAsync(x => x.ClassId == id && x.StudentId == me);
        if (e != null)
        {
            _db.ClassEnrollments.Remove(e);
            await _db.SaveChangesAsync();
        }
        return Ok(new { message = "You left this class." });
    }

    [HttpPost, Authorize(Policy = Policies.AdminOnly)]
    public async Task<ActionResult<AcademicClassDto>> Create(AcademicClassCreateDto dto)
    {
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var teacher = await _db.Users.FirstOrDefaultAsync(u => u.Id == dto.TeacherId && u.Role == Roles.Teacher && u.IsActive);
        if (teacher == null) return BadRequest(new { message = "Select an active Teacher account." });

        var exists = await _db.AcademicClasses.AnyAsync(c => c.TeacherId == dto.TeacherId && c.CourseName == dto.CourseName.Trim() && c.Section == (dto.Section ?? "").Trim());
        if (exists) return Conflict(new { message = "That course/section is already assigned to this teacher." });

        var c = new AcademicClass
        {
            CourseName = dto.CourseName.Trim(),
            Section = (dto.Section ?? "").Trim(),
            Department = (dto.Department ?? "").Trim(),
            Room = (dto.Room ?? "").Trim(),
            TeacherId = teacher.Id,
            IsActive = true
        };
        _db.AcademicClasses.Add(c);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Class.Create", $"Created {c.CourseName} {c.Section} for {teacher.FullName}");
        c.Teacher = teacher;
        return Ok(new AcademicClassDto
        {
            Id = c.Id, CourseName = c.CourseName, Section = c.Section, Department = c.Department,
            Room = c.Room, TeacherId = c.TeacherId, TeacherName = teacher.FullName, IsActive = c.IsActive, StudentCount = 0
        });
    }

    [HttpPut("{id:int}"), Authorize(Policy = Policies.AdminOnly)]
    public async Task<IActionResult> Update(int id, AcademicClassCreateDto dto)
    {
        var c = await _db.AcademicClasses.FindAsync(id);
        if (c == null) return NotFound();
        var teacher = await _db.Users.FirstOrDefaultAsync(u => u.Id == dto.TeacherId && u.Role == Roles.Teacher && u.IsActive);
        if (teacher == null) return BadRequest(new { message = "Select an active Teacher account." });

        c.CourseName = dto.CourseName.Trim();
        c.Section = (dto.Section ?? "").Trim();
        c.Department = (dto.Department ?? "").Trim();
        c.Room = (dto.Room ?? "").Trim();
        c.TeacherId = teacher.Id;
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Class.Update", $"Updated {c.CourseName} {c.Section}");
        return NoContent();
    }

    [HttpDelete("{id:int}"), Authorize(Policy = Policies.AdminOnly)]
    public async Task<IActionResult> Delete(int id)
    {
        var c = await _db.AcademicClasses.FindAsync(id);
        if (c == null) return NotFound();
        c.IsActive = false;
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Class.Deactivate", $"Deactivated {c.CourseName} {c.Section}");
        return NoContent();
    }

    [HttpGet("{id:int}/students")]
    public async Task<ActionResult<List<ClassEnrollmentDto>>> Students(int id)
    {
        var c = await _db.AcademicClasses.FindAsync(id);
        if (c == null) return NotFound();
        if (User.GetRole() == Roles.Teacher && c.TeacherId != User.GetUserId()) return Forbid();
        if (User.GetRole() == Roles.Student)
        {
            var own = await _db.ClassEnrollments.AnyAsync(e => e.ClassId == id && e.StudentId == User.GetUserId());
            if (!own) return Forbid();
        }
        if (User.GetRole() == Roles.Staff) return Forbid();

        var studentsQuery = _db.ClassEnrollments
            .Where(e => e.ClassId == id && e.Student.IsActive);
        if (User.GetRole() == Roles.Student)
            studentsQuery = studentsQuery.Where(e => e.StudentId == User.GetUserId());

        var students = await studentsQuery
            .OrderBy(e => e.Student.FullName)
            .Select(e => new ClassEnrollmentDto
            {
                ClassId = e.ClassId,
                StudentId = e.StudentId,
                StudentName = e.Student.FullName,
                StudentIdNumber = e.Student.IdNumber
            }).ToListAsync();
        return Ok(students);
    }

    [HttpPost("{id:int}/students/{studentId:int}"), Authorize(Policy = Policies.AdminOnly)]
    public async Task<IActionResult> Enroll(int id, int studentId)
    {
        var c = await _db.AcademicClasses.FindAsync(id);
        var student = await _db.Users.FirstOrDefaultAsync(u => u.Id == studentId && u.Role == Roles.Student && u.IsActive);
        if (c == null || student == null) return BadRequest(new { message = "Class or active Student not found." });
        if (await _db.ClassEnrollments.AnyAsync(e => e.ClassId == id && e.StudentId == studentId))
            return Conflict(new { message = "Student is already enrolled in this class." });

        _db.ClassEnrollments.Add(new ClassEnrollment { ClassId = id, StudentId = studentId });
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Class.Enroll", $"Enrolled {student.FullName} in {c.CourseName} {c.Section}");
        return NoContent();
    }

    [HttpDelete("{id:int}/students/{studentId:int}"), Authorize(Policy = Policies.AdminOnly)]
    public async Task<IActionResult> Unenroll(int id, int studentId)
    {
        var e = await _db.ClassEnrollments.FirstOrDefaultAsync(x => x.ClassId == id && x.StudentId == studentId);
        if (e == null) return NotFound();
        var student = await _db.Users.FindAsync(studentId);
        var c = await _db.AcademicClasses.FindAsync(id);
        _db.ClassEnrollments.Remove(e);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Class.Unenroll", $"Removed {student?.FullName ?? "Student"} from {c?.CourseName ?? "class"}");
        return NoContent();
    }
}

