using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Dtos;
using StudentManagement.Models;
using StudentManagement.Services;

namespace StudentManagement.Controllers;

[ApiController]
[Route("api/dashboard")]
[Authorize(Policy = Policies.AdminOnly)]
public class DashboardController : ControllerBase
{
    private readonly AppDbContext _db;
    public DashboardController(AppDbContext db) => _db = db;

    [HttpGet("summary")]
    public async Task<ActionResult<DashboardSummaryDto>> Summary()
    {
        var today = AppClock.Today;

        var summary = new DashboardSummaryDto
        {
            TotalStudents = await _db.Users.CountAsync(u => u.Role == Roles.Student),
            TotalTeachers = await _db.Users.CountAsync(u => u.Role == Roles.Teacher),
            TotalStaff = await _db.Users.CountAsync(u => u.Role == Roles.Staff),
            TodayAttendanceCount = await _db.Attendance.CountAsync(a => a.Date == today),
            NoticeCount = await _db.Notices.CountAsync(),
            RecentActivity = await _db.AuditLogs
                .OrderByDescending(l => l.Timestamp)
                .Take(10)
                .Select(l => new AuditLogDto
                {
                    Id = l.Id, ActorName = l.ActorName, ActorRole = l.ActorRole,
                    Action = l.Action, Details = l.Details, Timestamp = l.Timestamp
                })
                .ToListAsync()
        };

        return Ok(summary);
    }
}
