using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Dtos;
using StudentManagement.Models;
using StudentManagement.Services;

namespace StudentManagement.Controllers;

[ApiController]
[Route("api/notices")]
[Authorize]
public class NoticeController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IAuditLogger _audit;
    public NoticeController(AppDbContext db, IAuditLogger audit)
    { _db = db; _audit = audit; }

    [HttpGet]
    public async Task<IActionResult> Index([FromQuery] int? page = null, [FromQuery] int? pageSize = null, [FromQuery] string? search = null)
    {
        var role = User.GetRole(); var me = User.GetUserId();
        var q = _db.Notices.Include(n => n.CreatedBy).Include(n => n.TargetClass).AsQueryable();

        if (role == Roles.Student)
            q = q.Where(n => (n.TargetClassId == null && (n.AudienceRole == null || n.AudienceRole == Roles.Student))
                || (n.TargetClassId != null && _db.ClassEnrollments.Any(e => e.ClassId == n.TargetClassId && e.StudentId == me)));
        else if (role == Roles.Teacher)
            q = q.Where(n => (n.TargetClassId == null && n.AudienceRole == null) || n.CreatedByUserId == me);
        else if (role == Roles.Staff)
            q = q.Where(n => n.TargetClassId == null && (n.AudienceRole == null || n.AudienceRole == Roles.Staff));
        // Admin sees all.

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim().ToLower();
            // Students never see who posted a notice, so they cannot search by author either.
            var byAuthor = role != Roles.Student;
            q = q.Where(n => n.Title.ToLower().Contains(term) || n.Body.ToLower().Contains(term)
                || (byAuthor && n.CreatedBy.FullName.ToLower().Contains(term)));
        }

        var shaped = q.OrderByDescending(n => n.CreatedAt).ThenByDescending(n => n.Id).Select(n => new NoticeDto {
            Id=n.Id, Title=n.Title, Body=n.Body, AudienceRole=n.AudienceRole, TargetClassId=n.TargetClassId,
            TargetClassName=n.TargetClass==null?null:n.TargetClass.CourseName+(string.IsNullOrWhiteSpace(n.TargetClass.Section)?"":" · "+n.TargetClass.Section),
            CreatedByName=n.CreatedBy.FullName, CreatedAt=n.CreatedAt
        });

        if (page.HasValue || pageSize.HasValue || !string.IsNullOrWhiteSpace(search))
        {
            var size = Math.Clamp(pageSize ?? 10, 5, 100);
            var total = await q.CountAsync();
            var pages = (int)Math.Ceiling(total / (double)size);
            var current = Math.Clamp(page ?? 1, 1, Math.Max(1, pages));
            var items = await shaped.Skip((current - 1) * size).Take(size).ToListAsync();
            return Ok(new { items, page = current, pageSize = size, totalCount = total, totalPages = pages });
        }
        return Ok(await shaped.ToListAsync());
    }

    [HttpPost, Authorize(Policy = Policies.TeacherOrAdmin)]
    public async Task<ActionResult<NoticeDto>> Create(NoticeCreateDto dto, CancellationToken ct)
    {
        if (!ModelState.IsValid) return ValidationProblem(ModelState);
        var role = User.GetRole();
        AcademicClass? target = null;
        Notice notice;
        IQueryable<User> recipients;
        if (role == Roles.Teacher)
        {
            if (dto.TargetClassId is null)
                return BadRequest(new { message = "Choose one of your classes. Teacher notices are private to that class." });
            target = await _db.AcademicClasses.FirstOrDefaultAsync(x => x.Id == dto.TargetClassId.Value && x.IsActive && x.TeacherId == User.GetUserId(), ct);
            if (target == null) return Forbid();
            notice = new Notice { Title = dto.Title.Trim(), Body = dto.Body.Trim(), AudienceRole = Roles.Student,
                TargetClassId = target.Id, CreatedByUserId = User.GetUserId() };
            recipients = _db.Users.Where(u => u.IsActive && u.Role == Roles.Student &&
                _db.ClassEnrollments.Any(e => e.ClassId == target.Id && e.StudentId == u.Id));
        }
        else
        {
            if (dto.AudienceRole != null && !Roles.All.Contains(dto.AudienceRole))
                return BadRequest(new { message = "Unknown audience role." });
            if (dto.TargetClassId is not null)
            {
                target = await _db.AcademicClasses.FindAsync(new object[] { dto.TargetClassId.Value }, ct);
                if (target == null) return BadRequest(new { message = "Target class not found." });
            }
            notice = new Notice { Title = dto.Title.Trim(), Body = dto.Body.Trim(), AudienceRole = dto.AudienceRole,
                TargetClassId = dto.TargetClassId, CreatedByUserId = User.GetUserId() };
            recipients = _db.Users.Where(u => u.IsActive && u.Id != User.GetUserId());
            if (notice.TargetClassId is not null)
                recipients = recipients.Where(u => _db.ClassEnrollments.Any(e => e.ClassId == notice.TargetClassId && e.StudentId == u.Id));
            else if (!string.IsNullOrWhiteSpace(notice.AudienceRole))
                recipients = recipients.Where(u => u.Role == notice.AudienceRole);
        }

        _db.Notices.Add(notice);
        await _db.SaveChangesAsync(ct);
        var recipientIds = await recipients.Select(u => u.Id).ToListAsync(ct);
        foreach (var id in recipientIds)
            _db.Notifications.Add(new InAppNotification { UserId = id, Title = "Campus notice: " + notice.Title,
                Message = notice.Body.Length > 1100 ? notice.Body[..1100] : notice.Body,
                Kind = "notice", Link = "/notices" });
        await _db.SaveChangesAsync(ct);
        await _audit.LogAsync(User, "Notice.Create", $"Posted notice \"{notice.Title}\"; in-app notifications: {recipientIds.Count}");
        return Ok(new NoticeDto { Id = notice.Id, Title = notice.Title, Body = notice.Body,
            AudienceRole = notice.AudienceRole, TargetClassId = notice.TargetClassId,
            TargetClassName = target == null ? null : target.CourseName + (string.IsNullOrWhiteSpace(target.Section) ? "" : " · " + target.Section),
            CreatedByName = User.FindFirst("FullName")?.Value ?? "", CreatedAt = notice.CreatedAt });
    }

    [HttpDelete("{id:int}"), Authorize(Policy = Policies.TeacherOrAdmin)]
    public async Task<IActionResult> Delete(int id)
    {
        var n=await _db.Notices.FindAsync(id); if(n==null)return NotFound();
        if(User.GetRole()!=Roles.Admin && n.CreatedByUserId!=User.GetUserId())return Forbid();
        _db.Notices.Remove(n); await _db.SaveChangesAsync();
        await _audit.LogAsync(User,"Notice.Delete",$"Deleted notice \"{n.Title}\""); return NoContent();
    }
}
