using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Models;
using StudentManagement.Services;

namespace StudentManagement.Controllers;

/// <summary>Institution-wide, database-backed operational indicators for Admins.</summary>
[ApiController]
[Route("api/campus-intelligence")]
[Authorize(Policy = Policies.AdminOnly)]
public class CampusIntelligenceController : ControllerBase
{
    private readonly AppDbContext _db;
    public CampusIntelligenceController(AppDbContext db) => _db = db;

    [HttpGet("overview")]
    public async Task<IActionResult> Overview()
    {
        var today = AppClock.Today;
        var firstDay = today.AddDays(-13);

        var totalUsers = await _db.Users.CountAsync();
        var activeUsers = await _db.Users.CountAsync(u => u.IsActive);
        var totalStudents = await _db.Users.CountAsync(u => u.Role == Roles.Student);
        var activeStudents = await _db.Users.CountAsync(u => u.Role == Roles.Student && u.IsActive);
        var totalTeachers = await _db.Users.CountAsync(u => u.Role == Roles.Teacher);
        var activeTeachers = await _db.Users.CountAsync(u => u.Role == Roles.Teacher && u.IsActive);
        var totalStaff = await _db.Users.CountAsync(u => u.Role == Roles.Staff);
        var activeClasses = await _db.AcademicClasses.CountAsync(c => c.IsActive);
        var activeEnrollments = await _db.ClassEnrollments.CountAsync(e => e.Class.IsActive && e.Student.IsActive);
        var classAttendanceToday = await _db.Attendance.CountAsync(a => a.ClassId != null && a.Date == today);
        var resultCount = await _db.ResultEntries.CountAsync();
        var averageCourseworkMarks = resultCount == 0
            ? 0
            : Math.Round(await _db.ResultEntries.AverageAsync(r => r.Mid + r.Final + r.Assignment), 1);
        var noticeCount = await _db.Notices.CountAsync();
        var unreadNotifications = await _db.Notifications.CountAsync(n => n.ReadAt == null);
        var scheduledEntries = await _db.RoutineEntries.CountAsync();

        var departments = await _db.Users
            .Where(u => u.Role == Roles.Student || u.Role == Roles.Teacher)
            .GroupBy(u => u.Department ?? "Unassigned")
            .Select(g => new
            {
                department = g.Key,
                students = g.Count(u => u.Role == Roles.Student),
                teachers = g.Count(u => u.Role == Roles.Teacher)
            })
            .OrderByDescending(x => x.students)
            .ThenBy(x => x.department)
            .Take(10)
            .ToListAsync();

        var attendanceRows = await _db.Attendance
            .Where(a => a.ClassId != null && a.Date >= firstDay && a.Date <= today)
            .GroupBy(a => a.Date)
            .Select(g => new { Date = g.Key, Count = g.Count() })
            .ToListAsync();
        var attendanceCounts = attendanceRows.ToDictionary(x => x.Date, x => x.Count);
        var attendanceTrend = Enumerable.Range(0, 14).Select(offset =>
        {
            var date = firstDay.AddDays(offset);
            return new { date, count = attendanceCounts.TryGetValue(date, out var count) ? count : 0 };
        }).ToList();

        // ResultEntry timestamps are UTC. Convert each result date into the campus calendar day.
        var cutoffUtc = DateTime.UtcNow.AddDays(-16);
        var resultTimestamps = await _db.ResultEntries
            .Where(r => r.CreatedAt >= cutoffUtc)
            .Select(r => r.CreatedAt)
            .ToListAsync();
        var resultCounts = new Dictionary<DateOnly, int>();
        foreach (var timestamp in resultTimestamps)
        {
            var date = AppClock.DateOf(timestamp);
            if (date < firstDay || date > today) continue;
            resultCounts[date] = resultCounts.TryGetValue(date, out var current) ? current + 1 : 1;
        }
        var resultsTrend = Enumerable.Range(0, 14).Select(offset =>
        {
            var date = firstDay.AddDays(offset);
            return new { date, count = resultCounts.TryGetValue(date, out var count) ? count : 0 };
        }).ToList();

        var recentActivity = await _db.AuditLogs
            .OrderByDescending(a => a.Timestamp)
            .Take(8)
            .Select(a => new
            {
                a.Id,
                a.ActorName,
                a.ActorRole,
                a.Action,
                a.Details,
                a.Timestamp
            })
            .ToListAsync();

        return Ok(new
        {
            generatedAt = AppClock.UtcNow,
            totals = new
            {
                totalUsers,
                activeUsers,
                totalStudents,
                activeStudents,
                totalTeachers,
                activeTeachers,
                totalStaff,
                activeClasses,
                activeEnrollments,
                classAttendanceToday,
                resultCount,
                averageCourseworkMarks,
                noticeCount,
                unreadNotifications,
                scheduledEntries
            },
            departmentBreakdown = departments,
            attendanceTrend,
            resultsTrend,
            recentActivity
        });
    }
}
