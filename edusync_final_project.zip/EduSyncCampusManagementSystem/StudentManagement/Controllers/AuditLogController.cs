using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Dtos;
using StudentManagement.Models;

namespace StudentManagement.Controllers;

[ApiController]
[Route("api/audit-logs")]
[Authorize(Policy = Policies.AdminOnly)]
public class AuditLogController : ControllerBase
{
    private readonly AppDbContext _db;
    public AuditLogController(AppDbContext db) => _db = db;

    /// <summary>With page / pageSize / search: server-side DataTable paging (search + count + page all run in the database).
    /// Without them: the old behaviour (latest <paramref name="take"/> entries as a plain list).</summary>
    [HttpGet]
    public async Task<IActionResult> Index([FromQuery] int take = 100, [FromQuery] int? page = null, [FromQuery] int? pageSize = null, [FromQuery] string? search = null)
    {
        var q = _db.AuditLogs.AsQueryable();
        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim().ToLower();
            q = q.Where(l => l.ActorName.ToLower().Contains(term) || l.ActorRole.ToLower().Contains(term)
                || l.Action.ToLower().Contains(term) || l.Details.ToLower().Contains(term));
        }
        var ordered = q.OrderByDescending(l => l.Timestamp).ThenByDescending(l => l.Id);
        var shaped = ordered.Select(l => new AuditLogDto
        {
            Id = l.Id, ActorName = l.ActorName, ActorRole = l.ActorRole, Action = l.Action, Details = l.Details, Timestamp = l.Timestamp
        });

        if (page.HasValue || pageSize.HasValue || !string.IsNullOrWhiteSpace(search))
        {
            var size = Math.Clamp(pageSize ?? 10, 5, 100);
            var total = await q.CountAsync();
            var pages = (int)Math.Ceiling(total / (double)size);
            var current = Math.Clamp(page ?? 1, 1, Math.Max(1, pages));
            var items = await shaped.Skip((current - 1) * size).Take(size).ToListAsync();
            return Ok(new { items, page = current, pageSize = size, totalCount = total, totalPages = pages });
        }
        return Ok(await shaped.Take(Math.Clamp(take, 1, 500)).ToListAsync());
    }
}
