using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Models;
using StudentManagement.Services;

namespace StudentManagement.Controllers;

[ApiController]
[Route("api/notifications")]
[Authorize]
public class NotificationsController : ControllerBase
{
    private readonly AppDbContext _db;
    public NotificationsController(AppDbContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> List([FromQuery] int page = 1, [FromQuery] int pageSize = 10, CancellationToken ct = default)
    {
        page = Math.Max(1, page); pageSize = Math.Clamp(pageSize, 1, 50);
        var uid = User.GetUserId();
        var q = _db.Notifications.AsNoTracking().Where(n => n.UserId == uid);
        var total = await q.CountAsync(ct);
        var unread = await q.CountAsync(n => n.ReadAt == null, ct);
        var items = await q.OrderByDescending(n => n.CreatedAt).ThenByDescending(n => n.Id)
            .Skip((page - 1) * pageSize).Take(pageSize)
            .Select(n => new { n.Id, n.Title, n.Message, n.Kind, n.Link, n.CreatedAt, n.ReadAt, IsRead = n.ReadAt != null }).ToListAsync(ct);
        return Ok(new { items, page, pageSize, total, unread, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
    }

    [HttpPost("{id:long}/read")]
    public async Task<IActionResult> MarkRead(long id, CancellationToken ct)
    {
        var item = await _db.Notifications.FirstOrDefaultAsync(n => n.Id == id && n.UserId == User.GetUserId(), ct);
        if (item == null) return NotFound();
        item.ReadAt ??= DateTime.UtcNow;
        await _db.SaveChangesAsync(ct);
        return Ok(new { item.Id, item.ReadAt });
    }

    [HttpPost("read-all")]
    public async Task<IActionResult> MarkAllRead(CancellationToken ct)
    {
        await _db.Notifications.Where(n => n.UserId == User.GetUserId() && n.ReadAt == null)
            .ExecuteUpdateAsync(s => s.SetProperty(n => n.ReadAt, DateTime.UtcNow), ct);
        return Ok(new { unread = 0 });
    }
}
