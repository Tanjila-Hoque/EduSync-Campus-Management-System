using System.Globalization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Dtos;
using StudentManagement.Models;
using StudentManagement.Services;

namespace StudentManagement.Controllers;

[ApiController]
[Route("api/routine")]
[Authorize]
public class RoutineController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IAuditLogger _audit;
    public RoutineController(AppDbContext db, IAuditLogger audit) { _db = db; _audit = audit; }

    private static readonly string[] DayOrder =
        { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };


    private static bool TryGetMinutes(string? value, out int minutes)
    {
        minutes = 0;
        if (!TimeOnly.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.None, out var time))
            return false;
        minutes = (time.Hour * 60) + time.Minute;
        return true;
    }

    private static RoutineConflictDto? GetConflict(RoutineEntry first, RoutineEntry second)
    {
        if (!string.Equals(first.Day, second.Day, StringComparison.OrdinalIgnoreCase) ||
            !TryGetMinutes(first.StartTime, out var firstStart) ||
            !TryGetMinutes(first.EndTime, out var firstEnd) ||
            !TryGetMinutes(second.StartTime, out var secondStart) ||
            !TryGetMinutes(second.EndTime, out var secondEnd))
            return null;

        // Touching boundaries (for example 10:00-11:00 and 11:00-12:00) are not a clash.
        if (firstStart >= secondEnd || secondStart >= firstEnd) return null;

        var types = new List<string>();
        var reasons = new List<string>();
        if (first.TeacherId.HasValue && first.TeacherId == second.TeacherId)
        {
            types.Add("Teacher");
            reasons.Add($"{first.Teacher?.FullName ?? "The assigned teacher"} is scheduled for both classes.");
        }

        var firstRoom = first.Room?.Trim();
        var secondRoom = second.Room?.Trim();
        if (!string.IsNullOrWhiteSpace(firstRoom) && !string.IsNullOrWhiteSpace(secondRoom) &&
            string.Equals(firstRoom, secondRoom, StringComparison.OrdinalIgnoreCase))
        {
            types.Add("Room");
            reasons.Add($"Room {firstRoom} is booked for both classes.");
        }

        if (types.Count == 0) return null;

        return new RoutineConflictDto
        {
            FirstId = first.Id,
            SecondId = second.Id,
            Day = first.Day,
            FirstCourseName = first.CourseName,
            SecondCourseName = second.CourseName,
            FirstStartTime = first.StartTime,
            FirstEndTime = first.EndTime,
            SecondStartTime = second.StartTime,
            SecondEndTime = second.EndTime,
            FirstRoom = first.Room ?? "",
            SecondRoom = second.Room ?? "",
            FirstTeacherName = first.Teacher?.FullName,
            SecondTeacherName = second.Teacher?.FullName,
            ConflictType = string.Join(" + ", types),
            Reason = string.Join(" ", reasons)
        };
    }

    private static List<RoutineConflictDto> FindConflicts(List<RoutineEntry> entries)
    {
        var conflicts = new List<RoutineConflictDto>();
        for (var i = 0; i < entries.Count; i++)
        {
            for (var j = i + 1; j < entries.Count; j++)
            {
                var conflict = GetConflict(entries[i], entries[j]);
                if (conflict != null) conflicts.Add(conflict);
            }
        }
        return conflicts
            .OrderBy(c => Array.IndexOf(DayOrder, c.Day))
            .ThenBy(c => c.FirstStartTime)
            .ToList();
    }

    /// <summary>Everyone signed in can view the routine (Teacher/Student/Staff/Admin) —
    /// it's a schedule, not personal data, so this stays open unlike People/Results.</summary>
    [HttpGet]
    public async Task<ActionResult<List<RoutineEntryDto>>> Index([FromQuery] string? department)
    {
        var role = User.GetRole();
        var query = _db.RoutineEntries.AsQueryable();
        if (!string.IsNullOrWhiteSpace(department))
            query = query.Where(r => r.Department == department);
        if (role == Roles.Student)
        {
            var me = User.GetUserId();
            query = query.Where(r => _db.ClassEnrollments.Any(e => e.StudentId == me && e.Class.CourseName == r.CourseName));
        }

        var items = await query
            .Select(r => new RoutineEntryDto
            {
                Id = r.Id,
                Day = r.Day,
                StartTime = r.StartTime,
                EndTime = r.EndTime,
                CourseName = r.CourseName,
                Room = r.Room,
                Department = r.Department,
                // Student privacy: schedule shows the course/room only, never the Teacher name.
                TeacherName = role == Roles.Student ? null : (r.Teacher != null ? r.Teacher.FullName : null)
            })
            .ToListAsync();

        var ordered = items
            .OrderBy(r => Array.IndexOf(DayOrder, r.Day))
            .ThenBy(r => r.StartTime)
            .ToList();

        return Ok(ordered);
    }

    /// <summary>Admin-only report of all existing teacher/room overlaps in the timetable.</summary>
    [HttpGet("conflicts"), Authorize(Policy = Policies.AdminOnly)]
    public async Task<ActionResult<List<RoutineConflictDto>>> Conflicts()
    {
        var entries = await _db.RoutineEntries.Include(r => r.Teacher).ToListAsync();
        return Ok(FindConflicts(entries));
    }

    /// <summary>Only Admin manages the routine. Staff and Students have read-only access.</summary>
    [HttpPost, Authorize(Policy = Policies.AdminOnly)]
    public async Task<ActionResult<RoutineEntryDto>> Create(RoutineEntryCreateDto dto)
    {
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var day = DayOrder.FirstOrDefault(d => string.Equals(d, dto.Day?.Trim(), StringComparison.OrdinalIgnoreCase));
        if (day == null) return BadRequest(new { message = "Choose a valid day of the week." });

        if (!TryGetMinutes(dto.StartTime, out var startMinutes) || !TryGetMinutes(dto.EndTime, out var endMinutes))
            return BadRequest(new { message = "Enter start and end times in 24-hour HH:mm format." });
        if (endMinutes <= startMinutes)
            return BadRequest(new { message = "End time must be later than start time." });

        User? teacher = null;
        if (dto.TeacherId.HasValue)
        {
            teacher = await _db.Users.FirstOrDefaultAsync(u => u.Id == dto.TeacherId.Value && u.Role == Roles.Teacher && u.IsActive);
            if (teacher == null) return BadRequest(new { message = "Select an active teacher account." });
        }

        var entry = new RoutineEntry
        {
            Day = day,
            StartTime = dto.StartTime.Trim(),
            EndTime = dto.EndTime.Trim(),
            CourseName = dto.CourseName.Trim(),
            Room = dto.Room?.Trim() ?? "",
            Department = dto.Department?.Trim() ?? "",
            TeacherId = dto.TeacherId,
            Teacher = teacher
        };

        var existing = await _db.RoutineEntries
            .Include(r => r.Teacher)
            .Where(r => r.Day.ToLower() == day.ToLower())
            .ToListAsync();
        var clashes = existing
            .Select(current => GetConflict(current, entry))
            .Where(c => c != null)
            .Select(c => c!)
            .ToList();

        if (clashes.Count > 0)
            return Conflict(new
            {
                message = "This class conflicts with an existing timetable entry. Change the time, teacher, or room before saving.",
                conflicts = clashes
            });

        _db.RoutineEntries.Add(entry);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Routine.Create", $"Added {entry.CourseName} on {entry.Day}");

        return Ok(new RoutineEntryDto
        {
            Id = entry.Id, Day = entry.Day, StartTime = entry.StartTime, EndTime = entry.EndTime,
            CourseName = entry.CourseName, Room = entry.Room, Department = entry.Department,
            TeacherName = teacher?.FullName
        });
    }

    [HttpDelete("{id:int}"), Authorize(Policy = Policies.AdminOnly)]
    public async Task<IActionResult> Delete(int id)
    {
        var entry = await _db.RoutineEntries.FindAsync(id);
        if (entry == null) return NotFound();

        _db.RoutineEntries.Remove(entry);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Routine.Delete", $"Removed {entry.CourseName} on {entry.Day}");
        return NoContent();
    }
}
