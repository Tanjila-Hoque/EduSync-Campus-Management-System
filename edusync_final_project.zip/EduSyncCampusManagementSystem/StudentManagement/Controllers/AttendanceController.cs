using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Dtos;
using StudentManagement.Models;
using StudentManagement.Services;

namespace StudentManagement.Controllers;

[ApiController]
[Route("api/attendance")]
[Authorize]
public class AttendanceController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IAuditLogger _audit;
    private readonly QrService _qr;
    private readonly IConfiguration _config;

    public AttendanceController(AppDbContext db, IAuditLogger audit, QrService qr, IConfiguration config)
    { _db = db; _audit = audit; _qr = qr; _config = config; }

    // ------------------------------------------------------------------
    // Dated QR codes: one attendance QR per day, valid on THAT day only.
    //  - Gate QR  : "EDUSYNC-GATE-yyyyMMdd-signature" - Teachers/Staff scan it once a day.
    //  - Class QR : "CLASS:KEY:yyyyMMdd:signature"    - KEY is the class's course + section
    //               (e.g. CSE3201A), so QR files can be made ahead of time without knowing
    //               database ids. It only counts while that class's Teacher has a session open.
    // The signature comes from Attendance:CheckInSecret (appsettings.json) + the date, so a QR for
    // another day is rejected. "Today" is the Bangladesh (Asia/Dhaka) date decided by the server.
    // Changing the secret invalidates every QR made before the change.
    // ------------------------------------------------------------------
    private string Secret => _config["Attendance:CheckInSecret"] ?? "EDUNEXA-DEFAULT-SECRET";

    private static string Hex(string raw, int length)
        => Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(raw)))[..length];

    private static string Ymd(DateOnly d) => d.ToString("yyyyMMdd");

    private string GateSignature(DateOnly d) => Hex($"{Secret}|gate|{Ymd(d)}", 12);
    private string BuildGateCode(DateOnly d) => $"EDUSYNC-GATE-{Ymd(d)}-{GateSignature(d)}";

    /// <summary>Letters and digits only, upper-case: "CSE-3201" + "A" -> "CSE3201A".</summary>
    private static string Norm(string text)
        => System.Text.RegularExpressions.Regex.Replace((text ?? "").ToUpperInvariant(), "[^A-Z0-9]", "");

    private static string ClassKey(AcademicClass c) => Norm(c.CourseName) + Norm(c.Section);

    private string ClassSignature(string key, DateOnly d) => Hex($"{Secret}|class|{key}|{Ymd(d)}", 12);
    private string BuildClassCode(AcademicClass c, DateOnly d)
    {
        var key = ClassKey(c);
        return $"CLASS:{key}:{Ymd(d)}:{ClassSignature(key, d)}";
    }

    private static bool TryParseYmd(string text, out DateOnly date)
        => DateOnly.TryParseExact(text, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);

    /// <summary>Admin: today's Teacher/Staff gate QR.</summary>
    [HttpGet("checkin-code"), Authorize(Policy = Policies.AdminOnly)]
    public ActionResult<CheckInCodeDto> CheckInCode()
    {
        var today = AppClock.Today;
        var code = BuildGateCode(today);
        return Ok(new CheckInCodeDto { Code = code, Date = today, ImageBase64 = _qr.GeneratePngBase64(code, 14) });
    }

    /// <summary>Teachers and Staff may self-check in once per calendar day. Students never use this QR.</summary>
    [HttpPost("checkin")]
    public async Task<IActionResult> CheckIn(CheckInRequest request)
    {
        var role = User.GetRole();
        if (role == Roles.Admin) return BadRequest(new { message = "Administrator accounts are not tracked by attendance." });
        if (role == Roles.Student) return Forbid();

        var user = await _db.Users.FindAsync(User.GetUserId());
        if (user == null || !user.IsActive) return BadRequest(new { message = "This account is disabled." });

        var today = AppClock.Today;
        var scanned = (request.Code ?? "").Trim();
        if (scanned != BuildGateCode(today))
        {
            // A genuine QR from another day is the common mistake - say so instead of a vague error.
            var pieces = scanned.Split('-');
            if (pieces.Length == 4 && pieces[0] == "EDUSYNC" && pieces[1] == "GATE" && TryParseYmd(pieces[2], out var other) && pieces[3] == GateSignature(other))
                return BadRequest(new { message = $"This QR is for {other:dd MMM yyyy}, not today ({today:dd MMM yyyy}). Use today's QR." });
            return BadRequest(new { message = "This is not the official Teacher/Staff check-in QR. Scan the QR from the Admin." });
        }

        if (await _db.Attendance.AnyAsync(a => a.UserId == user.Id && a.ClassId == null && a.Date == today))
            return Conflict(new { message = "You have already checked in today." });

        _db.Attendance.Add(new AttendanceRecord
        {
            UserId = user.Id,
            ClassId = null,
            Date = today,
            CheckInTime = AppClock.UtcNow,
            MarkedByUserId = user.Id
        });
        try { await _db.SaveChangesAsync(); }
        catch (DbUpdateException) { return Conflict(new { message = "You have already checked in today." }); }

        await _audit.LogAsync(User, "Attendance.SelfCheckIn", $"{user.FullName} ({user.Role}) checked in via today's QR");
        return Ok(new { message = "Attendance recorded.", fullName = user.FullName, role = user.Role, idNumber = user.IdNumber, time = AppClock.UtcNow });
    }

    [HttpPost("sessions"), Authorize(Policy = Policies.TeacherOrAdmin)]
    public async Task<ActionResult<AttendanceSessionDto>> StartSession(StartSessionRequest request)
    {
        var c = await _db.AcademicClasses.Include(x => x.Teacher).FirstOrDefaultAsync(x => x.Id == request.ClassId && x.IsActive);
        if (c == null) return BadRequest(new { message = "Select one of your active classes." });
        if (User.GetRole() == Roles.Teacher && c.TeacherId != User.GetUserId()) return Forbid();

        if (request.DurationMinutes is null or < 1 or > 180)
            return BadRequest(new { message = "Attendance duration must be between 1 and 180 minutes." });
        var duration = request.DurationMinutes.Value;
        var teacherId = c.TeacherId;
        var session = new AttendanceSession
        {
            ClassId = c.Id,
            CourseName = c.CourseName,
            Section = c.Section,
            TeacherId = teacherId,
            StartedAt = AppClock.UtcNow,
            ExpiresAt = AppClock.UtcNow.AddMinutes(duration),
            EndedEarly = false
        };
        _db.AttendanceSessions.Add(session);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Attendance.SessionStarted", $"{c.Teacher.FullName} started {duration}-minute session for {c.CourseName} {c.Section}");
        return Ok(ToSessionDto(session, c.Teacher.FullName));
    }

    [HttpGet("sessions/mine"), Authorize(Policy = Policies.TeacherOrAdmin)]
    public async Task<IActionResult> MySession()
    {
        var userId = User.GetUserId();
        var now = AppClock.UtcNow;
        var q = _db.AttendanceSessions.Include(s => s.Teacher).Where(s => !s.EndedEarly && s.ExpiresAt > now);
        if (User.GetRole() == Roles.Teacher) q = q.Where(s => s.TeacherId == userId);
        else q = q.Where(s => s.TeacherId == userId);
        var session = await q.OrderByDescending(s => s.StartedAt).FirstOrDefaultAsync();
        if (session == null) return Ok(null);
        return Ok(ToSessionDto(session, session.Teacher.FullName));
    }

    [HttpPost("sessions/{id:int}/end"), Authorize(Policy = Policies.TeacherOrAdmin)]
    public async Task<IActionResult> EndSession(int id)
    {
        var session = await _db.AttendanceSessions.FindAsync(id);
        if (session == null) return NotFound(new { message = "Session not found." });
        if (User.GetRole() == Roles.Teacher && session.TeacherId != User.GetUserId()) return Forbid();
        session.EndedEarly = true;
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Attendance.SessionEnded", $"Session #{id} ended");
        return Ok(new { message = "Session ended." });
    }

    private static AttendanceSessionDto ToSessionDto(AttendanceSession s, string teacherName) => new()
    {
        Id = s.Id,
        ClassId = s.ClassId ?? 0,
        CourseName = s.CourseName,
        Section = s.Section,
        TeacherName = teacherName,
        StartedAt = s.StartedAt,
        ExpiresAt = s.ExpiresAt,
        SecondsRemaining = Math.Max(0, (int)(s.ExpiresAt - AppClock.UtcNow).TotalSeconds)
    };

    /// <summary>The class QR for a running session (today's QR for that class).</summary>
    [HttpGet("sessions/{id:int}/qr"), Authorize(Policy = Policies.TeacherOrAdmin)]
    public async Task<ActionResult<SessionQrDto>> SessionQr(int id, [FromQuery] string? clientUrl = null)
    {
        var session = await _db.AttendanceSessions.FindAsync(id);
        if (session == null) return NotFound(new { message = "Session not found." });
        if (User.GetRole() == Roles.Teacher && session.TeacherId != User.GetUserId()) return Forbid();
        if (session.EndedEarly || session.ExpiresAt <= AppClock.UtcNow) return BadRequest(new { message = "This session has ended." });
        if (session.ClassId == null) return BadRequest(new { message = "This session has no class." });

        var cls = await _db.AcademicClasses.FindAsync(session.ClassId.Value);
        if (cls == null) return BadRequest(new { message = "This class no longer exists." });

        var code = BuildClassCode(cls, AppClock.DateOf(session.StartedAt));
        // If the Teacher is displaying the React app on a phone/LAN address, encode a
        // real attendance link so a student's phone camera opens EduSync directly.
        // The raw code is still returned for the in-app scanner/manual fallback.
        var payload = code;
        if (!string.IsNullOrWhiteSpace(clientUrl) && Uri.TryCreate(clientUrl, UriKind.Absolute, out var baseUri) &&
            (baseUri.Scheme == Uri.UriSchemeHttp || baseUri.Scheme == Uri.UriSchemeHttps))
        {
            payload = $"{clientUrl.TrimEnd('/')}?scan={Uri.EscapeDataString(code)}";
        }
        return Ok(new SessionQrDto { Code = code, SecondsRemaining = Math.Max(0, (int)(session.ExpiresAt - AppClock.UtcNow).TotalSeconds), ImageBase64 = _qr.GeneratePngBase64(payload, 14) });
    }

    /// <summary>Student scans the QR shown by their Teacher. The student must be enrolled in that exact class.</summary>
    [HttpPost("session-scan")]
    public async Task<IActionResult> SessionScan(SessionScanRequest request)
    {
        if (User.GetRole() != Roles.Student) return StatusCode(403, new { message = "Only Students can use a class attendance QR." });
        var parts = (request.Code ?? "").Trim().Split(':');
        if (parts.Length != 4 || parts[0] != "CLASS" || !TryParseYmd(parts[2], out var codeDate))
            return BadRequest(new { message = "This is not a class QR. Scan the QR shown by your Teacher." });
        var key = parts[1];
        if (parts[3] != ClassSignature(key, codeDate))
            return BadRequest(new { message = "This is not a valid class QR." });

        // The class is identified by its course + section (the QR key). Match against the active classes.
        var matching = (await _db.AcademicClasses.Where(c => c.IsActive).ToListAsync())
            .Where(c => ClassKey(c) == key)
            .ToList();
        if (matching.Count == 0) return BadRequest(new { message = "This class no longer exists." });
        var classIds = matching.Select(c => c.Id).ToList();

        // The Teacher must have attendance open for this class right now.
        var now = AppClock.UtcNow;
        var session = await _db.AttendanceSessions
            .Where(s => s.ClassId != null && classIds.Contains(s.ClassId.Value) && !s.EndedEarly && s.ExpiresAt > now)
            .OrderByDescending(s => s.StartedAt)
            .FirstOrDefaultAsync();
        if (session == null)
            return BadRequest(new { message = $"Attendance for {matching[0].CourseName} isn't open right now. Ask your Teacher to start it, then scan again." });

        // This must be the QR for today (or for the day the session started, if the class runs past midnight).
        if (codeDate != AppClock.Today && codeDate != AppClock.DateOf(session.StartedAt))
            return BadRequest(new { message = $"This QR is for {codeDate:dd MMM yyyy}, not today ({AppClock.Today:dd MMM yyyy}). Scan today's QR." });

        if (session.ClassId == null) return BadRequest(new { message = "This session has no class." });
        var sessionId = session.Id;

        var studentId = User.GetUserId();
        var enrolled = await _db.ClassEnrollments.AnyAsync(e => e.ClassId == session.ClassId && e.StudentId == studentId);
        if (!enrolled) return StatusCode(403, new { message = "You are not enrolled in this class." });

        var today = AppClock.Today;
        if (await _db.Attendance.AnyAsync(a => a.UserId == studentId && a.ClassId == session.ClassId && a.Date == today))
            return Conflict(new { message = "Your attendance for this class is already recorded today." });

        var student = await _db.Users.FindAsync(studentId);
        if (student == null || !student.IsActive) return BadRequest(new { message = "This account is disabled." });

        _db.Attendance.Add(new AttendanceRecord
        {
            UserId = studentId,
            ClassId = session.ClassId,
            Date = today,
            CheckInTime = AppClock.UtcNow,
            MarkedByUserId = session.TeacherId
        });
        try { await _db.SaveChangesAsync(); }
        catch (DbUpdateException) { return Conflict(new { message = "Your attendance for this class is already recorded today." }); }

        await _audit.LogAsync(User, "Attendance.SessionScan", $"{student.FullName} attended {session.CourseName} {session.Section}");
        return Ok(new { message = "Attendance recorded.", fullName = student.FullName, courseName = session.CourseName, section = session.Section, time = AppClock.UtcNow });
    }

    [HttpPost("correct"), Authorize(Policy = Policies.TeacherOrAdmin)]
    public async Task<IActionResult> Correct(CorrectionRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Reason)) return BadRequest(new { message = "A reason is required." });
        var user = await _db.Users.FindAsync(request.UserId);
        if (user == null) return NotFound(new { message = "Person not found." });
        if (!user.IsActive) return BadRequest(new { message = "This account is disabled." });
        if (User.GetRole() == Roles.Teacher && user.Role != Roles.Student) return Forbid();

        // Teacher corrections are class-scoped: the student must belong to one of their classes.
        var targetClass = await _db.AcademicClasses.FindAsync(request.ClassId);
        if (targetClass == null) return BadRequest(new { message = "Select a valid class." });
        if (User.GetRole() == Roles.Teacher && targetClass.TeacherId != User.GetUserId()) return Forbid();
        var enrolled = await _db.ClassEnrollments.AnyAsync(e => e.ClassId == request.ClassId && e.StudentId == user.Id);
        if (!enrolled) return BadRequest(new { message = "That student is not enrolled in this class." });

        var already = await _db.Attendance.AnyAsync(a => a.UserId == user.Id && a.ClassId == request.ClassId && a.Date == request.Date);
        if (already) return Conflict(new { message = "Attendance is already recorded for this date." });

        _db.Attendance.Add(new AttendanceRecord
        {
            UserId = user.Id,
            ClassId = request.ClassId,
            Date = request.Date,
            CheckInTime = AppClock.UtcNow,
            MarkedByUserId = User.GetUserId(),
            IsCorrected = true,
            CorrectionReason = request.Reason.Trim()
        });
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Attendance.Correct", $"{user.FullName} on {request.Date}: Absent → Present. Reason: {request.Reason.Trim()}");
        return Ok(new { message = $"{user.FullName}'s attendance corrected to Present." });
    }

    [HttpDelete("{id:int}"), Authorize(Policy = Policies.TeacherOrAdmin)]
    public async Task<IActionResult> Revert(int id)
    {
        var record = await _db.Attendance.Include(a => a.User).Include(a => a.Class).FirstOrDefaultAsync(a => a.Id == id);
        if (record == null) return NotFound(new { message = "Attendance record not found." });
        if (User.GetRole() == Roles.Teacher && (record.User.Role != Roles.Student || record.Class?.TeacherId != User.GetUserId())) return Forbid();
        _db.Attendance.Remove(record);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(User, "Attendance.Revert", $"{record.User.FullName} on {record.Date}: attendance undone");
        return Ok(new { message = "Attendance reverted." });
    }

    [HttpGet("my")]
    public async Task<ActionResult<List<AttendanceRecordDto>>> My()
    {
        var userId = User.GetUserId();
        var records = await _db.Attendance
            .Where(a => a.UserId == userId)
            .OrderByDescending(a => a.Date).ThenByDescending(a => a.CheckInTime)
            .Select(a => new AttendanceRecordDto
            {
                Id = a.Id, UserId = a.UserId, ClassId = a.ClassId,
                CourseName = a.Class != null ? a.Class.CourseName : null, Section = a.Class != null ? a.Class.Section : null,
                UserFullName = a.User.FullName, IdNumber = a.User.IdNumber, Date = a.Date,
                CheckInTime = a.CheckInTime, IsCorrected = a.IsCorrected, CorrectionReason = a.CorrectionReason
            }).ToListAsync();
        return Ok(records);
    }

    /// <summary>Report for a class. Teachers can only see their own class roster; Admin can choose any class.</summary>
    [HttpGet("report"), Authorize(Policy = Policies.TeacherOrAdmin)]
    public async Task<ActionResult<ReportDto>> Report([FromQuery] int classId, [FromQuery] DateOnly? date)
    {
        var c = await _db.AcademicClasses.FindAsync(classId);
        if (c == null) return NotFound(new { message = "Class not found." });
        if (User.GetRole() == Roles.Teacher && c.TeacherId != User.GetUserId()) return Forbid();

        var day = date ?? AppClock.Today;
        var present = await _db.Attendance
            .Where(a => a.ClassId == classId && a.Date == day)
            .Select(a => new AttendanceRecordDto
            {
                Id = a.Id, UserId = a.UserId, ClassId = a.ClassId,
                CourseName = a.Class != null ? a.Class.CourseName : null, Section = a.Class != null ? a.Class.Section : null,
                UserFullName = a.User.FullName, IdNumber = a.User.IdNumber, Date = a.Date,
                CheckInTime = a.CheckInTime, IsCorrected = a.IsCorrected, CorrectionReason = a.CorrectionReason
            }).ToListAsync();

        var presentIds = present.Select(p => p.UserId).ToHashSet();
        var absent = await _db.ClassEnrollments
            .Where(e => e.ClassId == classId && e.Student.IsActive && !presentIds.Contains(e.StudentId))
            .OrderBy(e => e.Student.FullName)
            .Select(e => new AbsentPersonDto { UserId = e.StudentId, FullName = e.Student.FullName, IdNumber = e.Student.IdNumber })
            .ToListAsync();

        return Ok(new ReportDto { Date = day, Role = Roles.Student, Present = present, Absent = absent });
    }

    /// <summary>Admin: who has checked in today (or on another date) among Teachers or Staff, and who
    /// hasn't. This is the once-a-day gate-QR attendance, separate from class attendance.</summary>
    [HttpGet("staff-report"), Authorize(Policy = Policies.AdminOnly)]
    public async Task<ActionResult<ReportDto>> StaffReport([FromQuery] DateOnly? date, [FromQuery] string role = Roles.Teacher)
    {
        if (role != Roles.Teacher && role != Roles.Staff)
            return BadRequest(new { message = "Choose Teacher or Staff." });

        var day = date ?? AppClock.Today;
        var present = await _db.Attendance
            .Where(a => a.ClassId == null && a.Date == day && a.User.Role == role)
            .OrderBy(a => a.CheckInTime)
            .Select(a => new AttendanceRecordDto
            {
                Id = a.Id, UserId = a.UserId, ClassId = a.ClassId,
                UserFullName = a.User.FullName, IdNumber = a.User.IdNumber, Date = a.Date,
                CheckInTime = a.CheckInTime, IsCorrected = a.IsCorrected, CorrectionReason = a.CorrectionReason
            }).ToListAsync();

        var presentIds = present.Select(p => p.UserId).ToList();
        var absent = await _db.Users
            .Where(u => u.Role == role && u.IsActive && !presentIds.Contains(u.Id))
            .OrderBy(u => u.FullName)
            .Select(u => new AbsentPersonDto { UserId = u.Id, FullName = u.FullName, IdNumber = u.IdNumber })
            .ToListAsync();

        return Ok(new ReportDto { Date = day, Role = role, Present = present, Absent = absent });
    }

    /// <summary>Admin: mark a Teacher/Staff member present for a day by hand (their gate QR scan failed).
    /// A reason is required and it is written to the Audit Log.</summary>
    [HttpPost("correct-daily"), Authorize(Policy = Policies.AdminOnly)]
    public async Task<IActionResult> CorrectDaily(DailyCorrectionRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Reason)) return BadRequest(new { message = "A reason is required." });

        var user = await _db.Users.FindAsync(request.UserId);
        if (user == null) return NotFound(new { message = "Person not found." });
        if (!user.IsActive) return BadRequest(new { message = "This account is disabled." });
        if (user.Role != Roles.Teacher && user.Role != Roles.Staff)
            return BadRequest(new { message = "Daily attendance is for Teachers and Staff. Students are marked per class." });

        if (await _db.Attendance.AnyAsync(a => a.UserId == user.Id && a.ClassId == null && a.Date == request.Date))
            return Conflict(new { message = $"{user.FullName} is already marked present for that day." });

        _db.Attendance.Add(new AttendanceRecord
        {
            UserId = user.Id,
            ClassId = null,
            Date = request.Date,
            CheckInTime = AppClock.UtcNow,
            MarkedByUserId = User.GetUserId(),
            IsCorrected = true,
            CorrectionReason = request.Reason.Trim()
        });
        try { await _db.SaveChangesAsync(); }
        catch (DbUpdateException) { return Conflict(new { message = $"{user.FullName} is already marked present for that day." }); }

        await _audit.LogAsync(User, "Attendance.Correct", $"{user.FullName} ({user.Role}) on {request.Date}: Absent → Present. Reason: {request.Reason.Trim()}");
        return Ok(new { message = $"{user.FullName} marked present." });
    }
}
