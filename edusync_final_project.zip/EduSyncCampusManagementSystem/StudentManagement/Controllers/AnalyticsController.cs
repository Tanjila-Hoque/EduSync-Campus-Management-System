using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Dtos;
using StudentManagement.Models;
using StudentManagement.Services;

namespace StudentManagement.Controllers;

/// <summary>
/// "Attendance Health" - turns raw scans into something people can act on.
///  - Student : per class, the attendance %, and the 75%-rule maths ("you can miss 3 more" /
///              "attend the next 4 to get back to 75%").
///  - Teacher : per class, an early-warning list of students slipping below 75% plus a trend.
///  - Admin   : same as a Teacher, for any class.
/// A class counts as "held" on every day it had attendance taken (a session was opened or a
/// record exists), so the percentage never goes over 100%.
/// </summary>
[ApiController]
[Route("api/analytics")]
[Authorize]
public class AnalyticsController : ControllerBase
{
    private const double Required = 0.75; // the usual exam-eligibility rule

    private readonly AppDbContext _db;
    public AnalyticsController(AppDbContext db) { _db = db; }

    private static string StatusOf(int held, double percent)
        => held == 0 ? "NoData" : percent >= 80 ? "Safe" : percent >= 75 ? "Watch" : "AtRisk";

    /// <summary>Most classes you can still miss and stay >= 75%:  attended / (held + x) >= 0.75.</summary>
    private static int CanMissOf(int attended, int held)
        => held == 0 ? 0 : Math.Max(0, (int)Math.Floor(attended / Required - held + 1e-9));

    /// <summary>Classes in a row you must attend to get back to 75%:  (attended + y) / (held + y) >= 0.75.</summary>
    private static int MustAttendOf(int attended, int held)
    {
        if (held == 0 || attended >= Required * held - 1e-9) return 0;
        return (int)Math.Ceiling((Required * held - attended) / (1 - Required) - 1e-9);
    }

    private static double Pct(int attended, int held) => held == 0 ? 0 : Math.Round(100.0 * attended / held, 1);

    /// <summary>For each class: the set of days it was held.</summary>
    private async Task<Dictionary<int, HashSet<DateOnly>>> HeldDays(List<int> classIds)
    {
        var result = classIds.ToDictionary(id => id, _ => new HashSet<DateOnly>());

        var sessions = await _db.AttendanceSessions
            .Where(s => s.ClassId != null && classIds.Contains(s.ClassId.Value))
            .Select(s => new { ClassId = s.ClassId!.Value, s.StartedAt })
            .ToListAsync();
        foreach (var s in sessions) result[s.ClassId].Add(AppClock.DateOf(s.StartedAt));

        var records = await _db.Attendance
            .Where(a => a.ClassId != null && classIds.Contains(a.ClassId.Value))
            .Select(a => new { ClassId = a.ClassId!.Value, a.Date })
            .Distinct()
            .ToListAsync();
        foreach (var r in records) result[r.ClassId].Add(r.Date);

        return result;
    }

    /// <summary>Student: my attendance health in every class I've joined.</summary>
    [HttpGet("my")]
    public async Task<ActionResult<MyHealthDto>> My()
    {
        if (User.GetRole() != Roles.Student) return StatusCode(403, new { message = "This view is for Students." });
        var me = User.GetUserId();

        var classes = await _db.ClassEnrollments
            .Where(e => e.StudentId == me && e.Class.IsActive)
            .Select(e => new { e.Class.Id, e.Class.CourseName, e.Class.Section })
            .ToListAsync();

        var ids = classes.Select(c => c.Id).ToList();
        var held = await HeldDays(ids);

        var mine = await _db.Attendance
            .Where(a => a.UserId == me && a.ClassId != null && ids.Contains(a.ClassId.Value))
            .Select(a => new { ClassId = a.ClassId!.Value, a.Date })
            .ToListAsync();
        var attendedBy = mine.GroupBy(x => x.ClassId).ToDictionary(g => g.Key, g => g.Select(x => x.Date).Distinct().Count());

        var rows = classes.Select(c =>
        {
            var h = held[c.Id].Count;
            var a = attendedBy.TryGetValue(c.Id, out var n) ? n : 0;
            var pct = Pct(a, h);
            return new ClassHealthDto
            {
                ClassId = c.Id, CourseName = c.CourseName, Section = c.Section, TeacherName = "",
                Held = h, Attended = a, Percent = pct, Status = StatusOf(h, pct),
                CanMiss = CanMissOf(a, h), MustAttend = MustAttendOf(a, h)
            };
        }).OrderBy(r => r.Percent).ThenBy(r => r.CourseName).ToList();

        var withData = rows.Where(r => r.Held > 0).ToList();
        return Ok(new MyHealthDto
        {
            AveragePercent = withData.Count == 0 ? 0 : Math.Round(withData.Average(r => r.Percent), 1),
            AtRiskCount = withData.Count(r => r.Status == "AtRisk"),
            Classes = rows
        });
    }

    /// <summary>Teacher (own class) / Admin (any class): who's slipping, the average, and the trend.</summary>
    [HttpGet("class/{id:int}"), Authorize(Policy = Policies.TeacherOrAdmin)]
    public async Task<ActionResult<ClassInsightsDto>> ClassInsights(int id)
    {
        var c = await _db.AcademicClasses.Include(x => x.Teacher).FirstOrDefaultAsync(x => x.Id == id);
        if (c == null) return NotFound(new { message = "Class not found." });
        if (User.GetRole() == Roles.Teacher && c.TeacherId != User.GetUserId()) return Forbid();

        var heldDays = (await HeldDays(new List<int> { id }))[id];
        var held = heldDays.Count;

        var students = await _db.ClassEnrollments
            .Where(e => e.ClassId == id && e.Student.IsActive)
            .Select(e => new { e.StudentId, e.Student.FullName, e.Student.IdNumber })
            .ToListAsync();

        var records = await _db.Attendance
            .Where(a => a.ClassId == id)
            .Select(a => new { a.UserId, a.Date })
            .ToListAsync();
        var attendedBy = records.GroupBy(r => r.UserId).ToDictionary(g => g.Key, g => g.Select(r => r.Date).Distinct().Count());

        var rows = students.Select(s =>
        {
            var a = attendedBy.TryGetValue(s.StudentId, out var n) ? n : 0;
            var pct = Pct(a, held);
            return new StudentHealthRowDto
            {
                StudentId = s.StudentId, FullName = s.FullName, IdNumber = s.IdNumber,
                Attended = a, Percent = pct, Status = StatusOf(held, pct), MustAttend = MustAttendOf(a, held)
            };
        }).OrderBy(r => r.Percent).ThenBy(r => r.FullName).ToList();

        var perDay = records.GroupBy(r => r.Date).ToDictionary(g => g.Key, g => g.Select(r => r.UserId).Distinct().Count());
        var trend = heldDays.OrderByDescending(d => d).Take(10).OrderBy(d => d)
            .Select(d => new TrendPointDto { Date = d, Present = perDay.TryGetValue(d, out var p) ? p : 0 })
            .ToList();

        return Ok(new ClassInsightsDto
        {
            ClassId = c.Id, CourseName = c.CourseName, Section = c.Section, TeacherName = c.Teacher.FullName,
            Held = held, StudentCount = rows.Count,
            AveragePercent = rows.Count == 0 || held == 0 ? 0 : Math.Round(rows.Average(r => r.Percent), 1),
            AtRiskCount = rows.Count(r => r.Status == "AtRisk"),
            Trend = trend, Students = rows
        });
    }
}
