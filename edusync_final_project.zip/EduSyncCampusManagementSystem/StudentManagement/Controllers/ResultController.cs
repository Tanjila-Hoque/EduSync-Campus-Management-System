using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Dtos;
using StudentManagement.Models;
using StudentManagement.Services;

namespace StudentManagement.Controllers;

[ApiController]
[Route("api/results")]
[Authorize]
public class ResultController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IAuditLogger _audit;
    public ResultController(AppDbContext db, IAuditLogger audit) { _db=db; _audit=audit; }

    private async Task<(double marks,double percent)> GetAttendanceMarksAsync(int studentId, string courseName)
    {
        var classes = await _db.AcademicClasses
            .Where(c => c.IsActive && c.CourseName == courseName &&
                        _db.ClassEnrollments.Any(e => e.ClassId == c.Id && e.StudentId == studentId))
            .Select(c => c.Id).ToListAsync();
        if (classes.Count == 0) return (0,0);

        var held = await _db.AttendanceSessions.CountAsync(s => s.ClassId != null && classes.Contains(s.ClassId.Value));
        if (held == 0) return (0,0);
        var attended = await _db.Attendance.CountAsync(a => a.UserId == studentId && a.ClassId != null && classes.Contains(a.ClassId.Value));
        var pct = Math.Min(100, attended * 100.0 / held);
        return (Math.Round(pct * 10.0 / 100.0, 2), Math.Round(pct, 2));
    }

    private async Task<ResultEntryDto> ToDtoAsync(ResultEntry r)
    {
        var (attMarks, attPct) = await GetAttendanceMarksAsync(r.StudentId, r.CourseName);
        r.AttendanceMarks=attMarks;
        return new ResultEntryDto {
            Id=r.Id, StudentId=r.StudentId, StudentName=r.Student.FullName, StudentIdNumber=r.Student.IdNumber,
            CourseName=r.CourseName, Mid=r.Mid, Final=r.Final, Assignment=r.Assignment,
            AttendanceMarks=attMarks, AttendancePercent=attPct, Total=r.Total, Grade=r.Grade, CreatedAt=r.CreatedAt
        };
    }

    [HttpGet]
    public async Task<ActionResult<List<ResultEntryDto>>> Index([FromQuery] int? studentId)
    {
        var role=User.GetRole();
        if(role==Roles.Staff)return Forbid();
        int targetId;
        if(role==Roles.Student) targetId=User.GetUserId();
        else if(role is Roles.Teacher or Roles.Admin) {
            if(studentId is null)return BadRequest(new{message="Pass ?studentId= to view a student's results."});
            targetId=studentId.Value;
        } else return Forbid();

        var results=await _db.ResultEntries.Include(r=>r.Student).Where(r=>r.StudentId==targetId).OrderByDescending(r=>r.CreatedAt).ToListAsync();
        var output=new List<ResultEntryDto>();
        foreach(var r in results) output.Add(await ToDtoAsync(r));
        return Ok(output);
    }

    [HttpPost, Authorize(Policy = Policies.TeacherOrAdmin)]
    public async Task<ActionResult<ResultEntryDto>> Create(ResultEntryCreateDto dto)
    {
        if(!ModelState.IsValid)return ValidationProblem(ModelState);
        var student=await _db.Users.FindAsync(dto.StudentId);
        if(student==null || student.Role!=Roles.Student)return BadRequest(new{message="That student was not found."});

        var entry=new ResultEntry {StudentId=dto.StudentId,CourseName=dto.CourseName.Trim(),Mid=dto.Mid,Final=dto.Final,Assignment=dto.Assignment,EnteredByUserId=User.GetUserId()};
        _db.ResultEntries.Add(entry); await _db.SaveChangesAsync();
        await _audit.LogAsync(User,"Result.Create",$"Entered {entry.CourseName} result for {student.FullName}");
        entry.Student=student;
        return Ok(await ToDtoAsync(entry));
    }

    [HttpDelete("{id:int}"), Authorize(Policy = Policies.TeacherOrAdmin)]
    public async Task<IActionResult> Delete(int id)
    {
        var entry=await _db.ResultEntries.Include(r=>r.Student).FirstOrDefaultAsync(r=>r.Id==id);
        if(entry==null)return NotFound();
        _db.ResultEntries.Remove(entry); await _db.SaveChangesAsync();
        await _audit.LogAsync(User,"Result.Delete",$"Removed {entry.CourseName} result for {entry.Student.FullName}");
        return NoContent();
    }
}
