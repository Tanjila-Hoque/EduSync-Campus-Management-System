using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Dtos;
using StudentManagement.Services;

namespace StudentManagement.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _auth;
    private readonly AppDbContext _db;

    public AuthController(IAuthService auth, AppDbContext db)
    {
        _auth = auth;
        _db = db;
    }

    /// <summary>Sign up page -> always creates a Student account.</summary>
    [HttpPost("register"), AllowAnonymous]
    public async Task<ActionResult<AuthResponseDto>> Register(RegisterDto dto)
    {
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var (user, error) = await _auth.RegisterAsync(dto);
        if (user == null) return BadRequest(new { message = error });

        var tokens = await _auth.IssueTokensAsync(user);
        return Ok(tokens);
    }

    /// <summary>Login page.</summary>
    [HttpPost("login"), AllowAnonymous]
    public async Task<ActionResult<AuthResponseDto>> Login(LoginDto dto)
    {
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var (user, error) = await _auth.ValidateAsync(dto.Username.Trim(), dto.Password);
        if (user == null) return Unauthorized(new { message = error });

        var tokens = await _auth.IssueTokensAsync(user, dto.RememberMe);
        return Ok(tokens);
    }

    /// <summary>Called silently by the React app when the access token is close to expiring.</summary>
    [HttpPost("refresh"), AllowAnonymous]
    public async Task<ActionResult<AuthResponseDto>> Refresh(RefreshRequestDto dto)
    {
        var (user, error) = await _auth.RefreshAsync(dto.RefreshToken);
        if (user == null) return Unauthorized(new { message = error });

        // Preserve the original session choice while rotating the refresh token.
        var remember = user.RefreshTokenExpiresAt.HasValue &&
                       user.RefreshTokenExpiresAt.Value - DateTime.UtcNow > TimeSpan.FromDays(1);
        var tokens = await _auth.IssueTokensAsync(user, remember);
        return Ok(tokens);
    }

    [HttpPost("logout"), Authorize]
    public async Task<IActionResult> Logout()
    {
        await _auth.RevokeRefreshTokenAsync(User.GetUserId());
        return NoContent();
    }

    [HttpGet("me"), Authorize]
    public async Task<ActionResult<UserSummaryDto>> Me()
    {
        var user = await _db.Users.FindAsync(User.GetUserId());
        if (user == null) return NotFound();

        return Ok(new UserSummaryDto
        {
            Id = user.Id,
            FullName = user.FullName,
            Username = user.Username,
            Role = user.Role,
            Email = user.Email,
            IdNumber = user.IdNumber,
            Department = user.Department,
            PhotoPath = user.PhotoPath
        });
    }

    [HttpPost("forgot-password"), AllowAnonymous]
    public async Task<IActionResult> ForgotPassword(ForgotPasswordDto dto)
    {
        if (!ModelState.IsValid) return ValidationProblem(ModelState);
        if (!PasswordHasher.IsStrongEnough(dto.NewPassword))
            return BadRequest(new { message = "Use at least 8 characters with a letter and a number." });
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Username == dto.Username.Trim());
        if (user == null || !user.IsActive)
            return BadRequest(new { message = "Invalid username or verification code." });
        if (string.IsNullOrWhiteSpace(user.PasswordResetCodeHash) ||
            user.PasswordResetCodeExpiresAt is null ||
            user.PasswordResetCodeExpiresAt < DateTime.UtcNow ||
            !PasswordHasher.Verify(dto.VerificationCode.Trim(), user.PasswordResetCodeHash))
            return BadRequest(new { message = "Invalid or expired verification code. Ask an Admin for a new code." });

        user.PasswordHash = PasswordHasher.Hash(dto.NewPassword);
        user.PasswordResetCodeHash = null;
        user.PasswordResetCodeExpiresAt = null;
        user.FailedLoginCount = 0; user.LockoutEnd = null;
        user.RefreshToken = null; user.RefreshTokenExpiresAt = null;
        await _db.SaveChangesAsync();
        return Ok(new { message = "Password reset successfully. You can now sign in." });
    }

    [HttpPost("change-password"), Authorize]
    public async Task<IActionResult> ChangePassword(ChangePasswordDto dto)
    {
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == User.GetUserId());
        if (user == null) return NotFound();

        if (!PasswordHasher.Verify(dto.CurrentPassword, user.PasswordHash))
            return BadRequest(new { message = "Current password is wrong." });

        if (!PasswordHasher.IsStrongEnough(dto.NewPassword))
            return BadRequest(new { message = "Use at least 8 characters with a letter and a number." });

        user.PasswordHash = PasswordHasher.Hash(dto.NewPassword);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
