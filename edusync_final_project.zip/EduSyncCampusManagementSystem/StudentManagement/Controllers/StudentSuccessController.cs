using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Models;
using StudentManagement.Services;

namespace StudentManagement.Controllers;

[ApiController]
[Route("api/student-success")]
[Authorize]
public class StudentSuccessController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly GeminiService _gemini;
    public StudentSuccessController(AppDbContext db, GeminiService gemini) { _db = db; _gemini = gemini; }

    public sealed record RadarStudent(int StudentId, string Name, string? StudentNumber, double AttendancePercent,
        double AcademicAverage, int AttendanceSessions, int ResultCount, int RiskScore, string RiskLevel,
        string[] Reasons, string Recommendation);
    public sealed record RadarResponse(int TotalStudents, int AtRisk, int NeedsAttention, double AverageAttendance,
        double AverageAcademic, List<RadarStudent> Students, string? PersonalizedPlan, bool AiGenerated);

    [HttpGet("radar")]
    public async Task<IActionResult> Radar(CancellationToken ct)
    {
        var uid = User.GetUserId();
        var role = User.GetRole();
        if (role is not (Roles.Admin or Roles.Teacher or Roles.Student))
            return Forbid();

        var peopleQuery = _db.Users.AsNoTracking().Where(u => u.IsActive && u.Role == Roles.Student);
        if (role == Roles.Student) peopleQuery = peopleQuery.Where(u => u.Id == uid);
        if (role == Roles.Teacher)
        {
            var taught = _db.AcademicClasses.Where(c => c.TeacherId == uid).Select(c => c.Id);
            var enrolled = _db.ClassEnrollments.Where(e => taught.Contains(e.ClassId)).Select(e => e.StudentId);
            peopleQuery = peopleQuery.Where(u => enrolled.Contains(u.Id));
        }
        var people = await peopleQuery.Select(u => new { u.Id, u.FullName, u.IdNumber }).ToListAsync(ct);
        if (people.Count == 0) return Ok(new RadarResponse(0,0,0,0,0,new(),null,false));

        var ids = people.Select(p => p.Id).ToList();
        var resultRows = await _db.ResultEntries.AsNoTracking().Where(r => ids.Contains(r.StudentId))
            .Select(r => new { r.StudentId, r.Mid, r.Final, r.Assignment }).ToListAsync(ct);
        var attendanceRows = await _db.Attendance.AsNoTracking().Where(a => ids.Contains(a.UserId) && a.ClassId != null)
            .Select(a => new { a.UserId, a.ClassId, a.Date }).Distinct().ToListAsync(ct);
        var sessions = await _db.AttendanceSessions.AsNoTracking().Where(s => s.ClassId != null)
            .Select(s => new { ClassId = s.ClassId!.Value, s.StartedAt }).ToListAsync(ct);
        var heldDates = sessions.GroupBy(s => s.ClassId).ToDictionary(g => g.Key, g => g.Select(x => AppClock.DateOf(x.StartedAt)).ToHashSet());
        foreach (var r in attendanceRows)
        {
            if (!heldDates.ContainsKey(r.ClassId!.Value)) heldDates[r.ClassId.Value] = new HashSet<DateOnly>();
            heldDates[r.ClassId.Value].Add(r.Date);
        }
        var enrollment = await _db.ClassEnrollments.AsNoTracking().Where(e => ids.Contains(e.StudentId))
            .Select(e => new { e.StudentId, e.ClassId }).ToListAsync(ct);

        var rows = new List<RadarStudent>();
        foreach (var p in people)
        {
            var enrolledClasses = enrollment.Where(e => e.StudentId == p.Id).Select(e => e.ClassId).Distinct().ToList();
            var held = enrolledClasses.Sum(cid => heldDates.TryGetValue(cid, out var ds) ? ds.Count : 0);
            var attended = attendanceRows.Where(a => a.UserId == p.Id && a.ClassId.HasValue && enrolledClasses.Contains(a.ClassId.Value)).Select(a => (a.ClassId, a.Date)).Distinct().Count();
            var attPct = held == 0 ? 100 : Math.Round(100.0 * Math.Min(attended, held) / held, 1);
            var grades = resultRows.Where(r => r.StudentId == p.Id).Select(r => Math.Clamp((r.Mid + r.Final + r.Assignment) / 100.0 * 100.0, 0, 100)).ToList();
            var avg = grades.Count == 0 ? 0 : Math.Round(grades.Average(), 1);
            var reasons = new List<string>();
            var score = 0;
            if (held > 0 && attPct < 75) { score += 45; reasons.Add($"Attendance is {attPct}% (below the 75% support threshold)."); }
            else if (held > 0 && attPct < 85) { score += 20; reasons.Add($"Attendance is {attPct}%, close to the 75% threshold."); }
            if (grades.Count > 0 && avg < 40) { score += 45; reasons.Add($"Academic average is {avg}%, indicating substantial academic support may be needed."); }
            else if (grades.Count > 0 && avg < 60) { score += 25; reasons.Add($"Academic average is {avg}%, below the 60% watch threshold."); }
            if (grades.Count == 0) reasons.Add("No result records are available yet; academic risk cannot be assessed from grades.");
            if (held == 0) reasons.Add("No class attendance sessions are recorded for this student's enrolled classes.");
            var level = score >= 45 ? "At risk" : score >= 20 ? "Needs attention" : "On track";
            var rec = score >= 45 ? "Arrange a supportive check-in, review missed classes, and create a short weekly study plan." :
                score >= 20 ? "Monitor progress weekly and set a specific attendance or coursework goal." :
                "Maintain current habits and review progress before upcoming assessments.";
            rows.Add(new RadarStudent(p.Id,p.FullName,p.IdNumber,attPct,avg,held,grades.Count,score,level,reasons.ToArray(),rec));
        }
        rows = rows.OrderByDescending(x => x.RiskScore).ThenBy(x => x.AttendancePercent).ToList();
        string? plan = null; var ai = false;
        if (role == Roles.Student && rows.Count > 0)
        {
            var me = rows[0];
            var prompt = "You are EduSync's supportive student-success coach. Based ONLY on these real measured facts, give a personalized 7-day study and attendance plan in clear concise bullet points. Do not shame, diagnose, invent course names or claim certainty. State when data is missing. Facts: " +
                $"attendance {me.AttendancePercent}% across {me.AttendanceSessions} recorded class sessions; academic average {me.AcademicAverage}% across {me.ResultCount} result records; reasons: {string.Join(" ",me.Reasons)}";
            try { plan = await _gemini.GenerateAsync(prompt, ct); ai = !string.IsNullOrWhiteSpace(plan); }
            catch (Exception) { plan = me.Recommendation + " Track attendance and review your latest marked results; ask your teacher for help with difficult topics."; }
        }
        return Ok(new RadarResponse(rows.Count,rows.Count(x=>x.RiskLevel=="At risk"),rows.Count(x=>x.RiskLevel=="Needs attention"),
            Math.Round(rows.Average(x=>x.AttendancePercent),1),Math.Round(rows.Where(x=>x.ResultCount>0).Select(x=>x.AcademicAverage).DefaultIfEmpty(0).Average(),1),rows,plan,ai));
    }

    [HttpPost("notify")]
    [Authorize(Policy = Policies.TeacherOrAdmin)]
    public async Task<IActionResult> NotifyAtRisk(CancellationToken ct)
    {
        // Build the same rule-based risk signals from live records, then persist only today's
        // actionable alerts. A unique daily title/link check prevents duplicate refresh spam.
        var peopleQuery = _db.Users.Where(u => u.IsActive && u.Role == Roles.Student);
        if (User.GetRole() == Roles.Teacher) { var taught = _db.AcademicClasses.Where(c => c.TeacherId == User.GetUserId()).Select(c => c.Id); var enrolled = _db.ClassEnrollments.Where(e => taught.Contains(e.ClassId)).Select(e => e.StudentId); peopleQuery = peopleQuery.Where(u => enrolled.Contains(u.Id)); }
        var people = await peopleQuery.ToListAsync(ct);
        var sessions = await _db.AttendanceSessions.Where(s => s.ClassId != null).Select(s => new { ClassId = s.ClassId!.Value, s.StartedAt }).ToListAsync(ct);
        var records = await _db.Attendance.Where(a => a.ClassId != null).Select(a => new { a.UserId, ClassId = a.ClassId!.Value, a.Date }).ToListAsync(ct);
        var enrollments = await _db.ClassEnrollments.Select(e => new { e.StudentId, e.ClassId }).ToListAsync(ct);
        var results = await _db.ResultEntries.Select(r => new { r.StudentId, r.Mid, r.Final, r.Assignment }).ToListAsync(ct);
        var held = sessions.GroupBy(s=>s.ClassId).ToDictionary(g=>g.Key,g=>g.Select(x=>AppClock.DateOf(x.StartedAt)).ToHashSet());
        foreach(var r in records) { if(!held.ContainsKey(r.ClassId)) held[r.ClassId]=new HashSet<DateOnly>(); held[r.ClassId].Add(r.Date); }
        var today = DateTime.UtcNow.Date;
        var created=0;
        foreach(var student in people)
        {
            var classes=enrollments.Where(e=>e.StudentId==student.Id).Select(e=>e.ClassId).Distinct().ToList();
            var total=classes.Sum(c=>held.TryGetValue(c,out var ds)?ds.Count:0);
            var attended=records.Where(r=>r.UserId==student.Id).Select(r=>(r.ClassId,r.Date)).Distinct().Count();
            var attendance=total==0?100:100.0*Math.Min(total,attended)/total;
            var marks=results.Where(r=>r.StudentId==student.Id).Select(r=>r.Mid+r.Final+r.Assignment).ToList();
            var weak=marks.Count>0 && marks.Average()<40;
            if ((total>0 && attendance<75) || weak)
            {
                var title="Student success check-in";
                var exists=await _db.Notifications.AnyAsync(n=>n.UserId==student.Id && n.Title==title && n.CreatedAt>=today,ct);
                if(!exists) { _db.Notifications.Add(new InAppNotification { UserId=student.Id, Title=title,
                    Message=$"Your current attendance is {(total==0?"not yet measurable":Math.Round(attendance,1)+"%")} and academic average is {(marks.Count==0?"not available":Math.Round(marks.Average(),1)+"%")}. Review your study plan and contact your teacher if you need support.",
                    Kind="support",Link="/insights" }); created++; }
            }
        }
        await _db.SaveChangesAsync(ct);
        return Ok(new { created, message = $"Created {created} new student support notification(s)." });
    }
}
