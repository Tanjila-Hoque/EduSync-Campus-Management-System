using System.ComponentModel.DataAnnotations;

namespace StudentManagement.Dtos;

public class NoticeDto
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string Body { get; set; } = "";
    public string? AudienceRole { get; set; }
    public int? TargetClassId { get; set; }
    public string? TargetClassName { get; set; }
    public string CreatedByName { get; set; } = "";
    public DateTime CreatedAt { get; set; }
}

public class NoticeCreateDto
{
    [Required, StringLength(150)]
    public string Title { get; set; } = "";

    [Required]
    public string Body { get; set; } = "";

    /// <summary>Admin-only role-wide audience. Teachers cannot broadcast to all students.</summary>
    public string? AudienceRole { get; set; }

    /// <summary>Teacher-only: the teacher's own class whose enrolled students receive it.</summary>
    public int? TargetClassId { get; set; }
}
