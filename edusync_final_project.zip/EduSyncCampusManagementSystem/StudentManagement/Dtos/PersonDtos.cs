using System.ComponentModel.DataAnnotations;
using StudentManagement.Models;

namespace StudentManagement.Dtos;

public class PersonDto
{
    public int Id { get; set; }
    public string FullName { get; set; } = "";
    public string Username { get; set; } = "";
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public string Role { get; set; } = "";
    public string? IdNumber { get; set; }
    public string? Department { get; set; }
    public string? PhotoPath { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class PersonCreateDto
{
    [Required, StringLength(100)]
    public string FullName { get; set; } = "";

    [Required, StringLength(50)]
    [RegularExpression(@"^[a-zA-Z0-9._-]+$", ErrorMessage = "Use letters, numbers, dot, dash or underscore only.")]
    public string Username { get; set; } = "";

    [EmailAddress]
    public string? Email { get; set; }
    public string? Phone { get; set; }

    [Required]
    public string Role { get; set; } = Roles.Student;

    public string? IdNumber { get; set; }
    public string? Department { get; set; }

    // Admin-created accounts: no password rules - any characters, any length (just not empty).
    [Required(AllowEmptyStrings = false, ErrorMessage = "Enter a password."), DataType(DataType.Password)]
    public string Password { get; set; } = "";

    public bool IsActive { get; set; } = true;
}

public class PasswordResetCodeDto
{
    [Required] public int UserId { get; set; }
}

public class PersonUpdateDto
{
    [Required, StringLength(100)]
    public string FullName { get; set; } = "";

    [EmailAddress]
    public string? Email { get; set; }
    public string? Phone { get; set; }

    [Required]
    public string Role { get; set; } = Roles.Student;

    public string? IdNumber { get; set; }
    public string? Department { get; set; }
    public bool IsActive { get; set; } = true;

    /// <summary>Optional - only set this to reset the person's password.</summary>
    [DataType(DataType.Password)]
    public string? Password { get; set; }
}
