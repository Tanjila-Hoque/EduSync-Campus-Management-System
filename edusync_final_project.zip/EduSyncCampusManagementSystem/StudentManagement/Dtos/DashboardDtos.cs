namespace StudentManagement.Dtos;

public class DashboardSummaryDto
{
    public int TotalStudents { get; set; }
    public int TotalTeachers { get; set; }
    public int TotalStaff { get; set; }
    public int TodayAttendanceCount { get; set; }
    public int NoticeCount { get; set; }
    public List<AuditLogDto> RecentActivity { get; set; } = new();
}
