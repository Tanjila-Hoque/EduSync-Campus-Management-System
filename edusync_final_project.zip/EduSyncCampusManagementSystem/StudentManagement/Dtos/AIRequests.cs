using System.ComponentModel.DataAnnotations;
namespace StudentManagement.Dtos;
public class NoticeAIRequest
{
    [Required, StringLength(2000)] public string Topic { get; set; } = "";
    [Required] public string Language { get; set; } = "English";
}
public class ChatAIRequest
{
    [Required, StringLength(1000)] public string Question { get; set; } = "";
    /// <summary>Optional previous turns so the bot remembers the conversation. Role: "user" or "model".</summary>
    public List<ChatTurn>? History { get; set; }
}
public class ChatTurn
{
    public string Role { get; set; } = "user";
    [StringLength(4000)] public string Text { get; set; } = "";
}
