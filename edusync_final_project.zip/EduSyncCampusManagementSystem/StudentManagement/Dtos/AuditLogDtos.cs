namespace StudentManagement.Dtos;

public class AuditLogDto
{
    public int Id { get; set; }
    public string ActorName { get; set; } = "";
    public string ActorRole { get; set; } = "";
    public string Action { get; set; } = "";
    public string Details { get; set; } = "";
    public DateTime Timestamp { get; set; }
}
