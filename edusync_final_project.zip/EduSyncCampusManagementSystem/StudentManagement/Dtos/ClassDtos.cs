using System.ComponentModel.DataAnnotations;

namespace StudentManagement.Dtos;

public class AcademicClassDto
{
    public int Id { get; set; }
    public string CourseName { get; set; } = "";
    public string Section { get; set; } = "";
    public string Department { get; set; } = "";
    public string Room { get; set; } = "";
    public int TeacherId { get; set; }
    public string TeacherName { get; set; } = "";
    public bool IsActive { get; set; }
    public int StudentCount { get; set; }

    /// <summary>For a Student browsing classes: have they joined this one?</summary>
    public bool Enrolled { get; set; }
}

public class AcademicClassCreateDto
{
    [Required, StringLength(100)] public string CourseName { get; set; } = "";
    [StringLength(30)] public string Section { get; set; } = "";
    [StringLength(100)] public string Department { get; set; } = "";
    [StringLength(50)] public string Room { get; set; } = "";
    [Required] public int TeacherId { get; set; }
}

public class ClassEnrollmentDto
{
    public int ClassId { get; set; }
    public int StudentId { get; set; }
    public string StudentName { get; set; } = "";
    public string? StudentIdNumber { get; set; }
}
