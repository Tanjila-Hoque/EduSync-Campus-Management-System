using System.ComponentModel.DataAnnotations;

namespace StudentManagement.Dtos;

public class ResultEntryDto
{
    public int Id { get; set; }
    public int StudentId { get; set; }
    public string StudentName { get; set; } = "";
    public string? StudentIdNumber { get; set; }
    public string CourseName { get; set; } = "";
    public double Mid { get; set; }
    public double Final { get; set; }
    public double Assignment { get; set; }
    public double AttendanceMarks { get; set; }
    public double AttendancePercent { get; set; }
    public double Total { get; set; }
    public string Grade { get; set; } = "";
    public DateTime CreatedAt { get; set; }
}

public class ResultEntryCreateDto
{
    [Required] public int StudentId { get; set; }
    [Required, StringLength(100)] public string CourseName { get; set; } = "";
    [Range(0, 100)] public double Mid { get; set; }
    [Range(0, 100)] public double Final { get; set; }
    [Range(0, 100)] public double Assignment { get; set; }
}
