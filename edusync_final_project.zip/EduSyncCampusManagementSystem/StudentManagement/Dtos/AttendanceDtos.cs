namespace StudentManagement.Dtos;

/// <summary>Teacher/Admin corrects a person that shows as Absent (e.g. QR failed but they
/// were actually present). Reason is required - it's what shows up in the Audit Log.</summary>
public record CorrectionRequest(int UserId, int ClassId, DateOnly Date, string? Reason);

/// <summary>Admin marks a Teacher/Staff member present for the day by hand (their gate QR scan failed).</summary>
public record DailyCorrectionRequest(int UserId, DateOnly Date, string? Reason);

/// <summary>Faculty/Staff self check-in: scans the shared daily entrance QR (displayed by
/// Admin/Staff at the gate) with their own phone camera. Students never use this - see
/// SessionScan instead, which is how a Student's attendance gets recorded.</summary>
public record CheckInRequest(string? Code);

/// <summary>Today's Teacher/Staff check-in QR (it changes every day).</summary>
public class CheckInCodeDto
{
    public string Code { get; set; } = "";
    public DateOnly Date { get; set; }
    public string ImageBase64 { get; set; } = "";
}

/// <summary>Teacher/Admin starts a time-limited attendance session for one course+section.</summary>
/// Section and DurationMinutes are optional. They MUST be nullable: with nullable reference types
/// on, a non-nullable string is implicitly [Required] and an empty "" (what the form sends when
/// Section is left blank) is converted to null -> the API answered 400 "Section field is required".
public record StartSessionRequest(int ClassId, int? DurationMinutes);

public class AttendanceSessionDto
{
    public int Id { get; set; }
    public string CourseName { get; set; } = "";
    public string Section { get; set; } = "";
    public int ClassId { get; set; }
    public string TeacherName { get; set; } = "";
    public DateTime StartedAt { get; set; }
    public DateTime ExpiresAt { get; set; }
    public int SecondsRemaining { get; set; }
}

/// <summary>A Student scans the class QR from their own panel while a session is open.</summary>
public record SessionScanRequest(string? Code);

/// <summary>The class QR for a running session (fixed for the whole session, so it can go on a projector).</summary>
public class SessionQrDto
{
    public string Code { get; set; } = "";
    public int SecondsRemaining { get; set; }
    public string ImageBase64 { get; set; } = "";
}

public class AttendanceRecordDto
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public int? ClassId { get; set; }
    public string? CourseName { get; set; }
    public string? Section { get; set; }
    public string UserFullName { get; set; } = "";
    public string? IdNumber { get; set; }
    public DateOnly Date { get; set; }
    public DateTime CheckInTime { get; set; }
    public bool IsCorrected { get; set; }
    public string? CorrectionReason { get; set; }
}

public class AbsentPersonDto
{
    public int UserId { get; set; }
    public string FullName { get; set; } = "";
    public string? IdNumber { get; set; }
}

public class ReportDto
{
    public DateOnly Date { get; set; }
    public string Role { get; set; } = "";
    public List<AttendanceRecordDto> Present { get; set; } = new();
    public List<AbsentPersonDto> Absent { get; set; } = new();
}
