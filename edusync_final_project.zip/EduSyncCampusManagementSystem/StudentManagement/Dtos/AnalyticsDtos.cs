namespace StudentManagement.Dtos;

/// <summary>One class's attendance "health" for one student: how they stand against the 75% rule
/// and exactly how many classes they can still miss (or must attend to recover).</summary>
public class ClassHealthDto
{
    public int ClassId { get; set; }
    public string CourseName { get; set; } = "";
    public string Section { get; set; } = "";
    public string TeacherName { get; set; } = "";

    /// <summary>Classes held so far (days on which this class had attendance taken).</summary>
    public int Held { get; set; }
    public int Attended { get; set; }
    public double Percent { get; set; }

    /// <summary>NoData | Safe (80%+) | Watch (75-80%) | AtRisk (below 75%)</summary>
    public string Status { get; set; } = "NoData";

    /// <summary>When at/above 75%: how many more classes can be missed and still stay at 75%.</summary>
    public int CanMiss { get; set; }

    /// <summary>When below 75%: how many classes in a row must be attended to get back to 75%.</summary>
    public int MustAttend { get; set; }
}

public class MyHealthDto
{
    public double AveragePercent { get; set; }
    public int AtRiskCount { get; set; }
    public List<ClassHealthDto> Classes { get; set; } = new();
}

public class StudentHealthRowDto
{
    public int StudentId { get; set; }
    public string FullName { get; set; } = "";
    public string? IdNumber { get; set; }
    public int Attended { get; set; }
    public double Percent { get; set; }
    public string Status { get; set; } = "NoData";
    public int MustAttend { get; set; }
}

public class TrendPointDto
{
    public DateOnly Date { get; set; }
    public int Present { get; set; }
}

public class ClassInsightsDto
{
    public int ClassId { get; set; }
    public string CourseName { get; set; } = "";
    public string Section { get; set; } = "";
    public string TeacherName { get; set; } = "";
    public int Held { get; set; }
    public int StudentCount { get; set; }
    public double AveragePercent { get; set; }
    public int AtRiskCount { get; set; }
    public List<TrendPointDto> Trend { get; set; } = new();
    /// <summary>Lowest attendance first, so the students who need attention are on top.</summary>
    public List<StudentHealthRowDto> Students { get; set; } = new();
}
