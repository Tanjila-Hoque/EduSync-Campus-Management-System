using System.ComponentModel.DataAnnotations;

namespace StudentManagement.Dtos;

// ---- Signup (public self-registration, always creates a Student account) ----
public class RegisterDto
{
    [Required(ErrorMessage = "Enter your full name."), StringLength(100)]
    public string FullName { get; set; } = "";

    [Required(ErrorMessage = "Choose a username."), StringLength(50)]
    [RegularExpression(@"^[a-zA-Z0-9._-]+$", ErrorMessage = "Use letters, numbers, dot, dash or underscore only.")]
    public string Username { get; set; } = "";

    [EmailAddress]
    public string? Email { get; set; }

    public string? Phone { get; set; }

    [Required(ErrorMessage = "Enter a password."), DataType(DataType.Password)]
    public string Password { get; set; } = "";

    [Required, DataType(DataType.Password), Compare(nameof(Password), ErrorMessage = "Passwords do not match.")]
    public string ConfirmPassword { get; set; } = "";

    /// <summary>Roll number the student wants to register with (optional, admin can fix later).</summary>
    public string? IdNumber { get; set; }
    public string? Department { get; set; }
}

public class LoginDto
{
    [Required(ErrorMessage = "Enter your username.")]
    public string Username { get; set; } = "";

    [Required(ErrorMessage = "Enter your password."), DataType(DataType.Password)]
    public string Password { get; set; } = "";

    public bool RememberMe { get; set; }
}

public class RefreshRequestDto
{
    [Required]
    public string RefreshToken { get; set; } = "";
}

public class ForgotPasswordDto
{
    [Required] public string Username { get; set; } = "";
    [Required, StringLength(20)] public string VerificationCode { get; set; } = "";
    [Required, DataType(DataType.Password)] public string NewPassword { get; set; } = "";
    [Required, DataType(DataType.Password), Compare(nameof(NewPassword), ErrorMessage = "The two passwords do not match.")]
    public string ConfirmPassword { get; set; } = "";
}

public class ChangePasswordDto
{
    [Required, DataType(DataType.Password)]
    public string CurrentPassword { get; set; } = "";

    [Required, DataType(DataType.Password)]
    public string NewPassword { get; set; } = "";

    [Required, DataType(DataType.Password), Compare(nameof(NewPassword), ErrorMessage = "The two passwords do not match.")]
    public string ConfirmPassword { get; set; } = "";
}

public class AuthResponseDto
{
    public string AccessToken { get; set; } = "";
    public string RefreshToken { get; set; } = "";
    public DateTime ExpiresAt { get; set; }
    public UserSummaryDto User { get; set; } = null!;
}

public class UserSummaryDto
{
    public int Id { get; set; }
    public string FullName { get; set; } = "";
    public string Username { get; set; } = "";
    public string Role { get; set; } = "";
    public string? Email { get; set; }
    public string? IdNumber { get; set; }
    public string? Department { get; set; }
    public string? PhotoPath { get; set; }
}
