using System.ComponentModel.DataAnnotations;

namespace StudentManagement.Dtos;

public class RoutineEntryDto
{
    public int Id { get; set; }
    public string Day { get; set; } = "";
    public string StartTime { get; set; } = "";
    public string EndTime { get; set; } = "";
    public string CourseName { get; set; } = "";
    public string Room { get; set; } = "";
    public string Department { get; set; } = "";
    public string? TeacherName { get; set; }
}

public class RoutineEntryCreateDto
{
    [Required] public string Day { get; set; } = "";
    [Required] public string StartTime { get; set; } = "";
    [Required] public string EndTime { get; set; } = "";
    [Required] public string CourseName { get; set; } = "";
    public string Room { get; set; } = "";
    public string Department { get; set; } = "";
    public int? TeacherId { get; set; }
}


/// <summary>Two routine entries that overlap while sharing a teacher or room.</summary>
public class RoutineConflictDto
{
    public int FirstId { get; set; }
    public int SecondId { get; set; }
    public string Day { get; set; } = "";
    public string FirstCourseName { get; set; } = "";
    public string SecondCourseName { get; set; } = "";
    public string FirstStartTime { get; set; } = "";
    public string FirstEndTime { get; set; } = "";
    public string SecondStartTime { get; set; } = "";
    public string SecondEndTime { get; set; } = "";
    public string FirstRoom { get; set; } = "";
    public string SecondRoom { get; set; } = "";
    public string? FirstTeacherName { get; set; }
    public string? SecondTeacherName { get; set; }
    public string ConflictType { get; set; } = "";
    public string Reason { get; set; } = "";
}
