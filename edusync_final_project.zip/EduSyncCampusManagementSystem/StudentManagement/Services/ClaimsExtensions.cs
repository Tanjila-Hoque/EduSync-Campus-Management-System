using System.Security.Claims;

namespace StudentManagement.Services;

public static class ClaimsExtensions
{
    public static int GetUserId(this ClaimsPrincipal principal)
    {
        var idText = principal.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        return int.TryParse(idText, out var id) ? id : 0;
    }

    public static string? GetRole(this ClaimsPrincipal principal) =>
        principal.FindFirst(ClaimTypes.Role)?.Value;
}
