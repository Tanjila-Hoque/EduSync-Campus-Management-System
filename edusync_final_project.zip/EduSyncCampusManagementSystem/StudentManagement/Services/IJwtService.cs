using System.Security.Claims;
using StudentManagement.Models;

namespace StudentManagement.Services;

public interface IJwtService
{
    (string Token, DateTime ExpiresAt) CreateAccessToken(User user);
    string CreateRefreshToken();
}
