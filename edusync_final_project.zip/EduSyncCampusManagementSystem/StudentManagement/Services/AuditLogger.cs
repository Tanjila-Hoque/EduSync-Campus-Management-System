using System.Security.Claims;
using StudentManagement.Data;
using StudentManagement.Models;

namespace StudentManagement.Services;

public class AuditLogger : IAuditLogger
{
    private readonly AppDbContext _db;
    public AuditLogger(AppDbContext db) => _db = db;

    public async Task LogAsync(ClaimsPrincipal actor, string action, string details)
    {
        _db.AuditLogs.Add(new AuditLog
        {
            ActorUserId = actor.GetUserId(),
            ActorName = actor.FindFirst("FullName")?.Value ?? actor.Identity?.Name ?? "Unknown",
            ActorRole = actor.GetRole() ?? "",
            Action = action,
            Details = details
        });
        await _db.SaveChangesAsync();
    }
}
