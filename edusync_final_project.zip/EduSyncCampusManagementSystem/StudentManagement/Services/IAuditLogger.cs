using System.Security.Claims;

namespace StudentManagement.Services;

public interface IAuditLogger
{
    Task LogAsync(ClaimsPrincipal actor, string action, string details);
}
