using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Models;

namespace StudentManagement.Services;

/// <summary>
/// Read-only "tools" (Gemini function calling) that let the chatbot look up any data the logged-in
/// user is allowed to see. SECURITY MODEL:
///  - userId and role always come from the verified JWT, never from the model or the browser.
///  - Every tool re-checks the role AND ownership (a teacher only reaches their own classes/roster).
///  - No tool writes, no tool accepts SQL, and secrets (password hashes, QR tokens...) are never selected.
/// Anything the model asks for outside its permission returns {"error": "..."} and the model explains it.
/// </summary>
public class CampusToolService
{
    private readonly AppDbContext _db;
    private readonly CampusDataService _data;
    public CampusToolService(AppDbContext db, CampusDataService data) { _db = db; _data = data; }

    // ---------------------------------------------------------------- permissions
    private static readonly string[] Everyone = { "get_routine", "get_notices" };
    private static readonly string[] StudentTools = { "list_classes" };
    private static readonly string[] TeacherTools =
        { "list_classes", "find_students", "get_student_report", "get_class_summary", "get_class_attendance_on_date", "get_class_results", "get_at_risk_students" };
    private static readonly string[] AdminTools = TeacherTools.Concat(new[] { "list_people", "get_campus_stats", "get_staff_attendance", "get_recent_activity" }).ToArray();

    private static string[] AllowedTools(string role) => role switch
    {
        Roles.Admin => Everyone.Concat(AdminTools).ToArray(),
        Roles.Teacher => Everyone.Concat(TeacherTools).ToArray(),
        Roles.Student => Everyone.Concat(StudentTools).ToArray(),
        Roles.Staff => Everyone,
        _ => Array.Empty<string>()
    };

    // ---------------------------------------------------------------- declarations (what Gemini sees)
    private static object Str(string d) => new { type = "string", description = d };
    private static object Int(string d) => new { type = "integer", description = d };

    private static object Fn(string name, string description, Dictionary<string, object>? props = null, params string[] required)
    {
        var d = new Dictionary<string, object> { ["name"] = name, ["description"] = description };
        if (props != null && props.Count > 0)
        {
            var schema = new Dictionary<string, object> { ["type"] = "object", ["properties"] = props };
            if (required.Length > 0) schema["required"] = required;
            d["parameters"] = schema;
        }
        return d;
    }

    private static readonly Dictionary<string, object> Catalog = new()
    {
        ["get_routine"] = Fn("get_routine", "Class routine/timetable. Students only see their own courses. All filters optional.",
            new() { ["day"] = Str("Day name e.g. Sunday"), ["course"] = Str("Course name or part of it"), ["teacher"] = Str("Teacher name or part of it"), ["department"] = Str("Department") }),
        ["get_notices"] = Fn("get_notices", "Search notices the user is allowed to see (newest first).",
            new() { ["search"] = Str("Word to search in title/body"), ["limit"] = Int("Max notices, default 10, max 20") }),
        ["list_classes"] = Fn("list_classes", "List classes (course, section, teacher, room, department). Students see all active classes with an 'enrolled' flag; teachers see their own; admins see all.",
            new() { ["query"] = Str("Course, section, department or teacher name filter") }),
        ["find_students"] = Fn("find_students", "Find students by name, username or ID number. Teachers only find students in their own classes. Use this first to get a student_id.",
            new() { ["query"] = Str("Name, username or ID number") }, "query"),
        ["get_student_report"] = Fn("get_student_report", "A student's classes, attendance percentages and results with grades. Teachers: only students in their own classes.",
            new() { ["student_id"] = Int("Student id from find_students") }, "student_id"),
        ["get_class_summary"] = Fn("get_class_summary", "Roster and attendance health of one class: classes held, average %, students below 75%.",
            new() { ["class_id"] = Int("Class id from list_classes") }, "class_id"),
        ["get_class_attendance_on_date"] = Fn("get_class_attendance_on_date", "Who was present and absent in one class on one date.",
            new() { ["class_id"] = Int("Class id"), ["date"] = Str("yyyy-MM-dd; empty = today") }, "class_id"),
        ["get_class_results"] = Fn("get_class_results", "Mid/final/assignment marks, total and grade for every student in one class.",
            new() { ["class_id"] = Int("Class id") }, "class_id"),
        ["get_at_risk_students"] = Fn("get_at_risk_students", "Students below the 75% attendance rule. Teachers: across own classes. Admins: across all active classes, or one class.",
            new() { ["class_id"] = Int("Optional class id") }),
        ["list_people"] = Fn("list_people", "Admin only: directory of users by role with contact details.",
            new() { ["role"] = Str("Student, Teacher, Staff or Admin"), ["query"] = Str("Name, username or ID number") }, "role"),
        ["get_campus_stats"] = Fn("get_campus_stats", "Admin only: campus-wide counts by department, inactive accounts, class sizes."),
        ["get_staff_attendance"] = Fn("get_staff_attendance", "Admin only: daily gate check-in of teachers or staff - who is present/absent.",
            new() { ["role"] = Str("Teacher or Staff"), ["date"] = Str("yyyy-MM-dd; empty = today") }, "role"),
        ["get_recent_activity"] = Fn("get_recent_activity", "Admin only: latest audit-log entries (who did what).",
            new() { ["limit"] = Int("Default 15, max 30") }),
    };

    public object[] DeclarationsFor(string role)
    {
        var allowed = AllowedTools(role);
        return allowed.Where(Catalog.ContainsKey).Select(n => Catalog[n]).ToArray();
    }

    // ---------------------------------------------------------------- dispatcher
    public async Task<object> ExecuteAsync(int userId, string role, string name, JsonElement args, CancellationToken ct)
    {
        if (!AllowedTools(role).Contains(name)) return new { error = "This information is not available for your role." };
        switch (name)
        {
            case "get_routine": return await GetRoutine(userId, role, args, ct);
            case "get_notices": return await GetNotices(userId, role, args, ct);
            case "list_classes": return await ListClasses(userId, role, args, ct);
            case "find_students": return await FindStudents(userId, role, args, ct);
            case "get_student_report": return await GetStudentReport(userId, role, args, ct);
            case "get_class_summary": return await GetClassSummary(userId, role, args, ct);
            case "get_class_attendance_on_date": return await GetClassAttendanceOnDate(userId, role, args, ct);
            case "get_class_results": return await GetClassResults(userId, role, args, ct);
            case "get_at_risk_students": return await GetAtRisk(userId, role, args, ct);
            case "list_people": return await ListPeople(args, ct);
            case "get_campus_stats": return await GetCampusStats(ct);
            case "get_staff_attendance": return await GetStaffAttendance(args, ct);
            case "get_recent_activity": return await GetRecentActivity(args, ct);
            default: return new { error = "Unknown tool." };
        }
    }

    // ---------------------------------------------------------------- argument helpers
    private static string? S(JsonElement a, string key)
    {
        if (a.ValueKind != JsonValueKind.Object || !a.TryGetProperty(key, out var v)) return null;
        var s = v.ValueKind == JsonValueKind.String ? v.GetString() : v.ValueKind == JsonValueKind.Number ? v.GetRawText() : null;
        return string.IsNullOrWhiteSpace(s) ? null : s.Trim();
    }

    private static int? I(JsonElement a, string key)
    {
        if (a.ValueKind != JsonValueKind.Object || !a.TryGetProperty(key, out var v)) return null;
        if (v.ValueKind == JsonValueKind.Number && v.TryGetInt32(out var n)) return n;
        if (v.ValueKind == JsonValueKind.String && int.TryParse(v.GetString(), out var m)) return m;
        return null;
    }

    private static DateOnly D(JsonElement a, string key) =>
        DateOnly.TryParse(S(a, key), out var d) ? d : AppClock.Today;

    private static string Lower(string? s) => (s ?? "").ToLowerInvariant();

    // ---------------------------------------------------------------- tools: everyone
    private async Task<object> GetRoutine(int userId, string role, JsonElement a, CancellationToken ct)
    {
        var q = _data.VisibleRoutine(userId, role);
        var day = S(a, "day");
        if (day != null)
        {
            var canonical = CampusDataService.DayOrder.FirstOrDefault(d => d.StartsWith(day, StringComparison.OrdinalIgnoreCase));
            if (canonical == null) return new { error = "Unknown day name." };
            q = q.Where(r => r.Day == canonical);
        }
        var course = Lower(S(a, "course")); var teacher = Lower(S(a, "teacher")); var dept = Lower(S(a, "department"));
        if (course != "") q = q.Where(r => r.CourseName.ToLower().Contains(course));
        if (teacher != "") q = q.Where(r => r.Teacher != null && r.Teacher.FullName.ToLower().Contains(teacher));
        if (dept != "") q = q.Where(r => r.Department.ToLower().Contains(dept));

        var rows = await q.Select(r => new { r.Day, r.StartTime, r.EndTime, r.CourseName, r.Room, r.Department, Teacher = r.Teacher != null ? r.Teacher.FullName : null })
            .Take(80).ToListAsync(ct);
        var ordered = rows.OrderBy(r => Array.IndexOf(CampusDataService.DayOrder, r.Day)).ThenBy(r => r.StartTime).ToList();
        return new { count = ordered.Count, routine = ordered };
    }

    private async Task<object> GetNotices(int userId, string role, JsonElement a, CancellationToken ct)
    {
        var q = _data.VisibleNotices(userId, role);
        var search = Lower(S(a, "search"));
        if (search != "") q = q.Where(n => n.Title.ToLower().Contains(search) || n.Body.ToLower().Contains(search));
        var limit = Math.Clamp(I(a, "limit") ?? 10, 1, 20);
        var rows = await q.OrderByDescending(n => n.CreatedAt).Take(limit)
            .Select(n => new { n.Title, n.Body, n.CreatedAt, By = n.CreatedBy.FullName }).ToListAsync(ct);
        return new { count = rows.Count, notices = rows.Select(n => new { n.Title, body = n.Body.Length > 600 ? n.Body[..600] + "…" : n.Body, date = n.CreatedAt.ToString("yyyy-MM-dd"), postedBy = n.By }) };
    }

    // ---------------------------------------------------------------- tools: classes
    private async Task<object> ListClasses(int userId, string role, JsonElement a, CancellationToken ct)
    {
        var q = _db.AcademicClasses.AsNoTracking().AsQueryable();
        if (role == Roles.Teacher) q = q.Where(c => c.TeacherId == userId);
        else if (role == Roles.Student) q = q.Where(c => c.IsActive);
        var text = Lower(S(a, "query"));
        if (text != "") q = q.Where(c => c.CourseName.ToLower().Contains(text) || c.Section.ToLower().Contains(text)
            || c.Department.ToLower().Contains(text) || c.Teacher.FullName.ToLower().Contains(text));

        var rows = await q.OrderBy(c => c.CourseName).ThenBy(c => c.Section).Take(40)
            .Select(c => new
            {
                c.Id, c.CourseName, c.Section, c.Department, c.Room, c.IsActive,
                Teacher = c.Teacher.FullName,
                Students = _db.ClassEnrollments.Count(e => e.ClassId == c.Id),
                Enrolled = _db.ClassEnrollments.Any(e => e.ClassId == c.Id && e.StudentId == userId)
            }).ToListAsync(ct);

        if (role == Roles.Student)
            return new { count = rows.Count, classes = rows.Select(c => new { classId = c.Id, course = c.CourseName, section = c.Section, department = c.Department, room = c.Room, teacher = c.Teacher, enrolled = c.Enrolled }) };
        return new { count = rows.Count, classes = rows.Select(c => new { classId = c.Id, course = c.CourseName, section = c.Section, department = c.Department, room = c.Room, teacher = c.Teacher, active = c.IsActive, students = c.Students }) };
    }

    /// <summary>Returns null when allowed, otherwise an error object. Teachers only reach their own classes.</summary>
    private async Task<object?> CheckClassAccess(int userId, string role, int classId, CancellationToken ct)
    {
        var owner = await _db.AcademicClasses.AsNoTracking().Where(c => c.Id == classId).Select(c => (int?)c.TeacherId).FirstOrDefaultAsync(ct);
        if (owner == null) return new { error = "Class not found." };
        if (role == Roles.Teacher && owner != userId) return new { error = "You can only view your own classes." };
        return null;
    }

    private async Task<object> GetClassSummary(int userId, string role, JsonElement a, CancellationToken ct)
    {
        var id = I(a, "class_id"); if (id == null) return new { error = "class_id is required." };
        var denied = await CheckClassAccess(userId, role, id.Value, ct); if (denied != null) return denied;
        var s = await _data.ClassSummaryAsync(id.Value, ct);
        if (s == null) return new { error = "Class not found." };
        return new
        {
            classId = s.ClassId, course = s.Course, section = s.Section, teacher = s.Teacher, room = s.Room, active = s.IsActive,
            classesHeld = s.Held, studentCount = s.Students.Count, averageAttendancePercent = s.AveragePercent, studentsBelow75 = s.AtRiskCount,
            students = s.Students.Take(80).Select(r => new { studentId = r.StudentId, name = r.Name, idNumber = r.IdNumber, attended = r.Attended, percent = r.Percent, status = r.Status, mustAttendInARow = r.MustAttend })
        };
    }

    private async Task<object> GetClassAttendanceOnDate(int userId, string role, JsonElement a, CancellationToken ct)
    {
        var id = I(a, "class_id"); if (id == null) return new { error = "class_id is required." };
        var denied = await CheckClassAccess(userId, role, id.Value, ct); if (denied != null) return denied;
        var day = D(a, "date");
        var present = await _db.Attendance.AsNoTracking().Where(x => x.ClassId == id && x.Date == day)
            .Select(x => new { x.UserId, x.User.FullName, x.User.IdNumber, x.IsCorrected }).ToListAsync(ct);
        var presentIds = present.Select(p => p.UserId).ToHashSet();
        var absent = await _db.ClassEnrollments.AsNoTracking().Where(e => e.ClassId == id && e.Student.IsActive)
            .Select(e => new { e.StudentId, e.Student.FullName, e.Student.IdNumber }).ToListAsync(ct);
        var absentRows = absent.Where(x => !presentIds.Contains(x.StudentId)).OrderBy(x => x.FullName).ToList();
        return new
        {
            date = day.ToString("yyyy-MM-dd"),
            presentCount = present.Count, absentCount = absentRows.Count,
            present = present.OrderBy(p => p.FullName).Take(80).Select(p => new { name = p.FullName, idNumber = p.IdNumber, correctedManually = p.IsCorrected }),
            absent = absentRows.Take(80).Select(p => new { name = p.FullName, idNumber = p.IdNumber })
        };
    }

    private async Task<object> GetClassResults(int userId, string role, JsonElement a, CancellationToken ct)
    {
        var id = I(a, "class_id"); if (id == null) return new { error = "class_id is required." };
        var denied = await CheckClassAccess(userId, role, id.Value, ct); if (denied != null) return denied;
        var summary = await _data.ClassSummaryAsync(id.Value, ct);
        if (summary == null) return new { error = "Class not found." };

        var ids = summary.Students.Select(s => s.StudentId).ToList();
        var results = await _db.ResultEntries.AsNoTracking().Where(r => r.CourseName == summary.Course && ids.Contains(r.StudentId))
            .OrderByDescending(r => r.CreatedAt).ToListAsync(ct);
        var latest = results.GroupBy(r => r.StudentId).Select(g => g.First()).ToList();
        var byStudent = summary.Students.ToDictionary(s => s.StudentId);

        var rows = latest.Select(r =>
        {
            var st = byStudent[r.StudentId];
            // Attendance marks use this class's attendance % (max 10), like the Results page.
            r.AttendanceMarks = Math.Round(Math.Min(100, st.Percent) * 10.0 / 100.0, 2);
            return new { studentId = r.StudentId, name = st.Name, idNumber = st.IdNumber, mid = r.Mid, final = r.Final, assignment = r.Assignment, attendanceMarks = r.AttendanceMarks, total = r.Total, grade = r.Grade };
        }).OrderByDescending(r => r.total).ToList();

        var without = summary.Students.Where(s => latest.All(r => r.StudentId != s.StudentId)).Select(s => s.Name).Take(40).ToList();
        return new { course = summary.Course, section = summary.Section, maxTotal = 110, resultsEntered = rows.Count, studentsWithoutResult = without, results = rows.Take(80) };
    }

    private async Task<object> GetAtRisk(int userId, string role, JsonElement a, CancellationToken ct)
    {
        var onlyClass = I(a, "class_id");
        List<int> ids;
        if (onlyClass != null)
        {
            var denied = await CheckClassAccess(userId, role, onlyClass.Value, ct); if (denied != null) return denied;
            ids = new List<int> { onlyClass.Value };
        }
        else
        {
            var q = _db.AcademicClasses.AsNoTracking().Where(c => c.IsActive);
            if (role == Roles.Teacher) q = q.Where(c => c.TeacherId == userId);
            ids = await q.OrderBy(c => c.Id).Select(c => c.Id).Take(25).ToListAsync(ct);
        }
        var rows = new List<object>(); var perClass = new List<(double Percent, object Row)>();
        foreach (var id in ids)
        {
            var s = await _data.ClassSummaryAsync(id, ct);
            if (s == null) continue;
            foreach (var st in s.Students.Where(x => x.Status == "AtRisk"))
                perClass.Add((st.Percent, new { course = s.Course, section = s.Section, classId = s.ClassId, studentId = st.StudentId, name = st.Name, idNumber = st.IdNumber, attended = st.Attended, classesHeld = s.Held, percent = st.Percent, mustAttendInARow = st.MustAttend }));
        }
        rows.AddRange(perClass.OrderBy(x => x.Percent).Take(50).Select(x => x.Row));
        return new { classesChecked = ids.Count, totalAtRisk = perClass.Count, shown = rows.Count, students = rows };
    }

    // ---------------------------------------------------------------- tools: students
    private async Task<object> FindStudents(int userId, string role, JsonElement a, CancellationToken ct)
    {
        var text = Lower(S(a, "query")); if (text == "") return new { error = "query is required." };
        var q = _db.Users.AsNoTracking().Where(u => u.Role == Roles.Student);
        if (role == Roles.Teacher)
            q = q.Where(u => _db.ClassEnrollments.Any(e => e.StudentId == u.Id && e.Class.TeacherId == userId && e.Class.IsActive));
        q = q.Where(u => u.FullName.ToLower().Contains(text) || u.Username.ToLower().Contains(text) || (u.IdNumber != null && u.IdNumber.ToLower().Contains(text)));
        var rows = await q.OrderBy(u => u.FullName).Take(15)
            .Select(u => new { u.Id, u.FullName, u.IdNumber, u.Department, u.IsActive }).ToListAsync(ct);
        return new { count = rows.Count, students = rows.Select(u => new { studentId = u.Id, name = u.FullName, idNumber = u.IdNumber, department = u.Department, active = u.IsActive }) };
    }

    private async Task<object> GetStudentReport(int userId, string role, JsonElement a, CancellationToken ct)
    {
        var id = I(a, "student_id"); if (id == null) return new { error = "student_id is required." };
        if (role == Roles.Teacher)
        {
            var onRoster = await _db.ClassEnrollments.AsNoTracking().AnyAsync(e => e.StudentId == id && e.Class.TeacherId == userId && e.Class.IsActive, ct);
            if (!onRoster) return new { error = "You can only view students enrolled in your own classes." };
        }
        var student = await _db.Users.AsNoTracking().Where(u => u.Id == id && u.Role == Roles.Student)
            .Select(u => new { u.FullName, u.IdNumber, u.Department, u.IsActive, u.Email, u.Phone }).FirstOrDefaultAsync(ct);
        if (student == null) return new { error = "Student not found." };

        var health = await _data.StudentHealthAsync(id.Value, ct);
        var results = await _data.StudentResultsAsync(id.Value, ct);
        return new
        {
            name = student.FullName, idNumber = student.IdNumber, department = student.Department, active = student.IsActive,
            email = role == Roles.Admin ? student.Email : null, phone = role == Roles.Admin ? student.Phone : null,
            attendance = health.Select(CampusDataService.DescribeHealth),
            results = results.Select(CampusDataService.DescribeResult),
            gradingNote = "Total is out of 110: mid + final + assignment + attendance marks (max 10)."
        };
    }

    // ---------------------------------------------------------------- tools: admin only
    private async Task<object> ListPeople(JsonElement a, CancellationToken ct)
    {
        var role = S(a, "role");
        if (role == null || !Roles.All.Contains(role)) return new { error = "role must be Student, Teacher, Staff or Admin." };
        var q = _db.Users.AsNoTracking().Where(u => u.Role == role);
        var text = Lower(S(a, "query"));
        if (text != "") q = q.Where(u => u.FullName.ToLower().Contains(text) || u.Username.ToLower().Contains(text) || (u.IdNumber != null && u.IdNumber.ToLower().Contains(text)));
        var total = await q.CountAsync(ct);
        var rows = await q.OrderBy(u => u.FullName).Take(30)
            .Select(u => new { u.Id, u.FullName, u.Username, u.IdNumber, u.Department, u.Email, u.Phone, u.IsActive }).ToListAsync(ct);
        return new { total, shown = rows.Count, people = rows.Select(u => new { id = u.Id, name = u.FullName, username = u.Username, idNumber = u.IdNumber, department = u.Department, email = u.Email, phone = u.Phone, active = u.IsActive }) };
    }

    private async Task<object> GetCampusStats(CancellationToken ct)
    {
        var inactive = await _db.Users.AsNoTracking().CountAsync(u => !u.IsActive, ct);
        var studentDepts = await _db.Users.AsNoTracking().Where(u => u.Role == Roles.Student)
            .GroupBy(u => u.Department).Select(g => new { Department = g.Key, Count = g.Count() }).ToListAsync(ct);
        var classDepts = await _db.AcademicClasses.AsNoTracking().Where(c => c.IsActive)
            .GroupBy(c => c.Department).Select(g => new { Department = g.Key, Count = g.Count() }).ToListAsync(ct);
        var biggest = await _db.AcademicClasses.AsNoTracking().Where(c => c.IsActive)
            .Select(c => new { c.Id, c.CourseName, c.Section, Students = _db.ClassEnrollments.Count(e => e.ClassId == c.Id) })
            .OrderByDescending(c => c.Students).Take(5).ToListAsync(ct);
        return new
        {
            inactiveAccounts = inactive,
            studentsByDepartment = studentDepts.Select(d => new { department = string.IsNullOrWhiteSpace(d.Department) ? "(none)" : d.Department, d.Count }),
            activeClassesByDepartment = classDepts.Select(d => new { department = string.IsNullOrWhiteSpace(d.Department) ? "(none)" : d.Department, d.Count }),
            largestClasses = biggest.Select(c => new { classId = c.Id, course = c.CourseName, section = c.Section, students = c.Students })
        };
    }

    private async Task<object> GetStaffAttendance(JsonElement a, CancellationToken ct)
    {
        var role = S(a, "role");
        if (role != Roles.Teacher && role != Roles.Staff) return new { error = "role must be Teacher or Staff." };
        var day = D(a, "date");
        var present = await _db.Attendance.AsNoTracking().Where(x => x.ClassId == null && x.Date == day && x.User.Role == role)
            .OrderBy(x => x.CheckInTime).Select(x => new { x.UserId, x.User.FullName, x.User.IdNumber, x.CheckInTime }).ToListAsync(ct);
        var presentIds = present.Select(p => p.UserId).ToHashSet();
        var everyone = await _db.Users.AsNoTracking().Where(u => u.Role == role && u.IsActive)
            .OrderBy(u => u.FullName).Select(u => new { u.Id, u.FullName, u.IdNumber }).ToListAsync(ct);
        var absent = everyone.Where(u => !presentIds.Contains(u.Id)).ToList();
        return new
        {
            date = day.ToString("yyyy-MM-dd"), role, presentCount = present.Count, absentCount = absent.Count,
            present = present.Take(80).Select(p => new { name = p.FullName, idNumber = p.IdNumber, checkInUtc = p.CheckInTime }),
            absent = absent.Take(80).Select(p => new { name = p.FullName, idNumber = p.IdNumber })
        };
    }

    private async Task<object> GetRecentActivity(JsonElement a, CancellationToken ct)
    {
        var limit = Math.Clamp(I(a, "limit") ?? 15, 1, 30);
        var rows = await _db.AuditLogs.AsNoTracking().OrderByDescending(l => l.Timestamp).Take(limit)
            .Select(l => new { l.Timestamp, l.ActorName, l.ActorRole, l.Action, l.Details }).ToListAsync(ct);
        return new { count = rows.Count, activity = rows.Select(l => new { timeUtc = l.Timestamp, actor = l.ActorName, role = l.ActorRole, action = l.Action, details = l.Details }) };
    }
}
