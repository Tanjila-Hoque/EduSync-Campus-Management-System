using StudentManagement.Dtos;
using StudentManagement.Models;

namespace StudentManagement.Services;

public interface IAuthService
{
    Task<(User? User, string? Error)> ValidateAsync(string username, string password);
    Task<(User? User, string? Error)> RegisterAsync(RegisterDto dto);
    Task<AuthResponseDto> IssueTokensAsync(User user, bool rememberMe = true);
    Task<(User? User, string? Error)> RefreshAsync(string refreshToken);
    Task RevokeRefreshTokenAsync(int userId);
}
