using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Dtos;
using StudentManagement.Models;

namespace StudentManagement.Services;

/// <summary>
/// Our own login/signup logic (no ASP.NET Identity): checks the users table,
/// verifies the hashed password, locks the account after repeated failures,
/// and issues our own JWT access token + opaque refresh token.
/// </summary>
public class AuthService : IAuthService
{
    private const int MaxFailedAttempts = 5;
    private static readonly TimeSpan LockoutTime = TimeSpan.FromMinutes(10);
    private static readonly TimeSpan RememberedRefreshLifetime = TimeSpan.FromDays(30);
    private static readonly TimeSpan SessionRefreshLifetime = TimeSpan.FromHours(12);

    private readonly AppDbContext _db;
    private readonly IJwtService _jwt;

    public AuthService(AppDbContext db, IJwtService jwt)
    {
        _db = db;
        _jwt = jwt;
    }

    public async Task<(User? User, string? Error)> ValidateAsync(string username, string password)
    {
        const string invalid = "Wrong username or password.";

        var user = await _db.Users.FirstOrDefaultAsync(u => u.Username == username);
        if (user == null)
        {
            PasswordHasher.Hash(password); // keep response time similar for unknown usernames
            return (null, invalid);
        }

        if (!user.IsActive)
            return (null, "This account is disabled. Please contact the administrator.");

        if (user.LockoutEnd.HasValue && user.LockoutEnd > DateTime.UtcNow)
        {
            var mins = Math.Ceiling((user.LockoutEnd.Value - DateTime.UtcNow).TotalMinutes);
            return (null, $"Too many failed attempts. Try again in {mins} minute(s).");
        }

        if (!PasswordHasher.Verify(password, user.PasswordHash))
        {
            user.FailedLoginCount++;
            if (user.FailedLoginCount >= MaxFailedAttempts)
            {
                user.LockoutEnd = DateTime.UtcNow.Add(LockoutTime);
                user.FailedLoginCount = 0;
            }
            await _db.SaveChangesAsync();
            return (null, invalid);
        }

        user.FailedLoginCount = 0;
        user.LockoutEnd = null;
        await _db.SaveChangesAsync();
        return (user, null);
    }

    public async Task<(User? User, string? Error)> RegisterAsync(RegisterDto dto)
    {
        var usernameTaken = await _db.Users.AnyAsync(u => u.Username == dto.Username);
        if (usernameTaken) return (null, "That username is already taken.");

        if (!PasswordHasher.IsStrongEnough(dto.Password))
            return (null, "Use at least 8 characters with a letter and a number.");

        if (!string.IsNullOrWhiteSpace(dto.IdNumber) &&
            await _db.Users.AnyAsync(u => u.IdNumber == dto.IdNumber))
            return (null, "That ID / roll number is already registered.");

        // Public signup always creates a Student account. Admin/Teacher/Staff accounts
        // are created from the People management screen by an existing Admin.
        var user = new User
        {
            FullName = dto.FullName.Trim(),
            Username = dto.Username.Trim(),
            Email = dto.Email,
            Phone = dto.Phone,
            PasswordHash = PasswordHasher.Hash(dto.Password),
            Role = Roles.Student,
            IdNumber = dto.IdNumber,
            Department = dto.Department,
            IsActive = true
        };

        _db.Users.Add(user);
        await _db.SaveChangesAsync();
        return (user, null);
    }

    public async Task<AuthResponseDto> IssueTokensAsync(User user, bool rememberMe = true)
    {
        var (accessToken, expiresAt) = _jwt.CreateAccessToken(user);
        var refreshToken = _jwt.CreateRefreshToken();

        user.RefreshToken = refreshToken;
        user.RefreshTokenExpiresAt = DateTime.UtcNow.Add(rememberMe ? RememberedRefreshLifetime : SessionRefreshLifetime);
        await _db.SaveChangesAsync();

        return new AuthResponseDto
        {
            AccessToken = accessToken,
            RefreshToken = refreshToken,
            ExpiresAt = expiresAt,
            User = new UserSummaryDto
            {
                Id = user.Id,
                FullName = user.FullName,
                Username = user.Username,
                Role = user.Role,
                Email = user.Email,
                IdNumber = user.IdNumber,
                Department = user.Department,
                PhotoPath = user.PhotoPath
            }
        };
    }

    public async Task<(User? User, string? Error)> RefreshAsync(string refreshToken)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.RefreshToken == refreshToken);
        if (user == null || user.RefreshTokenExpiresAt == null || user.RefreshTokenExpiresAt < DateTime.UtcNow)
            return (null, "Refresh token is invalid or expired. Please log in again.");

        if (!user.IsActive)
            return (null, "This account is disabled.");

        return (user, null);
    }

    public async Task RevokeRefreshTokenAsync(int userId)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == userId);
        if (user == null) return;
        user.RefreshToken = null;
        user.RefreshTokenExpiresAt = null;
        await _db.SaveChangesAsync();
    }
}
