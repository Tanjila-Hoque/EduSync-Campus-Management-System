using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Models;

namespace StudentManagement.Services;

/// <summary>
/// Read-only calculations shared by the AI chatbot. The formulas intentionally mirror
/// AnalyticsController (attendance health) and ResultController (attendance marks + grade)
/// so the chatbot always shows the same numbers as the app's own pages.
/// </summary>
public class CampusDataService
{
    private const double Required = 0.75;
    private readonly AppDbContext _db;
    public CampusDataService(AppDbContext db) { _db = db; }

    public record ClassHealthRow(int ClassId, string Course, string Section, string Teacher, string Room,
        int Held, int Attended, double Percent, string Status, int CanMiss, int MustAttend);

    public record ResultRow(string Course, double Mid, double Final, double Assignment,
        double AttendancePercent, double AttendanceMarks, double Total, string Grade);

    public static string StatusOf(int held, double percent)
        => held == 0 ? "NoData" : percent >= 80 ? "Safe" : percent >= 75 ? "Watch" : "AtRisk";

    public static int CanMissOf(int attended, int held)
        => held == 0 ? 0 : Math.Max(0, (int)Math.Floor(attended / Required - held + 1e-9));

    public static int MustAttendOf(int attended, int held)
    {
        if (held == 0 || attended >= Required * held - 1e-9) return 0;
        return (int)Math.Ceiling((Required * held - attended) / (1 - Required) - 1e-9);
    }

    public static double Pct(int attended, int held) => held == 0 ? 0 : Math.Round(100.0 * attended / held, 1);

    /// <summary>For each class: the set of calendar days it was held (a session opened or a record exists).</summary>
    public async Task<Dictionary<int, HashSet<DateOnly>>> HeldDaysAsync(List<int> classIds, CancellationToken ct)
    {
        var result = classIds.ToDictionary(id => id, _ => new HashSet<DateOnly>());
        if (classIds.Count == 0) return result;

        var sessions = await _db.AttendanceSessions.AsNoTracking()
            .Where(s => s.ClassId != null && classIds.Contains(s.ClassId.Value))
            .Select(s => new { ClassId = s.ClassId!.Value, s.StartedAt })
            .ToListAsync(ct);
        foreach (var s in sessions) result[s.ClassId].Add(AppClock.DateOf(s.StartedAt));

        var records = await _db.Attendance.AsNoTracking()
            .Where(a => a.ClassId != null && classIds.Contains(a.ClassId.Value))
            .Select(a => new { ClassId = a.ClassId!.Value, a.Date })
            .Distinct()
            .ToListAsync(ct);
        foreach (var r in records) result[r.ClassId].Add(r.Date);
        return result;
    }

    /// <summary>A student's attendance health in every active class they joined.</summary>
    public async Task<List<ClassHealthRow>> StudentHealthAsync(int studentId, CancellationToken ct)
    {
        var classes = await _db.ClassEnrollments.AsNoTracking()
            .Where(e => e.StudentId == studentId && e.Class.IsActive)
            .Select(e => new { e.Class.Id, e.Class.CourseName, e.Class.Section, e.Class.Room, Teacher = e.Class.Teacher.FullName })
            .ToListAsync(ct);
        var ids = classes.Select(c => c.Id).ToList();
        var held = await HeldDaysAsync(ids, ct);

        var mine = ids.Count == 0
            ? new List<(int ClassId, DateOnly Date)>()
            : (await _db.Attendance.AsNoTracking()
                .Where(a => a.UserId == studentId && a.ClassId != null && ids.Contains(a.ClassId.Value))
                .Select(a => new { ClassId = a.ClassId!.Value, a.Date })
                .ToListAsync(ct)).Select(x => (x.ClassId, x.Date)).ToList();
        var attendedBy = mine.GroupBy(x => x.ClassId).ToDictionary(g => g.Key, g => g.Select(x => x.Date).Distinct().Count());

        return classes.Select(c =>
        {
            var h = held[c.Id].Count;
            var a = attendedBy.TryGetValue(c.Id, out var n) ? n : 0;
            var pct = Pct(a, h);
            return new ClassHealthRow(c.Id, c.CourseName, c.Section, c.Teacher, c.Room, h, a, pct,
                StatusOf(h, pct), CanMissOf(a, h), MustAttendOf(a, h));
        }).OrderBy(r => r.Percent).ThenBy(r => r.Course).ToList();
    }

    /// <summary>A student's result rows with attendance marks (max 10) and grade, same formula as ResultController.</summary>
    public async Task<List<ResultRow>> StudentResultsAsync(int studentId, CancellationToken ct)
    {
        var results = await _db.ResultEntries.AsNoTracking()
            .Where(r => r.StudentId == studentId)
            .OrderByDescending(r => r.CreatedAt).Take(30).ToListAsync(ct);
        if (results.Count == 0) return new List<ResultRow>();

        var myClasses = await _db.ClassEnrollments.AsNoTracking()
            .Where(e => e.StudentId == studentId && e.Class.IsActive)
            .Select(e => new { e.ClassId, e.Class.CourseName }).ToListAsync(ct);
        var ids = myClasses.Select(c => c.ClassId).ToList();

        var sessionRows = await _db.AttendanceSessions.AsNoTracking()
            .Where(s => s.ClassId != null && ids.Contains(s.ClassId.Value))
            .GroupBy(s => s.ClassId).Select(g => new { ClassId = g.Key, Count = g.Count() }).ToListAsync(ct);
        var attendedRows = await _db.Attendance.AsNoTracking()
            .Where(a => a.UserId == studentId && a.ClassId != null && ids.Contains(a.ClassId.Value))
            .GroupBy(a => a.ClassId).Select(g => new { ClassId = g.Key, Count = g.Count() }).ToListAsync(ct);
        var sessionsBy = sessionRows.Where(x => x.ClassId.HasValue).ToDictionary(x => x.ClassId!.Value, x => x.Count);
        var attendedBy = attendedRows.Where(x => x.ClassId.HasValue).ToDictionary(x => x.ClassId!.Value, x => x.Count);

        var output = new List<ResultRow>();
        foreach (var r in results)
        {
            var classIds = myClasses.Where(c => c.CourseName == r.CourseName).Select(c => c.ClassId).ToList();
            var held = classIds.Sum(id => sessionsBy.TryGetValue(id, out var s) ? s : 0);
            var attended = classIds.Sum(id => attendedBy.TryGetValue(id, out var a) ? a : 0);
            var pct = held == 0 ? 0 : Math.Min(100, attended * 100.0 / held);
            r.AttendanceMarks = Math.Round(pct * 10.0 / 100.0, 2);
            output.Add(new ResultRow(r.CourseName, r.Mid, r.Final, r.Assignment, Math.Round(pct, 2), r.AttendanceMarks, r.Total, r.Grade));
        }
        return output;
    }

    public record StudentRow(int StudentId, string Name, string? IdNumber, int Attended, double Percent, string Status, int MustAttend);
    public record ClassSummary(int ClassId, string Course, string Section, string Teacher, int TeacherId, string Room, bool IsActive,
        int Held, double AveragePercent, int AtRiskCount, List<StudentRow> Students);

    /// <summary>Roster + attendance health for one class (same maths as AnalyticsController.ClassInsights).</summary>
    public async Task<ClassSummary?> ClassSummaryAsync(int classId, CancellationToken ct)
    {
        var c = await _db.AcademicClasses.AsNoTracking().Include(x => x.Teacher).FirstOrDefaultAsync(x => x.Id == classId, ct);
        if (c == null) return null;
        var held = (await HeldDaysAsync(new List<int> { classId }, ct))[classId].Count;

        var students = await _db.ClassEnrollments.AsNoTracking()
            .Where(e => e.ClassId == classId && e.Student.IsActive)
            .Select(e => new { e.StudentId, e.Student.FullName, e.Student.IdNumber }).ToListAsync(ct);
        var records = await _db.Attendance.AsNoTracking().Where(a => a.ClassId == classId)
            .Select(a => new { a.UserId, a.Date }).ToListAsync(ct);
        var attendedBy = records.GroupBy(r => r.UserId).ToDictionary(g => g.Key, g => g.Select(r => r.Date).Distinct().Count());

        var rows = students.Select(s =>
        {
            var a = attendedBy.TryGetValue(s.StudentId, out var n) ? n : 0;
            var pct = Pct(a, held);
            return new StudentRow(s.StudentId, s.FullName, s.IdNumber, a, pct, StatusOf(held, pct), MustAttendOf(a, held));
        }).OrderBy(r => r.Percent).ThenBy(r => r.Name).ToList();

        var avg = rows.Count == 0 || held == 0 ? 0 : Math.Round(rows.Average(r => r.Percent), 1);
        return new ClassSummary(c.Id, c.CourseName, c.Section, c.Teacher.FullName, c.TeacherId, c.Room, c.IsActive,
            held, avg, rows.Count(r => r.Status == "AtRisk"), rows);
    }

    /// <summary>Notices the user may see - identical rules to NoticeController.Index.</summary>
    public IQueryable<Notice> VisibleNotices(int userId, string role)
    {
        var q = _db.Notices.AsNoTracking().AsQueryable();
        if (role == Roles.Student)
            q = q.Where(n => (n.TargetClassId == null && (n.AudienceRole == null || n.AudienceRole == Roles.Student))
                || (n.TargetClassId != null && _db.ClassEnrollments.Any(e => e.ClassId == n.TargetClassId && e.StudentId == userId)));
        else if (role == Roles.Teacher)
            q = q.Where(n => (n.TargetClassId == null && n.AudienceRole == null) || n.CreatedByUserId == userId);
        else if (role == Roles.Staff)
            q = q.Where(n => n.TargetClassId == null && (n.AudienceRole == null || n.AudienceRole == Roles.Staff));
        return q; // Admin sees all
    }

    /// <summary>Routine rows - identical visibility to RoutineController (students only see their enrolled courses).</summary>
    public IQueryable<RoutineEntry> VisibleRoutine(int userId, string role)
    {
        var q = _db.RoutineEntries.AsNoTracking().AsQueryable();
        if (role == Roles.Student)
            q = q.Where(r => _db.ClassEnrollments.Any(e => e.StudentId == userId && e.Class.CourseName == r.CourseName));
        return q;
    }

    public static readonly string[] DayOrder = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

    public static string DescribeHealth(ClassHealthRow c) =>
        c.Held == 0
            ? $"{c.Course} ({c.Section}), teacher {c.Teacher}, room {c.Room}: no classes held yet"
            : $"{c.Course} ({c.Section}), teacher {c.Teacher}, room {c.Room}: attended {c.Attended} of {c.Held} held classes = {c.Percent}% [{c.Status}]; " +
              (c.MustAttend > 0 ? $"must attend next {c.MustAttend} classes in a row to get back to 75%" : $"can still miss {c.CanMiss} more classes and stay at or above 75%");

    public static string DescribeResult(ResultRow r) =>
        $"{r.Course}: mid {r.Mid}, final {r.Final}, assignment {r.Assignment}, attendance marks {r.AttendanceMarks}/10 ({r.AttendancePercent}%), total {r.Total}/110, grade {r.Grade}";
}
