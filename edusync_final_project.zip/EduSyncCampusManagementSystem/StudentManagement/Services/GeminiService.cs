using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

namespace StudentManagement.Services;

public class GeminiService
{
    private readonly HttpClient _client;
    private readonly IConfiguration _config;
    private readonly ILogger<GeminiService> _logger;
    public GeminiService(HttpClient client, IConfiguration config, ILogger<GeminiService> logger)
    {
        _client = client; _config = config; _logger = logger;
        _client.BaseAddress = new Uri("https://generativelanguage.googleapis.com/");
        _client.Timeout = TimeSpan.FromSeconds(75); // tool-calling chats can take several round trips
    }

    /// <summary>Single-prompt generation (used by the notice generator).</summary>
    public async Task<string> GenerateAsync(string prompt, CancellationToken ct)
    {
        var body = new Dictionary<string, object>
        {
            ["contents"] = new object[] { new { role = "user", parts = new[] { new { text = prompt } } } }
        };
        using var doc = await PostAsync(body, ct);
        return ExtractText(doc.RootElement) ?? throw new InvalidOperationException("Gemini returned empty text.");
    }

    /// <summary>
    /// Multi-turn chat. The system instruction carries the rules + the user's campus data. If tools are
    /// supplied, Gemini may call them (function calling); each call is executed by <paramref name="executeTool"/>
    /// on OUR server, the result is fed back, and the loop repeats until Gemini writes its final answer.
    /// </summary>
    public async Task<string> ChatAsync(string systemInstruction, IEnumerable<(string Role, string Text)> history, string question,
        object[] functionDeclarations, Func<string, JsonElement, Task<object>> executeTool, CancellationToken ct, int maxToolRounds = 5)
    {
        var contents = new List<object>();
        foreach (var (role, text) in history)
            contents.Add(new { role = role == "model" ? "model" : "user", parts = new[] { new { text } } });
        contents.Add(new { role = "user", parts = new[] { new { text = question } } });

        for (var round = 0; round <= maxToolRounds; round++)
        {
            var body = new Dictionary<string, object>
            {
                ["systemInstruction"] = new { parts = new[] { new { text = systemInstruction } } },
                ["contents"] = contents,
                ["generationConfig"] = new { temperature = 0.5 }
            };
            // On the last round tools are withheld so Gemini must answer with what it already has.
            if (functionDeclarations.Length > 0 && round < maxToolRounds)
                body["tools"] = new[] { new { functionDeclarations } };

            using var doc = await PostAsync(body, ct);
            var parts = GetParts(doc.RootElement);
            var calls = parts.Where(p => p.TryGetProperty("functionCall", out _)).ToList();
            if (calls.Count == 0)
                return ExtractText(doc.RootElement) ?? throw new InvalidOperationException("Gemini returned empty text.");

            // Keep Gemini's own turn exactly as received (it may carry thought signatures it needs back).
            contents.Add(new { role = "model", parts = parts.Select(p => p.Clone()).ToList() });

            var responses = new List<object>();
            foreach (var call in calls)
            {
                var fc = call.GetProperty("functionCall");
                var name = fc.GetProperty("name").GetString() ?? "";
                var args = fc.TryGetProperty("args", out var a) ? a.Clone() : default;
                object result;
                try { result = await executeTool(name, args); }
                catch (OperationCanceledException) { throw; }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "AI tool {Tool} failed", name);
                    result = new { error = "That lookup failed. Tell the user the data could not be loaded right now." };
                }
                responses.Add(new { functionResponse = new { name, response = new { result } } });
            }
            contents.Add(new { role = "user", parts = responses });
        }
        throw new InvalidOperationException("Gemini did not produce a final answer.");
    }

    // ------------------------------------------------------------------ plumbing
    private static string? _resolvedModel;   // the model that last worked; shared by all requests
    private static readonly string[] FallbackModels =
    {
        "gemini-3.8-flash",
        "gemini-3.6-flash",
        "gemini-3.5-flash-lite",
        "gemini-3.1-flash-lite",
        "gemini-3-flash-preview",
        "gemini-2.5-flash",
        "gemini-2.5-flash-lite"
    };

    /// <summary>For tests only: forget the remembered working model.</summary>
    public static void ResetModelCache() => _resolvedModel = null;

    /// <summary>
    /// Posts to generateContent. If Google answers 404 (model retired / not available to this key) the service asks
    /// Google which Flash models this key can use, switches to the newest one and remembers it - so a model
    /// retirement never breaks the chatbot again. Any other error (403 key, 429 quota...) is reported as-is.
    /// </summary>
    private async Task<JsonDocument> PostAsync(object body, CancellationToken ct)
    {
        var key = _config["Gemini:ApiKey"];
        if (string.IsNullOrWhiteSpace(key)) throw new InvalidOperationException("Gemini API key is not configured.");
        var configured = (_config["Gemini:Model"] ?? "").Trim();
        if (configured.Length == 0) configured = FallbackModels[0];

        var model = _resolvedModel ?? configured;
        var tried = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        List<string>? candidates = null;

        for (var attempt = 0; attempt < 10; attempt++)
        {
            tried.Add(model);
            using var request = new HttpRequestMessage(HttpMethod.Post, $"v1beta/models/{Uri.EscapeDataString(model)}:generateContent");
            request.Headers.Add("x-goog-api-key", key);
            request.Content = JsonContent.Create(body);
            using var response = await _client.SendAsync(request, ct);
            var text = await response.Content.ReadAsStringAsync(ct);

            if (response.IsSuccessStatusCode)
            {
                if (!string.Equals(model, configured, StringComparison.OrdinalIgnoreCase))
                    _logger.LogWarning("Gemini model '{Configured}' is not available - using '{Model}' instead. Set Gemini:Model to '{Model}' to silence this.", configured, model, model);
                _resolvedModel = model;
                return JsonDocument.Parse(text);
            }

            _logger.LogWarning("Gemini HTTP {Status} for model {Model}: {Detail}", (int)response.StatusCode, model, text.Length > 500 ? text[..500] : text);
            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                _resolvedModel = null;
                candidates ??= await BuildCandidatesAsync(key, ct);
                var next = candidates.FirstOrDefault(m => !tried.Contains(m));
                if (next != null) { model = next; continue; }
            }
            throw new HttpRequestException($"Gemini returned HTTP {(int)response.StatusCode}: {text}", null, response.StatusCode);
        }
        throw new HttpRequestException("Gemini returned HTTP 404: no usable model was found for this API key.", null, HttpStatusCode.NotFound);
    }

    /// <summary>Flash models this key can call (newest first), followed by a built-in list as a safety net.</summary>
    private async Task<List<string>> BuildCandidatesAsync(string key, CancellationToken ct)
    {
        var found = new List<(double Version, string Name)>();
        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, "v1beta/models?pageSize=200");
            request.Headers.Add("x-goog-api-key", key);
            using var response = await _client.SendAsync(request, ct);
            if (response.IsSuccessStatusCode)
            {
                using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
                if (doc.RootElement.TryGetProperty("models", out var models))
                    foreach (var m in models.EnumerateArray())
                    {
                        var name = m.TryGetProperty("name", out var n) ? n.GetString() ?? "" : "";
                        if (name.StartsWith("models/")) name = name[7..];
                        // Include text-generation Flash-Lite and Preview IDs too; the old pattern
                        // excluded "-lite" model IDs, so those were never discovered for fallback.
                        var match = System.Text.RegularExpressions.Regex.Match(name,
                            @"^gemini-(\d+(?:\.\d+)?)-flash(?:-lite)?(?:-preview(?:-[a-z0-9-]+)?)?$");
                        var canGenerate = m.TryGetProperty("supportedGenerationMethods", out var methods)
                            && methods.EnumerateArray().Any(x => x.GetString() == "generateContent");
                        if (match.Success && canGenerate)
                            found.Add((double.Parse(match.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture), name));
                    }
            }
        }
        catch (Exception ex) when (ex is HttpRequestException or JsonException or TaskCanceledException)
        { _logger.LogWarning(ex, "Could not list Gemini models; using the built-in fallback list."); }

        return found.OrderByDescending(x => x.Version).Select(x => x.Name)
            .Concat(FallbackModels).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }

    private static List<JsonElement> GetParts(JsonElement root)
    {
        if (!root.TryGetProperty("candidates", out var candidates) || candidates.GetArrayLength() == 0)
            throw new InvalidOperationException("Gemini returned no content (the request may have been blocked).");
        if (!candidates[0].TryGetProperty("content", out var content) || !content.TryGetProperty("parts", out var parts))
            throw new InvalidOperationException("Gemini returned no content.");
        return parts.EnumerateArray().ToList();
    }

    private static string? ExtractText(JsonElement root)
    {
        var text = string.Join("\n", GetParts(root)
            .Where(p => p.TryGetProperty("text", out _) && !(p.TryGetProperty("thought", out var t) && t.ValueKind == JsonValueKind.True))
            .Select(p => p.GetProperty("text").GetString()));
        return string.IsNullOrWhiteSpace(text) ? null : text;
    }
}
