using Microsoft.EntityFrameworkCore;
using StudentManagement.Data;
using StudentManagement.Models;

namespace StudentManagement.Services;

/// <summary>
/// Builds the always-on, role-scoped "Campus data" block that goes into the chatbot's system prompt.
/// Read-only. The user id and role come from the verified JWT, never from the browser.
/// For anything beyond this snapshot (other students, classes, dates...) the model calls the
/// role-checked tools in CampusToolService.
/// </summary>
public class CampusContextService
{
    private readonly AppDbContext _db;
    private readonly CampusDataService _data;
    public CampusContextService(AppDbContext db, CampusDataService data) { _db = db; _data = data; }

    public async Task<string> GetAsync(int userId, string role, CancellationToken ct)
    {
        var lines = new List<string>();
        var today = AppClock.Today;
        var me = await _db.Users.AsNoTracking().Where(u => u.Id == userId)
            .Select(u => new { u.FullName, u.IdNumber, u.Department, u.Email }).FirstOrDefaultAsync(ct);
        lines.Add($"Today (campus time, Asia/Dhaka): {today:yyyy-MM-dd}, {today.DayOfWeek}.");
        lines.Add($"Logged-in user: {me?.FullName ?? "unknown"} | role: {role} | ID number: {me?.IdNumber ?? "-"} | department: {me?.Department ?? "-"}");

        if (role == Roles.Student) await AddStudentAsync(lines, userId, today, ct);
        else if (role == Roles.Teacher) await AddTeacherAsync(lines, userId, today, ct);
        else if (role == Roles.Admin) await AddAdminAsync(lines, today, ct);
        else if (role == Roles.Staff) await AddStaffAsync(lines, userId, ct);

        var notices = await _data.VisibleNotices(userId, role).OrderByDescending(n => n.CreatedAt).Take(8)
            .Select(n => new { n.Title, n.Body, n.CreatedAt }).ToListAsync(ct);
        lines.Add("Recent notices visible to me: " + (notices.Count == 0 ? "none" :
            string.Join(" | ", notices.Select(n => $"[{n.CreatedAt:yyyy-MM-dd}] {n.Title}: {Trim(n.Body, 300)}"))));
        return string.Join("\n", lines);
    }

    private static string Trim(string s, int max) => s.Length > max ? s[..max] + "…" : s;

    private async Task AddStudentAsync(List<string> lines, int userId, DateOnly today, CancellationToken ct)
    {
        var health = await _data.StudentHealthAsync(userId, ct);
        lines.Add("My enrolled classes and attendance (75% is the usual exam-eligibility rule):\n- " +
            (health.Count == 0 ? "not enrolled in any class yet" : string.Join("\n- ", health.Select(CampusDataService.DescribeHealth))));

        var results = await _data.StudentResultsAsync(userId, ct);
        lines.Add("My results (marks: mid + final + assignment + attendance up to 10 = total out of 110):\n- " +
            (results.Count == 0 ? "no results entered yet" : string.Join("\n- ", results.Select(CampusDataService.DescribeResult))));

        var routine = await _data.VisibleRoutine(userId, Roles.Student).OrderBy(r => r.StartTime)
            .Select(r => new { r.Day, r.StartTime, r.EndTime, r.CourseName, r.Room, Teacher = r.Teacher != null ? r.Teacher.FullName : null })
            .Take(60).ToListAsync(ct);
        var ordered = routine.OrderBy(r => Array.IndexOf(CampusDataService.DayOrder, r.Day)).ThenBy(r => r.StartTime).ToList();
        var todayName = today.DayOfWeek.ToString();
        var todays = ordered.Where(r => r.Day == todayName).ToList();
        lines.Add("My classes today: " + (todays.Count == 0 ? "none scheduled in the routine" :
            string.Join("; ", todays.Select(r => $"{r.StartTime}-{r.EndTime} {r.CourseName} room {r.Room}"))));
        lines.Add("My weekly routine (matched by course name): " + (ordered.Count == 0 ? "none" :
            string.Join("; ", ordered.Select(r => $"{r.Day} {r.StartTime}-{r.EndTime} {r.CourseName} room {r.Room}"))));
    }

    private async Task AddTeacherAsync(List<string> lines, int userId, DateOnly today, CancellationToken ct)
    {
        var classes = await _db.AcademicClasses.AsNoTracking().Where(c => c.TeacherId == userId && c.IsActive)
            .Select(c => c.Id).ToListAsync(ct);
        var parts = new List<string>();
        foreach (var id in classes.Take(15))
        {
            var s = await _data.ClassSummaryAsync(id, ct);
            if (s == null) continue;
            parts.Add($"[class id {s.ClassId}] {s.Course} ({s.Section}) room {s.Room}: {s.Students.Count} students, {s.Held} classes held, average attendance {s.AveragePercent}%, {s.AtRiskCount} students below 75%");
        }
        lines.Add("My active classes:\n- " + (parts.Count == 0 ? "none" : string.Join("\n- ", parts)));

        var routine = await _db.RoutineEntries.AsNoTracking().Where(r => r.TeacherId == userId)
            .Select(r => new { r.Day, r.StartTime, r.EndTime, r.CourseName, r.Room }).ToListAsync(ct);
        var ordered = routine.OrderBy(r => Array.IndexOf(CampusDataService.DayOrder, r.Day)).ThenBy(r => r.StartTime).ToList();
        var todayName = today.DayOfWeek.ToString();
        lines.Add("My classes today: " + (ordered.Any(r => r.Day == todayName)
            ? string.Join("; ", ordered.Where(r => r.Day == todayName).Select(r => $"{r.StartTime}-{r.EndTime} {r.CourseName} room {r.Room}"))
            : "none scheduled in the routine"));
        lines.Add("My weekly routine: " + (ordered.Count == 0 ? "none" :
            string.Join("; ", ordered.Select(r => $"{r.Day} {r.StartTime}-{r.EndTime} {r.CourseName} room {r.Room}"))));

        var gate = await _db.Attendance.AsNoTracking().AnyAsync(a => a.UserId == userId && a.ClassId == null && a.Date == today, ct);
        lines.Add("My gate check-in today: " + (gate ? "done" : "not recorded yet"));
    }

    private async Task AddAdminAsync(List<string> lines, DateOnly today, CancellationToken ct)
    {
        var students = await _db.Users.AsNoTracking().CountAsync(u => u.Role == Roles.Student, ct);
        var teachers = await _db.Users.AsNoTracking().CountAsync(u => u.Role == Roles.Teacher, ct);
        var staff = await _db.Users.AsNoTracking().CountAsync(u => u.Role == Roles.Staff, ct);
        var classes = await _db.AcademicClasses.AsNoTracking().CountAsync(c => c.IsActive, ct);
        var enrollments = await _db.ClassEnrollments.AsNoTracking().CountAsync(ct);
        var todayClassCheckins = await _db.Attendance.AsNoTracking().CountAsync(a => a.Date == today && a.ClassId != null, ct);
        var todayGate = await _db.Attendance.AsNoTracking().CountAsync(a => a.Date == today && a.ClassId == null, ct);
        var notices = await _db.Notices.AsNoTracking().CountAsync(ct);
        lines.Add($"Campus totals: {students} students, {teachers} teachers, {staff} staff, {classes} active classes, {enrollments} enrollments, {notices} notices.");
        lines.Add($"Today's attendance records: {todayClassCheckins} student class check-ins, {todayGate} teacher/staff gate check-ins.");
        var recent = await _db.AuditLogs.AsNoTracking().OrderByDescending(l => l.Timestamp).Take(5)
            .Select(l => new { l.Timestamp, l.ActorName, l.Action, l.Details }).ToListAsync(ct);
        lines.Add("Latest audit activity: " + (recent.Count == 0 ? "none" :
            string.Join(" | ", recent.Select(l => $"[{l.Timestamp:yyyy-MM-dd HH:mm}] {l.ActorName}: {l.Action} - {Trim(l.Details, 120)}"))));
    }

    private async Task AddStaffAsync(List<string> lines, int userId, CancellationToken ct)
    {
        var recent = await _db.Attendance.AsNoTracking().Where(a => a.UserId == userId && a.ClassId == null)
            .OrderByDescending(a => a.Date).Take(7).Select(a => a.Date).ToListAsync(ct);
        lines.Add("My recent gate check-in dates: " + (recent.Count == 0 ? "none" : string.Join(", ", recent.Select(d => d.ToString("yyyy-MM-dd")))));
    }
}
