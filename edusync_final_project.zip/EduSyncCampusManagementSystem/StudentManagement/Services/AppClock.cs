namespace StudentManagement.Services;

/// <summary>
/// One place for "what time is it?" so the whole app agrees.
///
/// WHY THIS EXISTS (root cause of the broken attendance API):
/// Npgsql 6+ maps DateTime to PostgreSQL "timestamp with time zone" and REFUSES to write or
/// compare a DateTime whose Kind is Local ("Cannot write DateTime with Kind=Local ...").
/// The old code used DateTime.Now everywhere in AttendanceController, so starting a session,
/// scanning a QR, self check-in and corrections all crashed with HTTP 500.
///  - Anything stored in / compared against the database  -> AppClock.UtcNow
///  - "Which calendar day is it for the campus?"           -> AppClock.Today (Bangladesh time)
/// </summary>
public static class AppClock
{
    private static readonly TimeZoneInfo CampusZone = ResolveZone();

    private static TimeZoneInfo ResolveZone()
    {
        foreach (var id in new[] { "Asia/Dhaka", "Bangladesh Standard Time" })
        {
            try { return TimeZoneInfo.FindSystemTimeZoneById(id); } catch { /* try next */ }
        }
        // Bangladesh is a fixed UTC+6 (no daylight saving) - safe fallback.
        return TimeZoneInfo.CreateCustomTimeZone("BST-fixed", TimeSpan.FromHours(6), "Bangladesh", "Bangladesh");
    }

    /// <summary>UTC instant - the only kind of DateTime that may touch PostgreSQL timestamptz.</summary>
    public static DateTime UtcNow => DateTime.UtcNow;

    /// <summary>Today's calendar date on campus (Asia/Dhaka), independent of the server's own time zone.</summary>
    public static DateOnly Today => DateOnly.FromDateTime(TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, CampusZone));

    /// <summary>The campus calendar date (Asia/Dhaka) of a stored UTC timestamp.</summary>
    public static DateOnly DateOf(DateTime stamp)
    {
        var utc = stamp.Kind == DateTimeKind.Unspecified ? DateTime.SpecifyKind(stamp, DateTimeKind.Utc) : stamp.ToUniversalTime();
        return DateOnly.FromDateTime(TimeZoneInfo.ConvertTimeFromUtc(utc, CampusZone));
    }
}
