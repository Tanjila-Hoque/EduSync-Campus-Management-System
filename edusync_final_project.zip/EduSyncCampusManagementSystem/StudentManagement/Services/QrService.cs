using System.Collections.Concurrent;
using QRCoder;

namespace StudentManagement.Services;

/// <summary>Turns a QR payload into a PNG (base64) the React app can show as an &lt;img&gt;.
/// Error-correction M gives a less dense picture than Q, so phones read it faster and from further away.
/// Only the picture changes - the text inside (and so every QR already downloaded) stays valid.</summary>
public class QrService
{
    private readonly ConcurrentDictionary<string, string> _cache = new();

    /// <param name="pixelsPerModule">10 is fine on screen; use 20 for print-quality downloads.</param>
    public string GeneratePngBase64(string payload, int pixelsPerModule = 10)
        => _cache.GetOrAdd($"{pixelsPerModule}|{payload}", _ => Generate(payload, pixelsPerModule));

    private static string Generate(string payload, int pixelsPerModule) => Convert.ToBase64String(Render(payload, pixelsPerModule));

    private static byte[] Render(string payload, int pixelsPerModule)
    {
        using var generator = new QRCodeGenerator();
        using var data = generator.CreateQrCode(payload, QRCodeGenerator.ECCLevel.M);
        var pngQr = new PngByteQRCode(data);
        return pngQr.GetGraphic(pixelsPerModule);
    }
}
