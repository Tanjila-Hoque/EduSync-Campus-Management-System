# Gemini API setup

## Model

The default model is `gemini-3.8-flash`, which appears in Google's current official Gemini API model list: https://ai.google.dev/gemini-api/docs/models. If the API key cannot access it, the service queries the API's available model list after a model 404 and tries another text-generation Flash/Flash-Lite ID. A 400/403 is usually a key, API authorization, model support, or project issue; fallback does not conceal authentication errors.

## API key (important)

Never store a real Gemini key in `appsettings.json`, `appsettings.Development.json`, React environment files, Git, a shared ZIP, or chat. Keys previously included in a ZIP or shared in chat must be revoked and replaced. A key was present in the supplied project ZIP during troubleshooting; treat it as exposed and revoke it in Google AI Studio. Create a new Gemini API key, make sure it is authorized/restricted for the Gemini API, and use `SETUP_LOCAL_SECRETS.ps1` to store it.

Google's current guidance says unrestricted standard keys are rejected; new AI Studio keys default to authorization keys, and keys should be managed in AI Studio: https://ai.google.dev/gemini-api/docs/generate-content/api-key.

The backend reads `Gemini:ApiKey` and `Gemini:Model` from .NET configuration. .NET User Secrets override appsettings. Restart the backend after changing settings.

## Errors

- HTTP 400/403/401: create a fresh key and confirm Gemini API access for its Google project. Do not post the key in logs/screenshots.
- HTTP 404: the configured model ID may not be available to this key; the backend tries discovered text-generation Flash models.
- HTTP 429: quota/rate limit; check usage/limits in AI Studio.
- Empty or unavailable response: inspect backend terminal logs for status and error summary; never paste secrets in a support request.
