@echo off
REM ============================================================
REM  EduSync - download the campus background photos (run once)
REM  Double-click this file (needs internet). The photos are saved in
REM  ClientApp\public\photos and then work WITHOUT internet.
REM ============================================================
cd /d "%~dp0"
if not exist "ClientApp\public\photos" mkdir "ClientApp\public\photos"
set UA=EduSyncStudentProject/1.0
set BASE=https://commons.wikimedia.org/wiki/Special:FilePath

echo Downloading photo 1 of 4 ...
curl -L -A "%UA%" -o "ClientApp\public\photos\campus-1.jpg" "%BASE%/Main_Building_at_the_University_of_Notre_Dame.jpg?width=1600"
echo Downloading photo 2 of 4 ...
curl -L -A "%UA%" -o "ClientApp\public\photos\campus-2.jpg" "%BASE%/Main_Building_-_Drexel_University_%%2853590618820%%29.jpg?width=1600"
echo Downloading photo 3 of 4 ...
curl -L -A "%UA%" -o "ClientApp\public\photos\campus-3.jpg" "%BASE%/University_of_Mary_Main_Campus.jpg?width=1600"
echo Downloading photo 4 of 4 ...
curl -L -A "%UA%" -o "ClientApp\public\photos\campus-4.jpg" "%BASE%/Whitman_College_Lawn.jpg?width=1600"

echo.
echo Done. Refresh the browser (Ctrl+F5). Files are in ClientApp\public\photos
pause
