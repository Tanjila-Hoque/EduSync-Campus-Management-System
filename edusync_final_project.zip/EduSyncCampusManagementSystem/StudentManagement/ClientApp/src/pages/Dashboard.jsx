import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext.jsx";
import { quoteOfTheDay } from "../utils/quotes.js";
import { classLabel, timeAgo } from "../utils/format.js";
import { localDateIso } from "../utils/errors.js";
import Icon from "../components/Icon.jsx";
import EmptyState from "../components/EmptyState.jsx";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

function greeting() {
  const h = new Date().getHours();
  return h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
}

/** Same data the old dashboard used (admin summary) plus read-only widgets built from endpoints that already
 *  exist (notices, routine, classes, attendance health, results) so every role gets a useful home screen. */
export default function Dashboard() {
  const { user } = useAuth();
  const role = user.role;

  const [summary, setSummary] = useState(null);
  const [notices, setNotices] = useState([]);
  const [routine, setRoutine] = useState([]);
  const [classes, setClasses] = useState([]);
  const [health, setHealth] = useState(null);
  const [results, setResults] = useState([]);
  const [myAttendance, setMyAttendance] = useState([]);
  const [successRadar, setSuccessRadar] = useState(null);
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const quiet = (p, set) => p.then(({ data }) => set(data)).catch(() => {});
    quiet(api.get("/notices"), setNotices);
    if (role === "Admin" || role === "Teacher" || role === "Student") quiet(api.get("/student-success/radar"), setSuccessRadar);
    quiet(api.get("/routine"), setRoutine);
    if (role === "Admin") quiet(api.get("/dashboard/summary"), setSummary);
    if (role === "Teacher" || role === "Student") quiet(api.get("/classes"), setClasses);
    if (role === "Student") {
      quiet(api.get("/analytics/my"), setHealth);
      quiet(api.get("/results"), setResults);
    }
    if (role === "Staff") quiet(api.get("/attendance/my"), setMyAttendance);
  }, [role]);

  const today = DAYS[now.getDay()];
  const todaysRoutine = useMemo(() => {
    let list = routine.filter((r) => r.day === today);
    if (role === "Teacher") list = list.filter((r) => r.teacherName === user.fullName);
    return list.sort((a, b) => a.startTime.localeCompare(b.startTime));
  }, [routine, today, role, user.fullName]);

  const firstName = (user.fullName || "").split(" ")[0];
  const checkedInToday = myAttendance.some((r) => !r.classId && r.date === localDateIso());

  const actions = {
    Admin: [
      { to: "/people", icon: "users", label: "Manage people" },
      { to: "/campus-intelligence", icon: "chart", label: "Campus intelligence" },
      { to: "/classes", icon: "book", label: "Classes" },
      { to: "/attendance", icon: "qr", label: "Attendance QR" },
      { to: "/routine", icon: "calendar", label: "Routine" },
      { to: "/notices", icon: "megaphone", label: "Post a notice" },
      { to: "/audit-log", icon: "shield", label: "Audit log" }
    ],
    Teacher: [
      { to: "/attendance", icon: "qr", label: "Take attendance" },
      { to: "/classes", icon: "book", label: "My classes" },
      { to: "/results", icon: "award", label: "Enter results" },
      { to: "/insights", icon: "chart", label: "Attendance insights" },
      { to: "/notices", icon: "megaphone", label: "Message students" },
      { to: "/people", icon: "users", label: "Students" }
    ],
    Student: [
      { to: "/attendance", icon: "qr", label: "Scan attendance" },
      { to: "/classes", icon: "book", label: "My classes" },
      { to: "/results", icon: "award", label: "My results" },
      { to: "/insights", icon: "chart", label: "Attendance health" },
      { to: "/routine", icon: "calendar", label: "Routine" },
      { to: "/notices", icon: "megaphone", label: "Notices" }
    ],
    Staff: [
      { to: "/attendance", icon: "qr", label: "Daily check-in" },
      { to: "/routine", icon: "calendar", label: "Routine" },
      { to: "/notices", icon: "megaphone", label: "Notices" }
    ]
  }[role] || [];

  const heroLine = {
    Admin: "Here's what's happening across the campus today.",
    Teacher: "Your classes, attendance and student updates at a glance.",
    Student: "Your classes, attendance health and latest updates.",
    Staff: "Your daily check-in and the campus updates that matter to you."
  }[role];

  return (
    <div className="page">
      <section className="hero">
        <div>
          <div className="hero-eyebrow">{greeting()}</div>
          <h2>{firstName || user.fullName}, welcome back</h2>
          <p>{heroLine}</p>
          <div className="hero-meta">
            <span className="hero-chip"><Icon name="user" size={13} /> {role}</span>
            {user.idNumber && <span className="hero-chip">ID {user.idNumber}</span>}
            {user.department && <span className="hero-chip">{user.department}</span>}
          </div>
        </div>
        <div className="hero-clock">
          <strong>{now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</strong>
          <span>{now.toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "short" })}</span>
        </div>
      </section>

      {role === "Admin" && <AdminStats summary={summary} />}
      {role === "Teacher" && <TeacherStats classes={classes} todayCount={todaysRoutine.length} />}
      {role === "Student" && <StudentStats health={health} classes={classes} results={results} />}
      {role === "Staff" && <StaffStatus checkedIn={checkedInToday} todayCount={todaysRoutine.length} />}

      {successRadar && (role === "Admin" || role === "Teacher" || role === "Student") && (
        <section className="card" style={{ marginBottom: 18 }}>
          <div className="card-head">
            <div><h2>Student Success Radar</h2><p className="sub">Live academic and attendance signals from PostgreSQL</p></div>
            <Link to="/success-radar" className="btn-secondary btn-sm">Explore insights</Link>
          </div>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <div style={{ flex: "1 1 130px", padding: 12, borderRadius: 12, background: "rgba(214,69,69,.09)" }}>
              <div className="muted small-note">{role === "Student" ? "Your risk score" : "At-risk students"}</div>
              <strong style={{ fontSize: 25, color: "#d64545" }}>{role === "Student" ? (successRadar.students[0]?.riskLevel || "No data") : successRadar.atRisk}</strong>
            </div>
            <div style={{ flex: "1 1 130px", padding: 12, borderRadius: 12, background: "rgba(217,146,43,.10)" }}>
              <div className="muted small-note">Needs attention</div><strong style={{ fontSize: 25, color: "#b87816" }}>{role === "Student" ? (successRadar.students[0]?.riskScore ?? "—") : successRadar.needsAttention}</strong>
            </div>
            <div style={{ flex: "1 1 130px", padding: 12, borderRadius: 12, background: "rgba(31,157,85,.09)" }}>
              <div className="muted small-note">{role === "Student" ? "Attendance" : "Average attendance"}</div><strong style={{ fontSize: 25, color: "#1f9d55" }}>{role === "Student" ? `${successRadar.students[0]?.attendancePercent ?? 0}%` : `${successRadar.averageAttendance}%`}</strong>
            </div>
          </div>
          {role === "Student" && successRadar.students[0]?.reasons?.length > 0 && <p style={{ marginBottom: 0, marginTop: 12 }}><strong>Support signal:</strong> {successRadar.students[0].reasons[0]}</p>}
        </section>
      )}

      <div className="grid-main">
        <div className="stack">
          <div className="card">
            <div className="card-head">
              <div>
                <h2>Quick actions</h2>
                <p className="sub">Jump straight to what you do most.</p>
              </div>
            </div>
            <div className="quick-grid">
              {actions.map((a) => (
                <Link key={a.to + a.label} to={a.to} className="quick-link">
                  <span className="quick-ico"><Icon name={a.icon} size={18} /></span>
                  <span>{a.label}</span>
                  <Icon name="arrowRight" size={15} className="quick-arrow" />
                </Link>
              ))}
            </div>
          </div>

          {(role === "Teacher" || role === "Student") && (
            <div className="card">
              <div className="card-head">
                <div>
                  <h2>{role === "Teacher" ? "My classes" : "My enrolled classes"}</h2>
                  <p className="sub">{classes.length} {classes.length === 1 ? "class" : "classes"}</p>
                </div>
                <Link to="/classes" className="btn-secondary btn-sm">View all</Link>
              </div>
              {classes.length === 0 ? (
                <EmptyState icon="book" title="No classes yet">
                  {role === "Student" ? "Open Attendance → My classes to join the classes you attend." : "Classes assigned to you by the admin will appear here."}
                </EmptyState>
              ) : (
                <div className="class-tiles">
                  {classes.slice(0, 6).map((c) => (
                    <div key={c.id} className="class-tile">
                      <div className="code">{c.courseName}</div>
                      <div className="meta">{c.section ? `Section ${c.section}` : "No section"}{c.room ? ` · Room ${c.room}` : ""}</div>
                      <div className="figures">
                        {role === "Teacher" ? <span><strong>{c.studentCount}</strong>students</span> : <span><strong>{c.teacherName || "—"}</strong>teacher</span>}
                        <span><strong>{c.department || "—"}</strong>department</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {role === "Student" && health?.classes?.length > 0 && (
            <div className="card">
              <div className="card-head">
                <div>
                  <h2>Attendance health</h2>
                  <p className="sub">The 75% rule, class by class.</p>
                </div>
                <Link to="/insights" className="btn-secondary btn-sm">Details</Link>
              </div>
              <div className="health-list">
                {health.classes.slice(0, 5).map((c) => (
                  <div key={c.classId} className="health-row">
                    <div className="health-top">
                      <strong>{classLabel(c)}</strong>
                      <span className={`pill ${c.status === "AtRisk" ? "red" : c.status === "Watch" ? "amber" : c.status === "Safe" ? "green" : "gray"}`}>
                        {c.status === "NoData" ? "No classes yet" : `${c.percent}%`}
                      </span>
                    </div>
                    <div className={`progress slim ${c.status === "AtRisk" ? "bad" : c.status === "Watch" ? "warn" : ""}`}>
                      <span style={{ width: `${Math.min(100, c.percent)}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {role === "Admin" && summary?.recentActivity?.length > 0 && (
            <div className="card">
              <div className="card-head">
                <div>
                  <h2>Recent activity</h2>
                  <p className="sub">The latest actions recorded across the system.</p>
                </div>
                <Link to="/audit-log" className="btn-secondary btn-sm">Audit log</Link>
              </div>
              <ul className="activity-list">
                {summary.recentActivity.map((a) => (
                  <li key={a.id}>
                    <span className="activity-dot" />
                    <div>
                      <div><strong>{a.actorName}</strong> <span className="muted">· {a.details}</span></div>
                      <div className="muted small-note">{timeAgo(a.timestamp)}</div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="stack">
          <div className="card">
            <div className="card-head">
              <div>
                <h2>Today's schedule</h2>
                <p className="sub">{today}</p>
              </div>
              <Link to="/routine" className="btn-secondary btn-sm">Routine</Link>
            </div>
            {todaysRoutine.length === 0 ? (
              <EmptyState icon="calendar" title="No classes today">Enjoy the free time.</EmptyState>
            ) : (
              <ul className="timeline">
                {todaysRoutine.map((r) => (
                  <li key={r.id}>
                    <div className="tl-time">{r.startTime}<span>{r.endTime}</span></div>
                    <div className="tl-body">
                      <strong>{r.courseName}</strong>
                      <span>{r.room ? `Room ${r.room}` : "Room not set"}{role !== "Student" && r.teacherName ? ` · ${r.teacherName}` : ""}</span>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="card">
            <div className="card-head">
              <div>
                <h2>Latest notices</h2>
                <p className="sub">Announcements meant for you.</p>
              </div>
              <Link to="/notices" className="btn-secondary btn-sm">All</Link>
            </div>
            {notices.length === 0 ? (
              <EmptyState icon="megaphone" title="No notices yet" />
            ) : (
              notices.slice(0, 4).map((n) => (
                <div key={n.id} className="mini-notice">
                  <strong>{n.title}</strong>
                  <p>{n.body}</p>
                  <span className="muted small-note">{timeAgo(n.createdAt)}</span>
                </div>
              ))
            )}
          </div>

          {role === "Student" && results.length > 0 && (
            <div className="card">
              <div className="card-head">
                <div>
                  <h2>Latest results</h2>
                  <p className="sub">Your most recent grades.</p>
                </div>
                <Link to="/results" className="btn-secondary btn-sm">All</Link>
              </div>
              {results.slice(0, 3).map((r) => (
                <div key={r.id} className="result-row">
                  <div>
                    <strong>{r.courseName}</strong>
                    <span className="muted small-note">Total {r.total}</span>
                  </div>
                  <span className={`badge grade-${r.grade.replace("+", "plus").replace("-", "minus")}`}>{r.grade}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="institution-footer">
        <span><strong>EduSync</strong> · Campus Management</span>
        <span className="foot-quote">“{quoteOfTheDay()}”</span>
        <span>Role-based access · Secure sessions</span>
      </div>
    </div>
  );
}

function CountUp({ value }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    if (typeof value !== "number") return undefined;
    let raf; let start;
    const step = (t) => {
      if (!start) start = t;
      const p = Math.min(1, (t - start) / 700);
      setN(Math.round(value * p));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return typeof value === "number" ? n : (value ?? "–");
}

function Stat({ icon, tone, value, label }) {
  return (
    <div className="stat-card">
      <div className={`stat-icon ${tone}`}><Icon name={icon} size={22} /></div>
      <div>
        <div className="stat-value"><CountUp value={value} /></div>
        <div className="stat-label">{label}</div>
      </div>
    </div>
  );
}

function AdminStats({ summary }) {
  if (!summary) return <div className="stat-grid">{[0, 1, 2, 3, 4].map((i) => <div key={i} className="stat-card skeleton" />)}</div>;
  const total = summary.totalStudents + summary.totalTeachers + summary.totalStaff || 1;
  const parts = [
    { label: "Students", n: summary.totalStudents, cls: "s1" },
    { label: "Teachers", n: summary.totalTeachers, cls: "s2" },
    { label: "Staff", n: summary.totalStaff, cls: "s3" }
  ];
  return (
    <>
      <div className="stat-grid">
        <Stat icon="cap" tone="blue" value={summary.totalStudents} label="Students" />
        <Stat icon="users" tone="teal" value={summary.totalTeachers} label="Teachers" />
        <Stat icon="briefcase" tone="gold" value={summary.totalStaff} label="Staff" />
        <Stat icon="checkCircle" tone="green" value={summary.todayAttendanceCount} label="Present today" />
        <Stat icon="megaphone" tone="violet" value={summary.noticeCount} label="Notices" />
      </div>
      <div className="card mix-card">
        <div className="card-head">
          <div>
            <h2>Campus community</h2>
            <p className="sub">{total} accounts across Students, Teachers and Staff.</p>
          </div>
        </div>
        <div className="mix-bar">
          {parts.map((p) => <span key={p.label} className={p.cls} style={{ width: `${(p.n / total) * 100}%` }} title={`${p.label}: ${p.n}`} />)}
        </div>
        <div className="mix-legend">
          {parts.map((p) => (
            <span key={p.label}><i className={p.cls} /> {p.label} <strong>{p.n}</strong> <em>{Math.round((p.n / total) * 100)}%</em></span>
          ))}
        </div>
      </div>
    </>
  );
}

function TeacherStats({ classes, todayCount }) {
  const students = classes.reduce((sum, c) => sum + (c.studentCount || 0), 0);
  return (
    <div className="stat-grid">
      <Stat icon="book" tone="blue" value={classes.length} label="My classes" />
      <Stat icon="cap" tone="teal" value={students} label="Enrolled students (all classes)" />
      <Stat icon="calendar" tone="gold" value={todayCount} label="Classes today" />
    </div>
  );
}

function StudentStats({ health, classes, results }) {
  const avg = health ? `${health.averagePercent}%` : "–";
  return (
    <div className="stat-grid">
      <Stat icon="book" tone="blue" value={classes.length} label="Classes joined" />
      <Stat icon="chart" tone={health && health.averagePercent < 75 ? "red" : "green"} value={avg} label="Average attendance" />
      <Stat icon="alert" tone={health?.atRiskCount ? "red" : "teal"} value={health?.atRiskCount ?? 0} label="Classes below 75%" />
      <Stat icon="award" tone="violet" value={results.length} label="Results published" />
    </div>
  );
}

function StaffStatus({ checkedIn, todayCount }) {
  return (
    <div className="stat-grid">
      <div className={`stat-card wide ${checkedIn ? "ok" : "pending"}`}>
        <div className={`stat-icon ${checkedIn ? "green" : "gold"}`}><Icon name={checkedIn ? "checkCircle" : "clock"} size={22} /></div>
        <div>
          <div className="stat-value small">{checkedIn ? "Checked in today" : "Not checked in yet"}</div>
          <div className="stat-label">{checkedIn ? "Your daily attendance is recorded." : "Scan today's check-in QR from the Attendance page."}</div>
        </div>
        {!checkedIn && <Link to="/attendance" className="btn-primary btn-sm">Check in</Link>}
      </div>
      <Stat icon="calendar" tone="blue" value={todayCount} label="Classes on today's routine" />
    </div>
  );
}
