import { useEffect, useState } from "react";
import api from "../api/axios";
import { errMsg } from "../utils/errors.js";
import { useAuth } from "../context/AuthContext.jsx";
import { timeAgo } from "../utils/format.js";
import PageHeader from "../components/PageHeader.jsx";
import EmptyState from "../components/EmptyState.jsx";
import Avatar from "../components/Avatar.jsx";
import Icon from "../components/Icon.jsx";

export default function Notices() {
  const { user } = useAuth();
  const canPost = ["Admin", "Teacher"].includes(user.role);
  const [notices, setNotices] = useState([]), [classes, setClasses] = useState([]), [loading, setLoading] = useState(true), [error, setError] = useState(""), [posting, setPosting] = useState(false);
  const [page, setPage] = useState(1), [pageSize, setPageSize] = useState(10), [totalCount, setTotalCount] = useState(0), [totalPages, setTotalPages] = useState(0);
  const [search, setSearch] = useState(""), [debounced, setDebounced] = useState("");
  const [form, setForm] = useState({ title: "", body: "", audienceRole: "", targetClassId: "" });
  const isTeacher = user.role === "Teacher";

  function load() {
    setLoading(true);
    api.get("/notices", { params: { page, pageSize, search: debounced || undefined } })
      .then(({ data }) => {
        const rows = Array.isArray(data) ? data : (data.items || []);
        setNotices(rows);
        setTotalCount(Array.isArray(data) ? data.length : (data.totalCount || 0));
        setTotalPages(Array.isArray(data) ? 1 : (data.totalPages || 0));
        if (!Array.isArray(data) && data.page && data.page !== page) setPage(data.page);
      })
      .catch((e) => setError(errMsg(e, "Could not load notices.")))
      .finally(() => setLoading(false));
  }
  // Search waits until typing stops, then restarts from page 1.
  useEffect(() => {
    const t = setTimeout(() => { setDebounced(search.trim()); setPage(1); }, 350);
    return () => clearTimeout(t);
  }, [search]);
  useEffect(() => { load(); }, [page, pageSize, debounced]);
  useEffect(() => {
    const aiDraft = sessionStorage.getItem("aiNoticeDraft");
    if (canPost && aiDraft) {
      sessionStorage.removeItem("aiNoticeDraft");
      const lines = aiDraft.split("\n");
      setForm(f => ({ ...f, title: lines[0]?.replace(/^#+\s*/, "").slice(0, 180) || "AI Notice", body: lines.slice(1).join("\n").trim() || aiDraft }));
    }
    if (canPost) api.get("/classes").then(({ data }) => setClasses(data)).catch(() => {});
  }, []);

  async function post(e) {
    e.preventDefault();
    setError("");
    setPosting(true);
    try {
      await api.post("/notices", {
        title: form.title,
        body: form.body,
        audienceRole: isTeacher ? "Student" : (form.audienceRole || null),
        targetClassId: form.targetClassId ? Number(form.targetClassId) : null
      });
      setForm({ title: "", body: "", audienceRole: "", targetClassId: "" });
      load();
    } catch (err) {
      setError(errMsg(err, "Could not post the notice."));
    } finally {
      setPosting(false);
    }
  }

  async function del(id) {
    if (!confirm("Delete this notice?")) return;
    try {
      await api.delete(`/notices/${id}`);
      load();
    } catch (e) {
      setError(errMsg(e, "Could not delete the notice."));
    }
  }

  const scope = (n) =>
    n.targetClassName
      ? { icon: "book", text: n.targetClassName, tone: "blue" }
      : n.audienceRole
        ? { icon: "users", text: `${n.audienceRole}s only`, tone: "violet" }
        : { icon: "megaphone", text: "Everyone", tone: "gold" };

  return (
    <div className="page">
      <PageHeader
        icon="megaphone"
        title="Notices & Announcements"
        subtitle="Stay updated with important academic and campus messages."
      />

      {error && <div className="auth-error"><Icon name="alert" size={16} /> {error}</div>}

      {canPost && (
        <form onSubmit={post} className="composer">
          <div className="composer-head">
            <span className="composer-ico"><Icon name="edit" size={18} /></span>
            <div>
              <div className="section-kicker">{isTeacher ? "Private class announcement" : "Campus announcement"}</div>
              <h2>{isTeacher ? "Message your own students" : "Publish a campus notice"}</h2>
              <p className="sub">
                {isTeacher
                  ? "Only students enrolled in the selected class will receive this notice."
                  : "Choose whether this notice is visible to everyone, a role, or a specific class."}
              </p>
            </div>
          </div>
          <input placeholder="Announcement title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          <textarea rows={4} placeholder="Write the announcement…" value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} required />
          <div className="row">
            <select value={form.targetClassId} onChange={(e) => setForm({ ...form, targetClassId: e.target.value })} required={isTeacher}>
              <option value="">{isTeacher ? "Select your class" : "Optional: target a class"}</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.courseName}{c.section ? ` · ${c.section}` : ""}{c.teacherName ? ` — ${c.teacherName}` : ""}
                </option>
              ))}
            </select>
            {!isTeacher && (
              <select value={form.audienceRole} onChange={(e) => setForm({ ...form, audienceRole: e.target.value })}>
                <option value="">Everyone</option>
                <option value="Student">Students</option>
                <option value="Teacher">Teachers</option>
                <option value="Staff">Staff</option>
                <option value="Admin">Admins</option>
              </select>
            )}
            <button className="btn-primary" disabled={posting}>
              <Icon name="send" size={16} /> {posting ? "Publishing…" : "Publish announcement"}
            </button>
          </div>
        </form>
      )}

      {user.role === "Staff" && (
        <div className="auth-info">
          <Icon name="info" size={16} />
          <span><strong>Staff view.</strong> You have read-only access to campus announcements. Posting is restricted to Teachers and Admins.</span>
        </div>
      )}

      <div className="card flush">
        <div className="table-toolbar">
          <div className="search-box">
            <Icon name="search" size={16} />
            <input placeholder="Search announcements" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <div className="datatable-toolbar-right">
            <label className="datatable-size-label">Rows
              <select value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }} aria-label="Rows per page">
                <option value={5}>5</option><option value={10}>10</option><option value={25}>25</option><option value={50}>50</option>
              </select>
            </label>
            <span className="muted">{totalCount} {totalCount === 1 ? "announcement" : "announcements"}</span>
          </div>
        </div>
        {loading && notices.length === 0 ? (
          <p className="muted" style={{ padding: 24 }}>Loading announcements…</p>
        ) : notices.length === 0 ? (
          <EmptyState icon="megaphone" title={debounced ? "No matching announcements" : "No announcements yet"}>{debounced ? "Try a different search." : "New campus messages will appear here."}</EmptyState>
        ) : (
          <div style={{ opacity: loading ? 0.6 : 1, transition: "opacity .15s" }}>
          {notices.map((n) => {
            const s = scope(n);
            return (
              <article key={n.id} className={`notice-item tone-${s.tone}`}>
                {user.role !== "Student" ? <Avatar name={n.createdByName} size={42} /> : <span className="notice-badge"><Icon name="bell" size={18} /></span>}
                <div className="notice-body">
                  <div className="notice-top">
                    <div className="notice-title-row">
                      <h3>{n.title}</h3>
                      <span className={`pill ${s.tone}`}><Icon name={s.icon} size={12} /> {s.text}</span>
                    </div>
                    {(user.role === "Admin" || n.createdByName === user.fullName) && (
                      <button className="btn-danger btn-sm" onClick={() => del(n.id)}><Icon name="trash" size={14} /> Delete</button>
                    )}
                  </div>
                  <p className="body">{n.body}</p>
                  <div className="notice-meta">
                    {user.role !== "Student" && <><span>By {n.createdByName}</span><span>•</span></>}
                    <span title={new Date(n.createdAt).toLocaleString()}>{timeAgo(n.createdAt)}</span>
                  </div>
                </div>
              </article>
            );
          })}
          </div>
        )}
        {totalCount > 0 && (
          <div className="datatable-footer">
            <span className="muted">Showing {(page - 1) * pageSize + 1}–{Math.min(page * pageSize, totalCount)} of {totalCount}</span>
            <div className="datatable-pagination">
              <button type="button" className="btn-secondary btn-sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1 || loading}>Previous</button>
              <span className="datatable-page-indicator">Page {Math.min(page, Math.max(totalPages, 1))} of {Math.max(totalPages, 1)}</span>
              <button type="button" className="btn-secondary btn-sm" onClick={() => setPage((p) => Math.min(Math.max(totalPages, 1), p + 1))} disabled={page >= totalPages || loading || totalPages === 0}>Next</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
