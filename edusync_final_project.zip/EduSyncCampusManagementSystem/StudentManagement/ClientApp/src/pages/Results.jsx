import { useEffect, useState } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext.jsx";
import PageHeader from "../components/PageHeader.jsx";
import EmptyState from "../components/EmptyState.jsx";
import Icon from "../components/Icon.jsx";

export default function Results() {
  const { user } = useAuth();
  const isStudent = user.role === "Student";
  const canEnter = ["Teacher", "Admin"].includes(user.role);

  const [students, setStudents] = useState([]);
  const [studentId, setStudentId] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(isStudent);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ courseName: "", mid: "", final: "", assignment: "" });
  const [saving, setSaving] = useState(false);

  // Teacher/Admin: load the student list once, to search by name.
  useEffect(() => {
    if (canEnter) {
      api.get("/people", { params: { role: "Student" } }).then(({ data }) => setStudents(data));
    }
  }, [canEnter]);

  function loadResults(id) {
    setLoading(true);
    setError("");
    api
      .get("/results", { params: isStudent ? {} : { studentId: id } })
      .then(({ data }) => setResults(data))
      .catch((err) => setError(err.response?.data?.message || "Could not load results."))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    if (isStudent) loadResults();
  }, [isStudent]);

  useEffect(() => {
    if (canEnter && studentId) loadResults(studentId);
  }, [studentId]);

  async function handleAdd(e) {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      await api.post("/results", {
        studentId: Number(studentId),
        courseName: form.courseName,
        mid: Number(form.mid) || 0,
        final: Number(form.final) || 0,
        assignment: Number(form.assignment) || 0
      });
      setForm({ courseName: "", mid: "", final: "", assignment: "" });
      loadResults(studentId);
    } catch (err) {
      setError(err.response?.data?.message || "Could not save the result.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    if (!confirm("Delete this result?")) return;
    await api.delete(`/results/${id}`);
    loadResults(studentId);
  }

  const selectedStudent = students.find((s) => String(s.id) === String(studentId));
  const attTone = (p) => (p >= 75 ? "" : p >= 60 ? "warn" : "bad");

  return (
    <div className="page">
      <PageHeader
        icon="award"
        title="Results"
        subtitle="View academic performance and maintain course results."
      />

      <div className="rule-note">
        <Icon name="info" size={17} />
        <span>Attendance contributes up to <strong>10 marks</strong>, calculated automatically from the student’s class attendance.</span>
      </div>

      {error && <div className="auth-error"><Icon name="alert" size={16} /> {error}</div>}

      {canEnter && (
        <div className="card">
          <div className="card-head">
            <div>
              <h2>Enter a result</h2>
              <p className="sub">Pick a student, then add marks for a course.</p>
            </div>
          </div>
          <div className="auth-field" style={{ maxWidth: 460 }}>
            <label>Student</label>
            <select value={studentId} onChange={(e) => setStudentId(e.target.value)}>
              <option value="">Select a student…</option>
              {students.map((s) => (
                <option key={s.id} value={s.id}>{s.fullName} ({s.idNumber || s.username})</option>
              ))}
            </select>
          </div>

          {studentId && (
            <form onSubmit={handleAdd}>
              <div className="form-grid">
                <div className="auth-field"><label>Course</label><input placeholder="CSE-3201" value={form.courseName} onChange={(e) => setForm((f) => ({ ...f, courseName: e.target.value }))} required /></div>
                <div className="auth-field"><label>Mid</label><input type="number" min="0" max="100" placeholder="0" value={form.mid} onChange={(e) => setForm((f) => ({ ...f, mid: e.target.value }))} /></div>
                <div className="auth-field"><label>Final</label><input type="number" min="0" max="100" placeholder="0" value={form.final} onChange={(e) => setForm((f) => ({ ...f, final: e.target.value }))} /></div>
                <div className="auth-field"><label>Assignment</label><input type="number" min="0" max="100" placeholder="0" value={form.assignment} onChange={(e) => setForm((f) => ({ ...f, assignment: e.target.value }))} /></div>
              </div>
              <div className="form-actions">
                <button className="btn-primary" type="submit" disabled={saving}><Icon name="plus" size={16} /> {saving ? "Saving…" : "Add result"}</button>
              </div>
            </form>
          )}
        </div>
      )}

      <div className="card flush">
        <div className="card-head">
          <div>
            <h2>{isStudent ? "My results" : selectedStudent ? `${selectedStudent.fullName}'s results` : "Results"}</h2>
            <p className="sub">{results.length} {results.length === 1 ? "course" : "courses"}</p>
          </div>
        </div>
        {loading ? (
          <p className="muted" style={{ padding: 24 }}>Loading…</p>
        ) : results.length === 0 ? (
          <EmptyState icon="award" title="No results yet">{canEnter && !studentId ? "Pick a student above to see their results." : "Results will appear here once they are published."}</EmptyState>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Course</th><th className="num">Mid</th><th className="num">Final</th><th className="num">Assignment</th><th>Attendance / 10</th><th className="num">Total / 110</th><th>Grade</th>
                  {canEnter && <th></th>}
                </tr>
              </thead>
              <tbody>
                {results.map((r) => (
                  <tr key={r.id}>
                    <td><strong className="course-code">{r.courseName}</strong></td>
                    <td className="num">{r.mid}</td>
                    <td className="num">{r.final}</td>
                    <td className="num">{r.assignment}</td>
                    <td>
                      <div className="att-cell">
                        <div className="top">{r.attendanceMarks} <span className="muted">/ 10</span></div>
                        <div className={`progress slim ${attTone(r.attendancePercent)}`}><span style={{ width: `${Math.min(100, r.attendancePercent)}%` }} /></div>
                        <div className="sub">{r.attendancePercent}% attendance</div>
                      </div>
                    </td>
                    <td className="num"><span className="total-chip">{r.total}</span></td>
                    <td><span className={`badge grade-${r.grade.replace("+", "plus").replace("-", "minus")}`}>{r.grade}</span></td>
                    {canEnter && <td className="num"><button className="btn-danger btn-sm" onClick={() => handleDelete(r.id)}><Icon name="trash" size={14} /> Delete</button></td>}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
