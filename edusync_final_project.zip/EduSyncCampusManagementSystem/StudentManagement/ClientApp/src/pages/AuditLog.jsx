import { useEffect, useState } from "react";
import api from "../api/axios";
import { errMsg } from "../utils/errors.js";
import PageHeader from "../components/PageHeader.jsx";
import EmptyState from "../components/EmptyState.jsx";
import Icon from "../components/Icon.jsx";

export default function AuditLog() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  // Wait until the admin stops typing, then search on the server from page 1.
  useEffect(() => {
    const t = setTimeout(() => { setDebounced(search.trim()); setPage(1); }, 350);
    return () => clearTimeout(t);
  }, [search]);

  // Server-side DataTable: only the current page is fetched; search/count/paging happen in the database.
  useEffect(() => {
    let stale = false;
    setLoading(true); setError("");
    api.get("/audit-logs", { params: { page, pageSize, search: debounced || undefined } })
      .then(({ data }) => {
        if (stale) return;
        setLogs(data.items || []);
        setTotalCount(data.totalCount || 0);
        setTotalPages(data.totalPages || 0);
        if (data.page && data.page !== page) setPage(data.page);
      })
      .catch((err) => { if (!stale) setError(errMsg(err, "Could not load the audit log.")); })
      .finally(() => { if (!stale) setLoading(false); });
    return () => { stale = true; };
  }, [page, pageSize, debounced]);

  const first = totalCount === 0 ? 0 : (page - 1) * pageSize + 1;
  const last = Math.min(page * pageSize, totalCount);

  return (
    <div className="page">
      <PageHeader
        icon="shield"
        title="Audit Log"
        subtitle="A record of who did what, for accountability. Admin only."
      />

      <div className="card flush">
        <div className="table-toolbar">
          <div className="search-box">
            <Icon name="search" size={16} />
            <input placeholder="Search by person, action or details" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <div className="datatable-toolbar-right">
            <label className="datatable-size-label">Rows
              <select value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }} aria-label="Rows per page">
                <option value={10}>10</option><option value={25}>25</option><option value={50}>50</option><option value={100}>100</option>
              </select>
            </label>
            <span className="muted">{totalCount} {totalCount === 1 ? "entry" : "entries"}</span>
          </div>
        </div>

        {error && <div className="auth-error" style={{ margin: 16 }}>{error}</div>}

        {loading && logs.length === 0 ? (
          <p className="muted" style={{ padding: 24 }}>Loading…</p>
        ) : logs.length === 0 ? (
          <EmptyState icon="shield" title="Nothing to show">No log entries match your search.</EmptyState>
        ) : (
          <div className="table-wrap datatable-wrap" style={{ opacity: loading ? 0.6 : 1, transition: "opacity .15s" }}>
            <table className="data-table">
              <thead>
                <tr><th>When</th><th>Who</th><th>Action</th><th>Details</th></tr>
              </thead>
              <tbody>
                {logs.map((l) => (
                  <tr key={l.id}>
                    <td className="muted nowrap">{new Date(l.timestamp).toLocaleString()}</td>
                    <td className="nowrap">{l.actorName} <RoleBadge role={l.actorRole} /></td>
                    <td><code className="action-chip">{l.action}</code></td>
                    <td>{l.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="datatable-footer">
              <span className="muted">Showing {first}–{last} of {totalCount}</span>
              <div className="datatable-pagination">
                <button type="button" className="btn-secondary btn-sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1 || loading}>Previous</button>
                <span className="datatable-page-indicator">Page {Math.min(page, Math.max(totalPages, 1))} of {Math.max(totalPages, 1)}</span>
                <button type="button" className="btn-secondary btn-sm" onClick={() => setPage((p) => Math.min(Math.max(totalPages, 1), p + 1))} disabled={page >= totalPages || loading || totalPages === 0}>Next</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function RoleBadge({ role }) {
  return <span className={`badge role-${role}`}>{role}</span>;
}
