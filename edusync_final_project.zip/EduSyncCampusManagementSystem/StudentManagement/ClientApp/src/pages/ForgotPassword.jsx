import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../api/axios";
import { APP_NAME, INSTITUTION } from "../utils/institution.js";
import PhotoBackdrop from "../components/PhotoBackdrop.jsx";
import Icon from "../components/Icon.jsx";

export default function ForgotPassword() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: "", verificationCode: "", newPassword: "", confirmPassword: "" });
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setOk("");
    if (form.newPassword !== form.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    setSaving(true);
    try {
      const { data } = await api.post("/auth/forgot-password", form);
      setOk(data.message);
      setTimeout(() => navigate("/login"), 900);
    } catch (err) {
      setError(err.response?.data?.message || "Could not reset the password.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="auth-layout">
      <PhotoBackdrop variant="auth" />

      <div className="auth-panel">
        <div className="auth-box">
          <div className="auth-mobile-brand">
            <span className="brand-mark"><Icon name="cap" size={20} /></span>
            <div>
              <div className="brand-name">{APP_NAME}</div>
              <div className="brand-sub">Campus workspace</div>
            </div>
          </div>

          <Link to="/login" className="auth-back"><Icon name="arrowLeft" size={16} /> Back to sign in</Link>
          <span className="auth-eyebrow">Secure account recovery</span>
          <h1>Reset your password</h1>
          <p className="auth-lead">Ask an Admin for a verification code, then use it here. The code expires after 15 minutes.</p>

          <ol className="steps">
            <li className="on"><span>1</span> Get code from Admin</li>
            <li className="on"><span>2</span> Set new password</li>
          </ol>

          {error && <div className="auth-error" role="alert"><Icon name="alert" size={16} /> {error}</div>}
          {ok && <div className="auth-success"><Icon name="checkCircle" size={16} /> {ok}</div>}

          <form onSubmit={submit}>
            <div className="field">
              <label htmlFor="fp-username">Username</label>
              <div className="input-wrap">
                <Icon name="user" size={17} />
                <input id="fp-username" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} autoComplete="username" required />
              </div>
            </div>
            <div className="field">
              <label htmlFor="fp-code">Admin verification code</label>
              <input
                id="fp-code"
                className="code-input"
                value={form.verificationCode}
                onChange={(e) => setForm({ ...form, verificationCode: e.target.value.replace(/\D/g, "").slice(0, 6) })}
                inputMode="numeric"
                placeholder="••••••"
                required
              />
            </div>
            <div className="field">
              <label htmlFor="fp-new">New password</label>
              <div className="input-wrap">
                <Icon name="lock" size={17} />
                <input id="fp-new" type="password" autoComplete="new-password" value={form.newPassword} onChange={(e) => setForm({ ...form, newPassword: e.target.value })} required />
              </div>
            </div>
            <div className="field">
              <label htmlFor="fp-confirm">Confirm new password</label>
              <div className="input-wrap">
                <Icon name="lock" size={17} />
                <input id="fp-confirm" type="password" autoComplete="new-password" value={form.confirmPassword} onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })} required />
              </div>
            </div>
            <button className="btn-primary btn-block btn-lg" disabled={saving}>{saving ? "Resetting…" : "Reset password"}</button>
          </form>
        </div>
      </div>
    </div>
  );
}
