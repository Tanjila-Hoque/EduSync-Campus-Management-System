import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import PageHeader from "../components/PageHeader.jsx";
import Icon from "../components/Icon.jsx";

export default function Notifications() {
  const [data,setData]=useState(null), [page,setPage]=useState(1), [error,setError]=useState("");
  const load=()=>api.get(`/notifications?page=${page}&pageSize=10`).then(r=>{setData(r.data);setError("");}).catch(e=>setError(e.response?.data?.message||"Could not load notifications."));
  useEffect(()=>{load();},[page]);
  async function read(id){try{await api.post(`/notifications/${id}/read`);load();}catch(e){setError("Could not mark notification as read.");}}
  async function readAll(){try{await api.post("/notifications/read-all");load();}catch(e){setError("Could not mark notifications as read.");}}
  return <div className="page"><PageHeader icon="bell" title="Notification center" subtitle="Personal campus updates and student-support alerts."/>
    <section className="card"><div className="card-head"><div><h2>Your notifications</h2><p className="sub">{data?.unread ?? "—"} unread · {data?.total ?? "—"} total</p></div><button className="btn-secondary btn-sm" disabled={!data?.unread} onClick={readAll}>Mark all read</button></div>
    {error&&<div className="auth-error">{error}</div>}
    {!data&&!error&&<p>Loading…</p>}
    {data&&data.items.length===0&&<p className="muted">You're all caught up. New alerts will appear here.</p>}
    {data?.items.map(n=><div key={n.id} style={{padding:"14px 0",borderTop:"1px solid var(--border)",display:"flex",gap:12,alignItems:"flex-start"}}>
      <div style={{width:36,height:36,borderRadius:10,display:"grid",placeItems:"center",background:n.isRead?"var(--border)":"rgba(53,113,220,.13)",flexShrink:0}}><Icon name={n.kind==="support"?"chart":"bell"} size={17}/></div>
      <div style={{flex:1,minWidth:0}}><div style={{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap"}}><strong>{n.title}</strong>{!n.isRead&&<span style={{fontSize:11,color:"#2563eb",fontWeight:700}}>UNREAD</span>}</div><p style={{margin:"5px 0"}}>{n.message}</p><div className="muted small-note">{new Date(n.createdAt).toLocaleString()}</div>{n.link&&<Link to={n.link} style={{display:"inline-block",marginTop:7}}>View details</Link>}</div>
      {!n.isRead&&<button className="btn-secondary btn-sm" onClick={()=>read(n.id)}>Mark read</button>}
    </div>)}
    {data&&data.totalPages>1&&<div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:16}}><button className="btn-secondary btn-sm" disabled={page<=1} onClick={()=>setPage(p=>p-1)}>Previous</button><span className="muted small-note">Page {data.page} of {data.totalPages}</span><button className="btn-secondary btn-sm" disabled={page>=data.totalPages} onClick={()=>setPage(p=>p+1)}>Next</button></div>}
    </section></div>;
}
