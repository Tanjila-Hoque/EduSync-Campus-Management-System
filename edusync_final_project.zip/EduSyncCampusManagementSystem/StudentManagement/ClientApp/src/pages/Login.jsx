import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { APP_NAME, INSTITUTION } from "../utils/institution.js";
import PhotoBackdrop from "../components/PhotoBackdrop.jsx";
import Icon from "../components/Icon.jsx";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ username: "", password: "", rememberMe: true });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      await login(form.username.trim(), form.password, form.rememberMe);
      navigate((location.state?.from?.pathname || "/dashboard") + (location.state?.from?.search || ""), { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || "Login failed. Please check your credentials.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="auth-layout">
      <PhotoBackdrop variant="auth" />

      <div className="auth-panel">
        <div className="auth-box">
          <div className="auth-mobile-brand">
            <span className="brand-mark"><Icon name="cap" size={20} /></span>
            <div>
              <div className="brand-name">{APP_NAME}</div>
              <div className="brand-sub">Campus workspace</div>
            </div>
          </div>

          <span className="auth-eyebrow">Campus workspace</span>
          <h1>Welcome back</h1>
          <p className="auth-lead">Sign in to continue to your campus workspace.</p>

          {error && <div className="auth-error" role="alert"><Icon name="alert" size={16} /> {error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="field">
              <label htmlFor="username">Username</label>
              <div className="input-wrap">
                <Icon name="user" size={17} />
                <input
                  id="username"
                  type="text"
                  autoComplete="username"
                  placeholder="Enter your username"
                  value={form.username}
                  onChange={(e) => setForm({ ...form, username: e.target.value })}
                  required
                  autoFocus
                />
              </div>
            </div>

            <div className="field">
              <label htmlFor="password">Password</label>
              <div className="input-wrap">
                <Icon name="lock" size={17} />
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  placeholder="Enter your password"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  required
                />
                <button type="button" className="input-eye" onClick={() => setShowPassword((v) => !v)} aria-label={showPassword ? "Hide password" : "Show password"}>
                  <Icon name={showPassword ? "eyeOff" : "eye"} size={17} />
                </button>
              </div>
            </div>

            <div className="auth-row">
              <label className="check">
                <input type="checkbox" checked={form.rememberMe} onChange={(e) => setForm({ ...form, rememberMe: e.target.checked })} />
                <span>Keep me signed in</span>
              </label>
              <Link to="/forgot-password" className="auth-link">Forgot password?</Link>
            </div>

            <button className="btn-primary btn-block btn-lg" disabled={submitting}>
              {submitting ? "Signing in…" : "Continue to EduSync"}
              {!submitting && <Icon name="arrowRight" size={17} />}
            </button>
          </form>

          <div className="auth-switch">New student? <Link to="/signup">Create your account</Link></div>
          <div className="auth-security">
            <Icon name="shield" size={15} />
            Protected by role-based access and secure session renewal.
          </div>
        </div>
      </div>
    </div>
  );
}
