import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { APP_NAME, INSTITUTION } from "../utils/institution.js";
import PhotoBackdrop from "../components/PhotoBackdrop.jsx";
import Icon from "../components/Icon.jsx";

const initialForm = {
  fullName: "",
  username: "",
  email: "",
  phone: "",
  idNumber: "",
  department: "",
  password: "",
  confirmPassword: ""
};

export default function Signup() {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState(initialForm);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");

    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    setSubmitting(true);
    try {
      await register({
        fullName: form.fullName.trim(),
        username: form.username.trim(),
        email: form.email || null,
        phone: form.phone || null,
        idNumber: form.idNumber || null,
        department: form.department || null,
        password: form.password,
        confirmPassword: form.confirmPassword
      });
      navigate("/dashboard", { replace: true });
    } catch (err) {
      const data = err.response?.data;
      setError(data?.message || firstValidationError(data) || "Sign up failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  function firstValidationError(data) {
    if (!data?.errors) return null;
    const firstKey = Object.keys(data.errors)[0];
    return data.errors[firstKey]?.[0];
  }

  const field = (id, label, props = {}) => (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <input id={id} value={form[id]} onChange={(e) => update(id, e.target.value)} {...props} />
    </div>
  );

  return (
    <div className="auth-layout">
      <PhotoBackdrop variant="auth" />

      <div className="auth-panel">
        <div className="auth-box wide">
          <div className="auth-mobile-brand">
            <span className="brand-mark"><Icon name="cap" size={20} /></span>
            <div>
              <div className="brand-name">{APP_NAME}</div>
              <div className="brand-sub">Campus workspace</div>
            </div>
          </div>

          <span className="auth-eyebrow">Student registration</span>
          <h1>Create your account</h1>
          <p className="auth-lead">Student sign up — teacher and staff accounts are created by an admin.</p>

          {error && <div className="auth-error" role="alert"><Icon name="alert" size={16} /> {error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="field-grid">
              {field("fullName", "Full name", { required: true, autoFocus: true })}
              {field("username", "Username", { required: true, autoComplete: "username" })}
              {field("idNumber", "Roll / ID number (optional)")}
              {field("department", "Department (optional)")}
              {field("email", "Email (optional)", { type: "email" })}
              {field("phone", "Mobile number (optional)", { type: "tel" })}
              {field("password", "Password", { type: "password", required: true, autoComplete: "new-password" })}
              {field("confirmPassword", "Confirm password", { type: "password", required: true, autoComplete: "new-password" })}
            </div>

            <button className="btn-primary btn-block btn-lg" type="submit" disabled={submitting}>
              {submitting ? "Creating account…" : "Create account"}
            </button>
          </form>

          <div className="auth-switch">Already have an account? <Link to="/login">Sign in</Link></div>
        </div>
      </div>
    </div>
  );
}
