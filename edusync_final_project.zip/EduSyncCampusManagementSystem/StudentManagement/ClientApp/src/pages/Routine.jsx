import { useEffect, useState } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext.jsx";
import PageHeader from "../components/PageHeader.jsx";
import Icon from "../components/Icon.jsx";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export default function Routine() {
  const { user } = useAuth();
  const canManage = user.role === "Admin";
  const showTeacher = user.role !== "Student";

  const [items, setItems] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [conflicts, setConflicts] = useState([]);
  const [conflictError, setConflictError] = useState("");
  const [conflictLoading, setConflictLoading] = useState(false);
  const [formConflicts, setFormConflicts] = useState([]);
  const [form, setForm] = useState({ day: "Sunday", startTime: "", endTime: "", courseName: "", room: "", department: "", teacherId: "" });
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    setError("");
    try {
      const { data } = await api.get("/routine");
      setItems(data);
    } catch (err) {
      setError(err.response?.data?.message || "Could not load the routine.");
    } finally {
      setLoading(false);
    }

    if (canManage) {
      setConflictLoading(true);
      setConflictError("");
      try {
        const { data } = await api.get("/routine/conflicts");
        setConflicts(data);
      } catch (err) {
        setConflictError(err.response?.data?.message || "Could not check timetable clashes.");
      } finally {
        setConflictLoading(false);
      }
    }
  }

  useEffect(() => { load(); }, [canManage]);

  useEffect(() => {
    if (!canManage) return;
    api.get("/people", { params: { role: "Teacher" } })
      .then(({ data }) => setTeachers(data))
      .catch(() => {});
  }, [canManage]);

  async function handleAdd(e) {
    e.preventDefault();
    setError("");
    setFormConflicts([]);
    setSaving(true);
    try {
      await api.post("/routine", { ...form, teacherId: form.teacherId ? Number(form.teacherId) : null });
      setForm((f) => ({ ...f, startTime: "", endTime: "", courseName: "" }));
      await load();
    } catch (err) {
      setError(err.response?.data?.message || "Could not add the class.");
      setFormConflicts(Array.isArray(err.response?.data?.conflicts) ? err.response.data.conflicts : []);
      if (canManage) {
        api.get("/routine/conflicts").then(({ data }) => setConflicts(data)).catch(() => {});
      }
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    if (!confirm("Remove this class from the routine?")) return;
    setError("");
    try {
      await api.delete(`/routine/${id}`);
      await load();
    } catch (err) {
      setError(err.response?.data?.message || "Could not remove the class.");
    }
  }

  const byDay = DAYS.map((day) => ({ day, entries: items.filter((i) => i.day === day) }));
  const todayName = DAYS[new Date().getDay()];

  function ConflictList({ rows }) {
    return <div className="clash-list">
      {rows.map((c, index) => (
        <div className="clash-item" key={`${c.firstId}-${c.secondId}-${index}`}>
          <div className="clash-item-top">
            <span className="pill red">{c.conflictType}</span>
            <strong>{c.day}</strong>
          </div>
          <div className="clash-courses">
            <span><strong>{c.firstCourseName}</strong><small>{c.firstStartTime}–{c.firstEndTime}{c.firstRoom ? ` · Room ${c.firstRoom}` : ""}</small></span>
            <Icon name="alert" size={17} />
            <span><strong>{c.secondCourseName}</strong><small>{c.secondStartTime}–{c.secondEndTime}{c.secondRoom ? ` · Room ${c.secondRoom}` : ""}</small></span>
          </div>
          <p className="muted" style={{ margin: "8px 0 0" }}>{c.reason}</p>
        </div>
      ))}
    </div>;
  }

  return (
    <div className="page">
      <PageHeader icon="calendar" title="Class Routine" subtitle="Keep class schedules clear, structured and easy to scan." />

      {error && <div className="auth-error"><Icon name="alert" size={16} /> {error}</div>}

      {canManage && (
        <section className={`card clash-card ${conflicts.length ? "has-clashes" : ""}`}>
          <div className="card-head">
            <div>
              <h2><Icon name="calendar" size={18} /> Smart Timetable Clash Detector</h2>
              <p className="sub">Checks overlapping class times for double-booked teachers and rooms. New clashes are blocked before saving.</p>
            </div>
            <button className="btn-secondary btn-sm" type="button" onClick={load} disabled={conflictLoading || loading}><Icon name="refresh" size={14} /> Recheck</button>
          </div>
          {conflictError && <div className="auth-error">{conflictError}</div>}
          {conflictLoading ? <p className="muted">Checking the timetable…</p> : conflicts.length === 0 && !conflictError ? (
            <div className="clash-clear"><Icon name="checkCircle" size={20} /><div><strong>No timetable clashes detected</strong><p className="muted">No overlapping assignments were found for the same teacher or room.</p></div></div>
          ) : conflicts.length > 0 ? (
            <><div className="clash-count"><strong>{conflicts.length}</strong> existing clash{conflicts.length === 1 ? "" : "es"} need review.</div><ConflictList rows={conflicts} /></>
          ) : null}
          {formConflicts.length > 0 && <div className="clash-new"><strong>This class was not saved because of a clash:</strong><ConflictList rows={formConflicts} /></div>}
        </section>
      )}

      {canManage && (
        <div className="card">
          <div className="card-head">
            <div>
              <h2>Add a class to the routine</h2>
              <p className="sub">Assign a teacher and room. The clash detector will validate the schedule before saving.</p>
            </div>
          </div>
          <form onSubmit={handleAdd}>
            <div className="form-grid">
              <div className="auth-field"><label>Day</label>
                <select value={form.day} onChange={(e) => setForm((f) => ({ ...f, day: e.target.value }))}>
                  {DAYS.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div className="auth-field"><label>Start</label><input type="time" value={form.startTime} onChange={(e) => setForm((f) => ({ ...f, startTime: e.target.value }))} required /></div>
              <div className="auth-field"><label>End</label><input type="time" value={form.endTime} onChange={(e) => setForm((f) => ({ ...f, endTime: e.target.value }))} required /></div>
              <div className="auth-field"><label>Course</label><input placeholder="CSE-3201" value={form.courseName} onChange={(e) => setForm((f) => ({ ...f, courseName: e.target.value }))} required /></div>
              <div className="auth-field"><label>Room</label><input placeholder="301" value={form.room} onChange={(e) => setForm((f) => ({ ...f, room: e.target.value }))} /></div>
              <div className="auth-field"><label>Department</label><input placeholder="Computer Science" value={form.department} onChange={(e) => setForm((f) => ({ ...f, department: e.target.value }))} /></div>
              <div className="auth-field"><label>Teacher</label>
                <select value={form.teacherId} onChange={(e) => setForm((f) => ({ ...f, teacherId: e.target.value }))}>
                  <option value="">No teacher assigned</option>
                  {teachers.map((t) => <option key={t.id} value={t.id}>{t.fullName}</option>)}
                </select>
              </div>
            </div>
            <div className="form-actions">
              <button className="btn-primary" type="submit" disabled={saving}><Icon name="plus" size={16} /> {saving ? "Checking & adding…" : "Add class"}</button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <div className="card"><p className="muted">Loading…</p></div>
      ) : (
        <div className="week-grid">
          {byDay.map(({ day, entries }) => (
            <section key={day} className={`day-card ${day === todayName ? "today" : ""}`}>
              <header>
                <h3>{day}</h3>
                {day === todayName ? <span className="pill green">Today</span> : <span className="muted">{entries.length} {entries.length === 1 ? "class" : "classes"}</span>}
              </header>
              {entries.length === 0 ? (
                <p className="day-empty">No classes</p>
              ) : (
                <ul className="slots">
                  {entries.map((e) => (
                    <li key={e.id} className="slot">
                      <div className="slot-time"><Icon name="clock" size={13} /> {e.startTime} – {e.endTime}</div>
                      <div className="slot-main">
                        <strong>{e.courseName}</strong>
                        <span>{e.room ? `Room ${e.room}` : "Room not set"}{showTeacher && e.teacherName ? ` · ${e.teacherName}` : ""}</span>
                      </div>
                      {canManage && (
                        <button className="icon-btn danger" onClick={() => handleDelete(e.id)} title="Remove from routine" aria-label="Remove from routine">
                          <Icon name="trash" size={15} />
                        </button>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
