import { useEffect, useState } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext.jsx";
import { errMsg } from "../utils/errors.js";
import PageHeader from "../components/PageHeader.jsx";
import Icon from "../components/Icon.jsx";

/* Attendance Health — turns raw scans into decisions.
   Student : "can I skip tomorrow's class?" per class, using the 75% rule.
   Teacher : an early-warning list of students slipping below 75%, plus a trend.            */

const COLORS = { Safe: "#1f9d55", Watch: "#d9922b", AtRisk: "#d64545", NoData: "#9aa5b4" };
const LABELS = { Safe: "On track", Watch: "Close to the limit", AtRisk: "Below 75%", NoData: "No classes yet" };

function Bar({ percent, status }) {
  return (
    <div style={{ position: "relative", height: 12, borderRadius: 8, background: "rgba(127,140,160,.22)", overflow: "hidden" }} title={`${percent}%`}>
      <div style={{ width: `${Math.min(100, percent)}%`, height: "100%", background: COLORS[status], transition: "width .4s" }} />
      <div style={{ position: "absolute", left: "75%", top: 0, bottom: 0, width: 2, background: "rgba(0,0,0,.45)" }} title="75% line" />
    </div>
  );
}

function Pill({ status }) {
  return <span style={{ background: COLORS[status], color: "#fff", borderRadius: 999, padding: "2px 10px", fontSize: 12, whiteSpace: "nowrap" }}>{LABELS[status]}</span>;
}

function Tile({ label, value, tone }) {
  return (
    <div style={{ flex: "1 1 130px", border: "1px solid var(--border)", borderRadius: 12, padding: "12px 14px" }}>
      <div className="muted small-note">{label}</div>
      <div style={{ fontSize: 26, fontWeight: 700, color: tone || "inherit" }}>{value}</div>
    </div>
  );
}

export default function Insights() {
  const { user } = useAuth();
  return <div className="page"><PageHeader icon="chart" title="Insights" subtitle="Turn attendance records into clear, actionable signals." />{user.role === "Student" ? <StudentHealth /> : <ClassHealth />}</div>;
}

/* ---------------- Student ---------------- */
function StudentHealth() {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.get("/analytics/my").then(({ data }) => setData(data)).catch(e => setError(errMsg(e, "Could not load your attendance health.")));
  }, []);

  function advice(c) {
    if (c.status === "NoData") return "No class has been held yet.";
    if (c.status === "AtRisk") return `Attend the next ${c.mustAttend} class${c.mustAttend === 1 ? "" : "es"} in a row to get back to 75%.`;
    if (c.canMiss > 0) return `You can miss ${c.canMiss} more class${c.canMiss === 1 ? "" : "es"} and still stay at 75%.`;
    return "You're right at the edge — don't miss the next class.";
  }

  return (
    <>
      <div className="card">
        <h2>My Attendance Health</h2>
        <p className="muted">Most universities need <strong>75%</strong> attendance to sit the exam. For every class you've joined, this shows where you stand and exactly how many classes you can still miss.</p>
        {error && <div className="auth-error">{error}</div>}
        {!data ? !error && <p>Loading…</p> : data.classes.length === 0 ? (
          <p className="muted">You haven't joined any class yet. Open Attendance → My classes and tick the classes you attend.</p>
        ) : (
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <Tile label="Overall average" value={`${data.averagePercent}%`} tone={data.averagePercent >= 75 ? COLORS.Safe : COLORS.AtRisk} />
            <Tile label="Classes below 75%" value={data.atRiskCount} tone={data.atRiskCount ? COLORS.AtRisk : COLORS.Safe} />
            <Tile label="Classes joined" value={data.classes.length} />
          </div>
        )}
      </div>

      {data && data.classes.map(c => (
        <div className="card" key={c.classId}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            <div>
              <h3 style={{ margin: 0 }}>{c.courseName}{c.section ? ` · ${c.section}` : ""}</h3>

            </div>
            <Pill status={c.status} />
          </div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 10, margin: "10px 0 6px" }}>
            <span style={{ fontSize: 30, fontWeight: 700, color: COLORS[c.status] }}>{c.percent}%</span>
            <span className="muted">{c.attended} of {c.held} classes attended</span>
          </div>
          <Bar percent={c.percent} status={c.status} />
          <p style={{ marginBottom: 0 }}><strong>{advice(c)}</strong></p>
        </div>
      ))}
    </>
  );
}

/* ---------------- Teacher / Admin ---------------- */
function ClassHealth() {
  const [classes, setClasses] = useState([]);
  const [classId, setClassId] = useState("");
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.get("/classes").then(({ data }) => {
      setClasses(data);
      if (data[0]) setClassId(String(data[0].id));
    }).catch(e => setError(errMsg(e, "Could not load your classes.")));
  }, []);

  useEffect(() => {
    if (!classId) return;
    setLoading(true); setError("");
    api.get(`/analytics/class/${classId}`).then(({ data }) => setData(data))
      .catch(e => setError(errMsg(e, "Could not load the class insights.")))
      .finally(() => setLoading(false));
  }, [classId]);

  function exportCsv() {
    const q = v => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const rows = [["Name", "ID", "Attended", "Classes held", "Percent", "Status"],
      ...data.students.map(s => [s.fullName, s.idNumber || "", s.attended, data.held, s.percent, LABELS[s.status]])];
    const csv = "\ufeff" + rows.map(r => r.map(q).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url; a.download = `attendance-${data.courseName}${data.section ? "-" + data.section : ""}.csv`; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  const atRisk = data ? data.students.filter(s => s.status === "AtRisk") : [];
  const maxTrend = data ? Math.max(1, data.studentCount, ...data.trend.map(t => t.present)) : 1;

  return (
    <>
      <div className="card">
        <h2>Class Attendance Health</h2>
        <p className="muted">See which students are slipping <em>before</em> they fall below 75%, and how attendance is trending class by class.</p>
        <div className="auth-field" style={{ maxWidth: 360 }}>
          <label>Class</label>
          <select value={classId} onChange={e => setClassId(e.target.value)}>
            {classes.map(c => <option key={c.id} value={c.id}>{c.courseName}{c.section ? ` · ${c.section}` : ""} — {c.teacherName}</option>)}
          </select>
        </div>
        {error && <div className="auth-error">{error}</div>}
        {classes.length === 0 && !error && <p className="muted">No classes yet.</p>}
      </div>

      {loading && <p>Loading…</p>}

      {data && !loading && (
        <>
          <div className="card">
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <Tile label="Classes held" value={data.held} />
              <Tile label="Students" value={data.studentCount} />
              <Tile label="Class average" value={`${data.averagePercent}%`} tone={data.held && data.averagePercent < 75 ? COLORS.AtRisk : COLORS.Safe} />
              <Tile label="Below 75%" value={data.atRiskCount} tone={data.atRiskCount ? COLORS.AtRisk : COLORS.Safe} />
            </div>

            {data.trend.length > 0 && (
              <>
                <h3 style={{ marginTop: 20 }}>Recent classes — students present</h3>
                <div style={{ display: "flex", alignItems: "flex-end", gap: 8, height: 120, overflowX: "auto" }}>
                  {data.trend.map(t => (
                    <div key={t.date} style={{ flex: "1 0 38px", textAlign: "center" }}>
                      <div className="muted small-note">{t.present}</div>
                      <div style={{ height: Math.max(4, (t.present / maxTrend) * 80), background: "var(--accent)", borderRadius: "6px 6px 0 0" }} />
                      <div className="muted small-note">{t.date.slice(5)}</div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>

          {atRisk.length > 0 && (
            <div className="card" style={{ borderLeft: `4px solid ${COLORS.AtRisk}` }}>
              <h3 style={{ marginTop: 0 }}><Icon name="alert" size={16} /> Needs attention ({atRisk.length})</h3>
              <p className="muted">These students are below 75% and risk missing exam eligibility.</p>
              <table>
                <thead><tr><th>Student</th><th>ID</th><th>Attendance</th><th>Needs to attend</th></tr></thead>
                <tbody>
                  {atRisk.map(s => (
                    <tr key={s.studentId}>
                      <td>{s.fullName}</td><td className="muted">{s.idNumber || "—"}</td>
                      <td style={{ color: COLORS.AtRisk }}><strong>{s.percent}%</strong> <span className="muted">({s.attended}/{data.held})</span></td>
                      <td>next {s.mustAttend} in a row</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="card">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
              <h3 style={{ margin: 0 }}>All students (lowest first)</h3>
              <button className="btn-secondary" type="button" onClick={exportCsv} disabled={data.students.length === 0}><Icon name="download" size={15} /> Export CSV</button>
            </div>
            {data.students.length === 0 ? <p className="muted">No students have joined this class yet.</p> : (
              <table style={{ marginTop: 10 }}>
                <thead><tr><th>Student</th><th>ID</th><th style={{ minWidth: 150 }}>Attendance</th><th>Status</th></tr></thead>
                <tbody>
                  {data.students.map(s => (
                    <tr key={s.studentId}>
                      <td>{s.fullName}</td><td className="muted">{s.idNumber || "—"}</td>
                      <td><div style={{ display: "flex", alignItems: "center", gap: 8 }}><div style={{ flex: 1 }}><Bar percent={s.percent} status={s.status} /></div><span style={{ minWidth: 44, textAlign: "right" }}>{s.percent}%</span></div></td>
                      <td><Pill status={s.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}
    </>
  );
}
