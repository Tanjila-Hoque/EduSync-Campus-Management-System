import { useEffect, useMemo, useState } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext.jsx";
import { errMsg } from "../utils/errors.js";
import PageHeader from "../components/PageHeader.jsx";
import EmptyState from "../components/EmptyState.jsx";
import Icon from "../components/Icon.jsx";

export default function Classes() {
  const { user } = useAuth();
  const isAdmin = user.role === "Admin";
  const [classes, setClasses] = useState([]);
  const [tablePage, setTablePage] = useState(1);
  const [tablePageSize, setTablePageSize] = useState(10);
  const [tableSearch, setTableSearch] = useState("");
  const [tableTotal, setTableTotal] = useState(0);
  const [tablePages, setTablePages] = useState(0);
  const [teachers, setTeachers] = useState([]);
  const [students, setStudents] = useState([]);
  const [selected, setSelected] = useState(null);
  const [roster, setRoster] = useState([]);
  const [form, setForm] = useState({ courseName: "", section: "", department: "", room: "", teacherId: "" });
  const [studentId, setStudentId] = useState("");
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true); setError("");
    try {
      const { data } = await api.get("/classes", { params: { page: tablePage, pageSize: tablePageSize, search: tableSearch || undefined } });
      const rows = Array.isArray(data) ? data : (data.items || []);
      setClasses(rows);
      setTableTotal(Array.isArray(data) ? data.length : (data.totalCount || 0));
      setTablePages(Array.isArray(data) ? 1 : (data.totalPages || 0));
      if (selected) {
        const fresh = rows.find(c => c.id === selected.id);
        if (fresh) setSelected(fresh);
      }
    } catch (e) { setError(errMsg(e, "Could not load classes.")); }
    finally { setLoading(false); }
  }

  useEffect(() => {
    if (isAdmin) {
      Promise.all([
        api.get("/people", { params: { role: "Teacher" } }),
        api.get("/people", { params: { role: "Student" } })
      ]).then(([t, s]) => { setTeachers(t.data); setStudents(s.data); }).catch(e => setError(errMsg(e, "Could not load teachers/students.")));
    }
  }, []);

  useEffect(() => { load(); }, [tablePage, tablePageSize, tableSearch]);

  async function openClass(c) {
    setSelected(c); setError("");
    try { const { data } = await api.get(`/classes/${c.id}/students`); setRoster(data); }
    catch (e) { setError(errMsg(e, "Could not load the class roster.")); }
  }

  async function createClass(e) {
    e.preventDefault(); setError(""); setOk("");
    try {
      await api.post("/classes", { ...form, teacherId: Number(form.teacherId) });
      setOk("Class created.");
      setForm({ courseName: "", section: "", department: "", room: "", teacherId: "" });
      await load();
    } catch (e) { setError(errMsg(e, "Could not create the class.")); }
  }

  async function enroll(e) {
    e.preventDefault(); if (!selected || !studentId) return;
    setError(""); setOk("");
    try {
      await api.post(`/classes/${selected.id}/students/${studentId}`);
      setOk("Student enrolled in this class.");
      setStudentId("");
      await openClass(selected);
      await load();
    } catch (e) { setError(errMsg(e, "Could not enroll this student.")); }
  }

  async function unenroll(id) {
    if (!selected || !confirm("Remove this student from the class?")) return;
    try { await api.delete(`/classes/${selected.id}/students/${id}`); await openClass(selected); await load(); }
    catch (e) { setError(errMsg(e, "Could not remove the student.")); }
  }

  const availableStudents = useMemo(() => new Set(roster.map(x => x.studentId)), [roster]);
  const isStudent = user.role === "Student";

  return (
    <div className="page">
      <PageHeader
        icon="book"
        title="Classes"
        subtitle="Manage class groups, sections, enrolment and class access."
      />

      {error && <div className="auth-error"><Icon name="alert" size={16} /> {error}</div>}
      {ok && <div className="auth-success"><Icon name="checkCircle" size={16} /> {ok}</div>}

      <div className="rule-note">
        <Icon name="info" size={17} />
        <span>
          Each class belongs to one Teacher and has its own student roster. A student can belong to many classes,
          so they can record attendance in every class they are enrolled in on the same day.
        </span>
      </div>

      {isAdmin && (
        <div className="card">
          <div className="card-head">
            <div>
              <h2>Create a class</h2>
              <p className="sub">Assign a course and section to one teacher.</p>
            </div>
          </div>
          <form onSubmit={createClass}>
            <div className="form-grid">
              <div className="auth-field"><label>Course</label><input value={form.courseName} onChange={e => setForm(f => ({...f, courseName:e.target.value}))} required placeholder="CSE-3201" /></div>
              <div className="auth-field"><label>Section</label><input value={form.section} onChange={e => setForm(f => ({...f, section:e.target.value}))} placeholder="A" /></div>
              <div className="auth-field"><label>Department</label><input value={form.department} onChange={e => setForm(f => ({...f, department:e.target.value}))} placeholder="Computer Science" /></div>
              <div className="auth-field"><label>Room</label><input value={form.room} onChange={e => setForm(f => ({...f, room:e.target.value}))} placeholder="301" /></div>
              <div className="auth-field"><label>Teacher</label><select value={form.teacherId} onChange={e => setForm(f => ({...f, teacherId:e.target.value}))} required><option value="">Select teacher</option>{teachers.filter(t=>t.isActive).map(t=><option key={t.id} value={t.id}>{t.fullName}</option>)}</select></div>
            </div>
            <div className="form-actions">
              <button className="btn-primary" type="submit"><Icon name="plus" size={16} /> Create class</button>
            </div>
          </form>
        </div>
      )}

      <div className="card flush">
        <div className="card-head">
          <div>
            <h2>{isStudent ? "My classes" : isAdmin ? "All classes" : "My teaching classes"}</h2>
            <p className="sub">{tableTotal} {tableTotal === 1 ? "class" : "classes"}</p>
          </div>
        </div>
        <div className="datatable-toolbar">
          <div className="search-box"><Icon name="search" size={16} /><input placeholder="Search course, section, teacher, room…" value={tableSearch} onChange={e => { setTableSearch(e.target.value); setTablePage(1); }} /></div>
          <div className="datatable-toolbar-right"><label className="datatable-size-label">Rows<select value={tablePageSize} onChange={e => { setTablePageSize(Number(e.target.value)); setTablePage(1); }} aria-label="Rows per page"><option value={10}>10</option><option value={25}>25</option><option value={50}>50</option></select></label><span className="muted">{tableTotal} total</span></div>
        </div>
        {loading ? <p className="muted" style={{ padding: 24 }}>Loading…</p> : classes.length === 0 ? (
          <EmptyState icon="book" title="No classes yet">Classes will appear here once they are created or joined.</EmptyState>
        ) : (
          <div className="table-wrap datatable-wrap">
            <table className="data-table">
              <thead><tr><th>Course</th><th>Section</th>{!isStudent && <th>Teacher</th>}<th>Room</th><th className="num">Students</th>{!isStudent && <th></th>}</tr></thead>
              <tbody>
                {classes.map(c => <tr key={c.id} className={selected?.id === c.id ? "row-active" : ""}>
                  <td><strong className="course-code">{c.courseName}</strong></td>
                  <td>{c.section ? <span className="pill blue">{c.section}</span> : <span className="muted">—</span>}</td>
                  {!isStudent && <td>{c.teacherName || "—"}</td>}
                  <td>{c.room || "—"}</td>
                  <td className="num"><span className="pill gray"><Icon name="users" size={12} /> {c.studentCount}</span></td>
                  {!isStudent && <td className="num"><button className="btn-secondary btn-sm" onClick={() => openClass(c)}>View roster</button></td>}
                </tr>)}
              </tbody>
            </table>
            <div className="datatable-footer">
              <span className="muted">Showing {tableTotal === 0 ? 0 : (tablePage - 1) * tablePageSize + 1}–{Math.min(tablePage * tablePageSize, tableTotal)} of {tableTotal}</span>
              <div className="datatable-pagination"><button type="button" className="btn-secondary btn-sm" onClick={() => setTablePage(p => Math.max(1, p - 1))} disabled={tablePage <= 1 || loading}>Previous</button><span className="datatable-page-indicator">Page {Math.min(tablePage, Math.max(tablePages, 1))} of {Math.max(tablePages, 1)}</span><button type="button" className="btn-secondary btn-sm" onClick={() => setTablePage(p => Math.min(Math.max(tablePages, 1), p + 1))} disabled={tablePage >= tablePages || loading || tablePages === 0}>Next</button></div>
            </div>
          </div>
        )}
      </div>

      {selected && !isStudent && (
        <div className="card">
          <div className="card-head">
            <div>
              <h2>{selected.courseName}{selected.section ? ` · ${selected.section}` : ""} — Student roster</h2>
              <p className="sub">Teacher: {selected.teacherName}. Only students enrolled in this class appear here.</p>
            </div>
            <button className="btn-ghost btn-sm" onClick={() => setSelected(null)}><Icon name="x" size={14} /> Close</button>
          </div>
          {isAdmin && (
            <form onSubmit={enroll} className="enroll-bar">
              <div className="auth-field" style={{ flex: 1, minWidth: 240 }}><label>Add student</label><select value={studentId} onChange={e => setStudentId(e.target.value)}><option value="">Select student</option>{students.filter(s => s.isActive && !availableStudents.has(s.id)).map(s => <option key={s.id} value={s.id}>{s.fullName} {s.idNumber ? `(${s.idNumber})` : ""}</option>)}</select></div>
              <button className="btn-primary" type="submit" disabled={!studentId}><Icon name="plus" size={16} /> Enroll</button>
            </form>
          )}
          {roster.length === 0 ? <EmptyState icon="users" title="No students yet">No students are enrolled in this class yet.</EmptyState> : (
            <div className="table-wrap">
              <table><thead><tr><th>Name</th><th>ID</th>{isAdmin && <th></th>}</tr></thead><tbody>{roster.map(s => <tr key={s.studentId}><td><strong>{s.studentName}</strong></td><td>{s.studentIdNumber || "—"}</td>{isAdmin && <td className="num"><button className="btn-danger btn-sm" onClick={() => unenroll(s.studentId)}>Remove</button></td>}</tr>)}</tbody></table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
