import { Fragment, useEffect, useId, useRef, useState } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext.jsx";
import { INSTITUTION } from "../utils/institution.js";
import { errMsg, localDateIso } from "../utils/errors.js";
import PageHeader from "../components/PageHeader.jsx";
import Icon from "../components/Icon.jsx";

function todayIso() { return localDateIso(); }

const initials = (name) => (name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join("");
const clock = (iso) => new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
const longDate = (d = new Date()) => d.toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
const mmss = (sec) => `${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(sec % 60).padStart(2, "0")}`;

export default function Attendance() {
  const { user } = useAuth();
  const isStudent = user.role === "Student";
  const isTeacher = user.role === "Teacher";
  const isAdmin = user.role === "Admin";
  const selfChecksInViaGate = ["Teacher", "Staff"].includes(user.role);

  return (
    <div className="page">
      <PageHeader
        icon="check"
        title="Attendance"
        subtitle={`${longDate()} · Secure, time-limited class attendance`}
      />

      {isStudent && <StudentClassesCard />}
      {isStudent && <StudentAttendanceCard />}
      {selfChecksInViaGate && <MySelfCheckInCard role={user.role} />}
      {isAdmin && (
        <div className="att-grid-2">
          <CheckInQrCard />
          <StaffAttendanceCard />
        </div>
      )}
      {(isTeacher || isAdmin) && <ClassSessions />}
    </div>
  );
}

function StudentClassesCard() {
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");

  function load() {
    api.get("/classes/browse")
      .then(({ data }) => {
        setClasses(data);
        if (!data.some(c => c.enrolled)) setOpen(true); // nothing picked yet -> show the list
      })
      .catch(e => setError(errMsg(e, "Could not load the class list.")))
      .finally(() => setLoading(false));
  }
  useEffect(load, []);

  async function toggle(c) {
    setError("");
    try {
      if (c.enrolled) await api.delete(`/classes/${c.id}/join`);
      else await api.post(`/classes/${c.id}/join`);
      setClasses(list => list.map(x => x.id === c.id ? { ...x, enrolled: !x.enrolled, studentCount: x.studentCount + (c.enrolled ? -1 : 1) } : x));
    } catch (e) { setError(errMsg(e, "Could not update your classes.")); }
  }

  const mine = classes.filter(c => c.enrolled).length;

  return (
    <div className="card">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
        <h2>My classes {!loading && <span className="muted">({mine})</span>}</h2>
        <button className="btn-secondary" type="button" onClick={() => setOpen(v => !v)}>{open ? "Hide" : "Choose my classes"}</button>
      </div>
      <p className="muted">Tick every class you attend. Your Teacher's attendance list only includes students who joined their class here, and you give attendance separately for each class.</p>
      {error && <div className="auth-error">{error}</div>}
      {open && (loading ? <p>Loading…</p> : classes.length === 0 ? <p className="muted">No classes yet. Ask the Admin to add them.</p> : (
        <table>
          <thead><tr><th>My Class</th><th>Section</th><th></th></tr></thead>
          <tbody>
            {classes.map(c => (
              <tr key={c.id}>
                <td><strong>{c.courseName}</strong></td>
                <td className="muted">{c.section || "—"}</td>
                <td><button className={c.enrolled ? "btn-secondary" : "btn-primary"} type="button" onClick={() => toggle(c)}>{c.enrolled ? "✓ Joined — leave" : "+ Join"}</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      ))}
    </div>
  );
}

function StudentAttendanceCard() {
  const [scannerOpen, setScannerOpen] = useState(false);
  const [manualOpen, setManualOpen] = useState(false);
  const [manualCode, setManualCode] = useState("");
  const [checking, setChecking] = useState(false);
  const [msg, setMsg] = useState(null);
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  function loadHistory() {
    setLoading(true);
    api.get("/attendance/my")
      .then(({ data }) => setRecords(data))
      .catch(e => setError(errMsg(e, "Could not load your attendance.")))
      .finally(() => setLoading(false));
  }
  useEffect(() => {
    loadHistory();
    const scan = new URLSearchParams(window.location.search).get("scan");
    if (scan) submitScan(scan, true);
  }, []);

  async function submitScan(rawCode, fromQrLink = false) {
    if (!rawCode?.trim()) return;
    let code = rawCode.trim();
    // A phone camera may return the full EduSync attendance URL rather than the
    // raw CLASS:... payload. Extract the signed payload before sending it to the API.
    try {
      const u = new URL(code);
      const embedded = u.searchParams.get("scan");
      if (embedded) code = embedded;
    } catch { /* raw CLASS:... code */ }
    setChecking(true); setMsg(null);
    try {
      const { data } = await api.post("/attendance/session-scan", { code });
      setMsg({ type: "ok", text: "✓ Attendance recorded", detail: `${data.courseName}${data.section ? ` · ${data.section}` : ""} · ${new Date(data.time).toLocaleTimeString()}` });
      if (fromQrLink) window.history.replaceState({}, document.title, window.location.pathname);
      loadHistory();
    } catch (e) { setMsg({ type: "error", text: errMsg(e, "Could not record attendance.") }); }
    finally { setChecking(false); setScannerOpen(false); }
  }

  return (
    <div className="card">
      <div className="section-kicker">STUDENT CHECK-IN</div>
      <h2>Join an open class</h2>
      <p className="muted">Scan your Teacher's QR with your phone camera. EduSync will open your attendance panel automatically and submit the check-in only after your class, login and session are verified.</p>
      {msg && <div className={msg.type === "ok" ? "auth-success" : "auth-error"}>{msg.text}{msg.detail && <div className="small-note">{msg.detail}</div>}</div>}
      {error && <div className="auth-error">{error}</div>}
      <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
        <button className="btn-secondary" onClick={() => { setScannerOpen(v=>!v); setManualOpen(false); }} disabled={checking}>{scannerOpen ? <><Icon name="x" size={16} /> Close camera</> : <><Icon name="camera" size={16} /> Scan Teacher QR</>}</button>
        <button className="btn-secondary" onClick={() => { setManualOpen(v=>!v); setScannerOpen(false); }} disabled={checking}><Icon name="edit" size={16} /> Type QR code</button>
      </div>
      {scannerOpen && <CameraScanner onDetected={submitScan} onError={text => setMsg({ type:"error", text })} />}
      {manualOpen && <form onSubmit={e => { e.preventDefault(); submitScan(manualCode); setManualCode(""); setManualOpen(false); }} className="inline-form" style={{ marginTop:12 }}><div className="auth-field" style={{flex:1}}><label>Class QR code</label><input value={manualCode} onChange={e=>setManualCode(e.target.value)} placeholder="CLASS:CSE3201A:20261004:..." autoFocus /></div><button className="btn-primary" disabled={checking || !manualCode.trim()}>Submit</button></form>}

      <hr />
      <h3>Attendance history</h3>
      {loading ? <p>Loading…</p> : records.length === 0 ? <p className="muted">No attendance recorded yet.</p> : (
        <table><thead><tr><th>Date</th><th>Class</th><th>Time</th><th>Status</th></tr></thead><tbody>
          {records.map(r => <tr key={r.id}><td>{r.date}</td><td>{r.courseName ? `${r.courseName}${r.section ? ` · ${r.section}` : ""}` : "Daily staff check-in"}</td><td>{new Date(r.checkInTime).toLocaleTimeString()}</td><td>{r.isCorrected ? "Corrected" : "Present"}</td></tr>)}
        </tbody></table>
      )}
    </div>
  );
}

function MySelfCheckInCard({ role }) {
  const [scannerOpen, setScannerOpen] = useState(false);
  const [manualOpen, setManualOpen] = useState(false);
  const [manualCode, setManualCode] = useState("");
  const [checking, setChecking] = useState(false);
  const [msg, setMsg] = useState(null);
  const [records, setRecords] = useState([]);

  function load() { api.get("/attendance/my").then(({data})=>setRecords(data)).catch(()=>{}); }
  useEffect(load, []);
  const checkedToday = records.some(r => !r.classId && r.date === todayIso());

  async function submit(code) {
    setChecking(true); setMsg(null);
    try { const {data} = await api.post("/attendance/checkin", {code}); setMsg({type:"ok", text:"✓ Daily attendance recorded", detail:`${data.time ? new Date(data.time).toLocaleTimeString() : ""}`}); load(); }
    catch(e) { setMsg({type:"error", text:errMsg(e, "Could not record today's attendance.")}); }
    finally { setChecking(false); setScannerOpen(false); }
  }

  return <div className="card">
    <h2>Daily {role} Check-in</h2>
    <p className="muted">Scan today's check-in QR once a day.</p>
    {checkedToday ? <div className="auth-success">You are already checked in today.</div> : <>
      {msg && <div className={msg.type === "ok" ? "auth-success" : "auth-error"}>{msg.text}{msg.detail && <div>{msg.detail}</div>}</div>}
      <div style={{display:"flex",gap:10,flexWrap:"wrap"}}><button className="btn-secondary" onClick={()=>{setScannerOpen(v=>!v);setManualOpen(false)}} disabled={checking}>{scannerOpen?<><Icon name="x" size={16} /> Close camera</>:<><Icon name="camera" size={16} /> Scan daily QR</>}</button><button className="btn-secondary" onClick={()=>{setManualOpen(v=>!v);setScannerOpen(false)}}><Icon name="edit" size={16} /> Type code</button></div>
      {scannerOpen && <CameraScanner onDetected={submit} onError={text=>setMsg({type:"error",text})} />}
      {manualOpen && <form onSubmit={e=>{e.preventDefault();submit(manualCode);setManualCode("")}} className="inline-form" style={{marginTop:12}}><div className="auth-field" style={{flex:1}}><label>Daily QR code</label><input value={manualCode} onChange={e=>setManualCode(e.target.value)} /></div><button className="btn-primary" disabled={checking}>Submit</button></form>}
    </>}
  </div>;
}


/* ---------------- Shared bits ---------------- */

function FullScreenQr({ src, title, onClose }) {
  return (
    <div className="fs-qr" onClick={onClose}>
      <img src={src} alt="QR code" />
      <h2>{title}</h2>
      <p>Tap anywhere to close</p>
    </div>
  );
}

function RosterRow({ name, sub, present, time, note, action }) {
  return (
    <li className="roster-row">
      <div className={`avatar-sm ${present ? "present" : ""}`}>{initials(name)}</div>
      <div className="rr-main">
        <div className="rr-name">{name}</div>
        {sub && <div className="rr-sub">{sub}</div>}
      </div>
      <div className="rr-right">
        {present ? <span className="status-pill ok">✓ {time}</span> : <span className="status-pill no">Absent</span>}
        {note}
        {action}
      </div>
    </li>
  );
}

function ReasonRow({ value, onChange, onSave, onCancel, busy }) {
  return (
    <li className="roster-edit">
      <input value={value} onChange={onChange} placeholder="Reason (e.g. phone battery died)" autoFocus />
      <button className="btn-primary" type="button" disabled={busy || !value.trim()} onClick={onSave}>{busy ? "Saving…" : "Save"}</button>
      <button className="btn-secondary" type="button" onClick={onCancel}>Cancel</button>
    </li>
  );
}

/* ---------------- Admin: today's check-in QR for Teachers & Staff ---------------- */

function CheckInQrCard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [full, setFull] = useState(false);

  useEffect(() => {
    api.get("/attendance/checkin-code").then(({ data }) => setData(data)).catch(e => setError(errMsg(e, "Could not load today's QR.")));
  }, []);

  const src = data ? `data:image/png;base64,${data.imageBase64}` : null;
  const dayLabel = data ? longDate(new Date(`${data.date}T00:00:00`)) : "";

  function print() {
    const w = window.open("", "_blank", "width=520,height=700");
    if (!w) return;
    w.document.write(`<html><head><title>${INSTITUTION.shortName} — Check-in</title></head><body style="font-family:sans-serif;text-align:center;padding:32px">
      <h2 style="margin-bottom:2px">${INSTITUTION.name}</h2><p style="margin-top:0;color:#667">Teacher &amp; Staff check-in</p>
      <img src="${src}" style="width:300px;height:300px"/><p><b>${dayLabel}</b></p></body></html>`);
    w.document.close(); w.print();
  }

  return (
    <div className="card gate-card">
      <div className="card-title-row"><h2>Check-in QR</h2><span className="badge role-Teacher">Teachers &amp; Staff</span></div>
      {error && <div className="auth-error">{error}</div>}
      {!data && !error && <p className="muted">Loading…</p>}
      {data && (
        <>
          <div className="qr-box"><img src={src} alt="Check-in QR" /></div>
          <p className="gate-date">{dayLabel}</p>
          <div className="btn-row">
            <button className="btn-secondary" type="button" onClick={() => setFull(true)}><Icon name="maximize" size={16} /> Full screen</button>
            <button className="btn-primary" type="button" onClick={print}><Icon name="printer" size={16} /> Print</button>
          </div>
        </>
      )}
      {full && src && <FullScreenQr src={src} title="Teacher & Staff check-in" onClose={() => setFull(false)} />}
    </div>
  );
}

/* ---------------- Admin: Teachers & Staff attendance ---------------- */

function StaffAttendanceCard() {
  const [role, setRole] = useState("Teacher");
  const [date, setDate] = useState(todayIso());
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [q, setQ] = useState("");
  const [reasonFor, setReasonFor] = useState(null);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);

  function load() {
    api.get("/attendance/staff-report", { params: { role, date } })
      .then(({ data }) => { setReport(data); setError(""); })
      .catch(e => setError(errMsg(e, "Could not load attendance.")))
      .finally(() => setLoading(false));
  }
  useEffect(() => { setLoading(true); setReasonFor(null); load(); }, [role, date]);

  async function markPresent(userId) {
    setBusy(true); setError("");
    try {
      await api.post("/attendance/correct-daily", { userId, date, reason: reason.trim() });
      setReasonFor(null); setReason(""); load();
    } catch (e) { setError(errMsg(e, "Could not mark this person present.")); }
    finally { setBusy(false); }
  }

  async function undo(recordId) {
    if (!confirm("Set this person back to absent?")) return;
    try { await api.delete(`/attendance/${recordId}`); load(); }
    catch (e) { setError(errMsg(e, "Could not undo this.")); }
  }

  const present = report?.present ?? [];
  const absent = report?.absent ?? [];
  const total = present.length + absent.length;
  const pct = total ? Math.round((100 * present.length) / total) : 0;

  const needle = q.trim().toLowerCase();
  const rows = [
    ...[...present].sort((a, b) => new Date(b.checkInTime) - new Date(a.checkInTime)).map(p => ({ key: `p${p.id}`, name: p.userFullName, id: p.idNumber, present: true, time: clock(p.checkInTime), recordId: p.id, corrected: p.isCorrected, why: p.correctionReason })),
    ...[...absent].sort((a, b) => a.fullName.localeCompare(b.fullName)).map(a => ({ key: `a${a.userId}`, name: a.fullName, id: a.idNumber, present: false, userId: a.userId }))
  ].filter(r => !needle || r.name.toLowerCase().includes(needle) || (r.id || "").toLowerCase().includes(needle));

  return (
    <div className="card">
      <div className="card-title-row">
        <h2>Teachers &amp; Staff</h2>
        <div className="seg">
          {["Teacher", "Staff"].map(r => <button key={r} type="button" className={role === r ? "on" : ""} onClick={() => setRole(r)}>{r === "Teacher" ? "Teachers" : "Staff"}</button>)}
        </div>
      </div>

      <div className="toolbar">
        <input type="date" value={date} max={todayIso()} onChange={e => e.target.value && setDate(e.target.value)} />
        <input className="search" placeholder="Search name or ID" value={q} onChange={e => setQ(e.target.value)} />
        <button className="btn-secondary" type="button" onClick={() => { setLoading(true); load(); }} title="Refresh" aria-label="Refresh"><Icon name="refresh" size={15} /></button>
      </div>

      <div className="count-row">
        <div className="big-count">{present.length}<span>/{total}</span></div>
        <div className="count-label">present · {pct}%</div>
      </div>
      <div className="progress"><span style={{ width: `${pct}%` }} /></div>

      {error && <div className="auth-error">{error}</div>}
      {loading ? <p className="muted">Loading…</p> : rows.length === 0 ? (
        <p className="muted">{total === 0 ? "No one to show yet." : "No match."}</p>
      ) : (
        <ul className="roster">
          {rows.map(r => (
            <Fragment key={r.key}>
              <RosterRow
                name={r.name}
                sub={r.id}
                present={r.present}
                time={r.time}
                note={r.corrected ? <span className="badge" title={r.why}>By Admin</span> : null}
                action={r.present
                  ? <button className="link-btn" type="button" onClick={() => undo(r.recordId)}>Undo</button>
                  : <button className="link-btn ok" type="button" onClick={() => { setReasonFor(r.userId); setReason(""); }}>Mark present</button>}
              />
              {reasonFor === r.userId && <ReasonRow value={reason} onChange={e => setReason(e.target.value)} onSave={() => markPresent(r.userId)} onCancel={() => setReasonFor(null)} busy={busy} />}
            </Fragment>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ---------------- Class roster: who is in the class, who has scanned ---------------- */

function Roster({ classId, date, live }) {
  const [report, setReport] = useState(null);
  const [error, setError] = useState("");
  const [q, setQ] = useState("");
  const [reasonFor, setReasonFor] = useState(null);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);

  function load() {
    if (!classId) return;
    api.get("/attendance/report", { params: { classId: Number(classId), date } })
      .then(({ data }) => { setReport(data); setError(""); })
      .catch(e => setError(errMsg(e, "Could not load the class list.")));
  }
  useEffect(() => {
    setReport(null); setReasonFor(null); load();
    if (!live) return;
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, [classId, date, live]);

  async function markPresent(studentId) {
    setBusy(true); setError("");
    try {
      await api.post("/attendance/correct", { userId: studentId, classId: Number(classId), date, reason: reason.trim() });
      setReasonFor(null); setReason(""); load();
    } catch (e) { setError(errMsg(e, "Could not mark this student present.")); }
    finally { setBusy(false); }
  }

  async function undo(recordId) {
    if (!confirm("Set this student back to absent?")) return;
    try { await api.delete(`/attendance/${recordId}`); load(); }
    catch (e) { setError(errMsg(e, "Could not undo this.")); }
  }

  const present = report?.present ?? [];
  const absent = report?.absent ?? [];
  const total = present.length + absent.length;
  const pct = total ? Math.round((100 * present.length) / total) : 0;

  const needle = q.trim().toLowerCase();
  const rows = [
    ...[...present].sort((a, b) => new Date(b.checkInTime) - new Date(a.checkInTime)).map(p => ({ key: `p${p.id}`, name: p.userFullName, id: p.idNumber, present: true, time: clock(p.checkInTime), recordId: p.id, corrected: p.isCorrected, why: p.correctionReason })),
    ...[...absent].sort((a, b) => a.fullName.localeCompare(b.fullName)).map(a => ({ key: `a${a.userId}`, name: a.fullName, id: a.idNumber, present: false, userId: a.userId }))
  ].filter(r => !needle || r.name.toLowerCase().includes(needle) || (r.id || "").toLowerCase().includes(needle));

  return (
    <>
      <div className="count-row">
        <div className="big-count">{present.length}<span>/{total}</span></div>
        <div className="count-label">present · {pct}%{live && " · live"}</div>
      </div>
      <div className="progress"><span style={{ width: `${pct}%` }} /></div>

      <div className="toolbar">
        <input className="search" placeholder="Search student" value={q} onChange={e => setQ(e.target.value)} />
      </div>
      {error && <div className="auth-error">{error}</div>}

      {!report ? <p className="muted">Loading…</p> : total === 0 ? (
        <p className="muted">No students have joined this class yet.</p>
      ) : rows.length === 0 ? <p className="muted">No match.</p> : (
        <ul className="roster">
          {rows.map(r => (
            <Fragment key={r.key}>
              <RosterRow
                name={r.name}
                sub={r.id}
                present={r.present}
                time={r.time}
                note={r.corrected ? <span className="badge" title={r.why}>By Teacher</span> : null}
                action={r.present
                  ? <button className="link-btn" type="button" onClick={() => undo(r.recordId)}>Undo</button>
                  : <button className="link-btn ok" type="button" onClick={() => { setReasonFor(r.userId); setReason(""); }}>Mark present</button>}
              />
              {reasonFor === r.userId && <ReasonRow value={reason} onChange={e => setReason(e.target.value)} onSave={() => markPresent(r.userId)} onCancel={() => setReasonFor(null)} busy={busy} />}
            </Fragment>
          ))}
        </ul>
      )}
    </>
  );
}

/* ---------------- Teacher / Admin: start attendance for a class ---------------- */

function useSessionQr(sessionId) {
  const [qr, setQr] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    if (!sessionId) { setQr(null); return; }
    let cancelled = false;
    setQr(null); setError("");
    api.get(`/attendance/sessions/${sessionId}/qr`, { params: { clientUrl: `${window.location.origin}/attendance` } })
      .then(({ data }) => { if (!cancelled) setQr(data); })
      .catch(e => { if (!cancelled) setError(errMsg(e, "Could not load the QR.")); });
    return () => { cancelled = true; };
  }, [sessionId]);
  return { src: qr ? `data:image/png;base64,${qr.imageBase64}` : null, error };
}

function ClassSessions() {
  const { user } = useAuth();
  const isAdmin = user.role === "Admin";
  const [classes, setClasses] = useState([]);
  const [classId, setClassId] = useState("");
  const [duration, setDuration] = useState(20);
  const [session, setSession] = useState(null);
  const [remaining, setRemaining] = useState(0);
  const [starting, setStarting] = useState(false);
  const [error, setError] = useState("");
  const [full, setFull] = useState(false);
  const [recDate, setRecDate] = useState(todayIso());
  const qr = useSessionQr(session?.id);

  useEffect(() => {
    api.get("/classes").then(({ data }) => {
      const active = data.filter(c => c.isActive);
      setClasses(active);
      setClassId(id => id || (active[0] ? String(active[0].id) : ""));
    }).catch(e => setError(errMsg(e, "Could not load your classes.")));
    api.get("/attendance/sessions/mine").then(({ data }) => {
      if (data) { setSession(data); setClassId(String(data.classId)); }
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (!session) { setRemaining(0); return; }
    setRemaining(session.secondsRemaining);
    const t = setInterval(() => setRemaining(r => (r <= 1 ? 0 : r - 1)), 1000);
    return () => clearInterval(t);
  }, [session]);
  useEffect(() => { if (session && remaining === 0) setSession(null); }, [remaining]);

  async function start() {
    if (!classId) return;
    setStarting(true); setError("");
    try {
      const { data } = await api.post("/attendance/sessions", { classId: Number(classId), durationMinutes: Number(duration) });
      setSession(data); setClassId(String(data.classId)); setRecDate(todayIso());
    } catch (e) { setError(errMsg(e, "Could not start attendance.")); }
    finally { setStarting(false); }
  }

  async function end() {
    if (!session || !confirm("End attendance for this class now?")) return;
    try { await api.post(`/attendance/sessions/${session.id}/end`); } catch { /* cleared locally either way */ }
    setSession(null);
  }

  const title = session ? `${session.courseName}${session.section ? ` · ${session.section}` : ""}` : "";

  if (session) {
    return (
      <div className="live-grid">
        <div className="qr-panel">
          <span className="pill-live">● LIVE · QR ACTIVE</span>
          <h3>{title}</h3>
          {qr.error && <div className="auth-error">{qr.error}</div>}
          {qr.src ? <div className="qr-box"><img src={qr.src} alt="Class QR" /></div> : !qr.error && <p>Loading QR…</p>}
          <div className="countdown">{mmss(remaining)}</div>
          <div className="qr-sub">Students scan this QR to open their EduSync attendance panel</div>
          <div className="btn-row center">
            <button className="btn-light" type="button" disabled={!qr.src} onClick={() => setFull(true)}><Icon name="maximize" size={15} /> Full screen</button>
            <button className="btn-light danger" type="button" onClick={end}><Icon name="stop" size={14} /> End</button>
          </div>
        </div>
        <div className="card">
          <div className="card-title-row"><h2>Students</h2></div>
          <Roster classId={String(session.classId)} date={todayIso()} live />
        </div>
        {full && qr.src && <FullScreenQr src={qr.src} title={title} onClose={() => setFull(false)} />}
      </div>
    );
  }

  return (
    <>
      <div className="card">
        <div className="card-title-row"><div><div className="section-kicker">TEACHER CONTROL</div><h2>Open a QR attendance session</h2></div><span className="badge role-Teacher">Custom duration</span></div>
        {classes.length === 0 ? (
          <p className="muted">No classes yet.</p>
        ) : (
          <>
            <div className="attendance-class-picker">
              <div>
                <div className="field-label">Select class</div>
                <select className="attendance-class-select" value={classId} onChange={e => setClassId(e.target.value)}>
                  {classes.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.courseName}{c.section ? ` · Section ${c.section}` : ""}{c.room ? ` · Room ${c.room}` : ""}
                    </option>
                  ))}
                </select>
                <small className="muted">You can open attendance anytime for any class assigned to you.</small>
              </div>
              <div className="selected-class-preview">
                <span className="selected-class-dot">●</span>
                <div>
                  <strong>{classes.find(c => String(c.id) === classId)?.courseName || "Select a class"}</strong>
                  <span>{(() => { const c = classes.find(x => String(x.id) === classId); return c ? `${c.section ? `Section ${c.section}` : "Class"} · ${c.studentCount ?? 0} students` : ""; })()}</span>
                </div>
              </div>
            </div>
            <div className="start-row">
              <div className="duration-field">
                <div className="field-label">Custom attendance window</div>
                <div className="duration-input-wrap">
                  <input type="number" min="1" max="180" value={duration} onChange={e => setDuration(Math.max(1, Math.min(180, Number(e.target.value) || 1)))} />
                  <span>minutes</span>
                </div>
                <small className="muted">Choose any duration from 1–180 minutes. The QR expires automatically when the timer ends.</small>
              </div>
              <button className="btn-primary btn-lg" type="button" onClick={start} disabled={starting || !classId}>{starting ? "Starting…" : "Generate QR & start"}</button>
            </div>
          </>
        )}
        {error && <div className="auth-error">{error}</div>}
      </div>

      {classes.length > 0 && (
        <div className="card">
          <div className="card-title-row">
            <h2>Class records</h2>
            <div className="toolbar" style={{ margin: 0 }}>
              <select value={classId} onChange={e => setClassId(e.target.value)}>
                {classes.map(c => <option key={c.id} value={c.id}>{c.courseName}{c.section ? ` · ${c.section}` : ""}</option>)}
              </select>
              <input type="date" value={recDate} max={todayIso()} onChange={e => e.target.value && setRecDate(e.target.value)} />
            </div>
          </div>
          <Roster classId={classId} date={recDate} live={false} />
        </div>
      )}
    </>
  );
}

function CameraScanner({onDetected,onError}){
  const containerId=`qr-camera-reader-${useId().replace(/[^a-zA-Z0-9]/g,"")}`; const [status,setStatus]=useState("starting"); const handledRef=useRef(false); const onDetectedRef=useRef(onDetected); const onErrorRef=useRef(onError); onDetectedRef.current=onDetected; onErrorRef.current=onError;
  useEffect(()=>{let cancelled=false,scanner=null,started=false;if(!window.isSecureContext){setStatus("error");onErrorRef.current("Camera access needs HTTPS. Use https://localhost:5173/ or type the QR code manually.");return;}
    const config={fps:15,qrbox:(w,h)=>{const size=Math.max(150,Math.floor(Math.min(w,h)*.75));return{width:size,height:size}},disableFlip:false,videoConstraints:{facingMode:"environment",width:{ideal:1280},height:{ideal:720}}};
    (async()=>{try{const lib=await import("html5-qrcode");if(cancelled)return;const {Html5Qrcode,Html5QrcodeSupportedFormats}=lib;scanner=new Html5Qrcode(containerId,{formatsToSupport:[Html5QrcodeSupportedFormats.QR_CODE],useBarCodeDetectorIfSupported:true,experimentalFeatures:{useBarCodeDetectorIfSupported:true},verbose:false});const onFrame=text=>{if(handledRef.current)return;handledRef.current=true;scanner.stop().catch(()=>{});onDetectedRef.current(text)};try{await scanner.start({facingMode:"environment"},config,onFrame,()=>{});}catch{const cams=await Html5Qrcode.getCameras();if(!cams?.length)throw new Error("No camera found.");const {videoConstraints,...plain}=config;await scanner.start(cams[0].id,plain,onFrame,()=>{})}started=true;if(cancelled){scanner.stop().then(()=>scanner.clear()).catch(()=>{});return}setStatus("scanning")}catch(e){if(cancelled)return;setStatus("error");onErrorRef.current(`Could not access the camera. Allow camera permission and make sure another app is not using it. (${e?.message||e})`)}})();return()=>{cancelled=true;if(scanner&&started)scanner.stop().then(()=>scanner.clear()).catch(()=>{})}},[containerId]);
  return <div className="qr-scanner-box"><div id={containerId}/>{status==="starting"&&<p className="muted">Starting camera…</p>}{status==="scanning"&&<p className="muted small-note">Hold the phone steady 15–25 cm from the QR and keep glare off the screen.</p>}</div>;
}
