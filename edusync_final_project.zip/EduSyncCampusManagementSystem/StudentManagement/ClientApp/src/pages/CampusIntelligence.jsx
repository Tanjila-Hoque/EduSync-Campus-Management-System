import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import PageHeader from "../components/PageHeader.jsx";
import Icon from "../components/Icon.jsx";
import { errMsg } from "../utils/errors.js";

function Metric({ icon, tone, label, value, note }) {
  return <div className="stat-card">
    <div className={`stat-icon ${tone}`}><Icon name={icon} size={20} /></div>
    <div><div className="stat-value">{value ?? "—"}</div><div className="stat-label">{label}</div>{note && <div className="muted small-note" style={{ marginTop: 3 }}>{note}</div>}</div>
  </div>;
}

function TrendChart({ title, subtitle, rows, color = "brand" }) {
  const max = Math.max(1, ...rows.map((r) => r.count));
  return <section className="card">
    <div className="card-head"><div><h2>{title}</h2><p className="sub">{subtitle}</p></div></div>
    {rows.every((r) => r.count === 0) ? <p className="muted">No records in this period.</p> : (
      <div className="intelligence-trend">
        {rows.map((row) => <div className="intelligence-trend-day" key={row.date} title={`${row.date}: ${row.count}`}>
          <span className="intelligence-trend-value">{row.count}</span>
          <div className="intelligence-trend-track"><div className={`intelligence-trend-bar ${color}`} style={{ height: `${Math.max(3, (row.count / max) * 100)}%` }} /></div>
          <span className="intelligence-trend-label">{String(row.date).slice(5)}</span>
        </div>)}
      </div>
    )}
  </section>;
}

export default function CampusIntelligence() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function load() {
    setLoading(true);
    setError("");
    try {
      const response = await api.get("/campus-intelligence/overview");
      setData(response.data);
    } catch (err) {
      setError(errMsg(err, "Could not load campus intelligence."));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  const totals = data?.totals;
  return <div className="page">
    <PageHeader
      icon="chart"
      title="Campus Intelligence"
      subtitle="Institution-wide operational insights calculated from live PostgreSQL records."
      actions={<button type="button" className="btn-secondary btn-sm" onClick={load} disabled={loading}><Icon name="refresh" size={14} /> Refresh</button>}
    />

    {error && <div className="auth-error"><Icon name="alert" size={16} /> {error}</div>}
    {loading && !data && <div className="card"><p className="muted">Loading live campus metrics…</p></div>}

    {data && <>
      <div className="intelligence-hero card">
        <div><div className="intelligence-eyebrow">CAMPUS OVERVIEW</div><h2>One view. Better decisions.</h2><p>Explore student population, academic activity, engagement and recent system actions. Figures are derived from the current database.</p></div>
        <div className="intelligence-hero-links"><Link to="/success-radar" className="btn-secondary btn-sm">Student Success Radar <Icon name="arrowRight" size={14} /></Link><Link to="/routine" className="btn-secondary btn-sm">Review timetable <Icon name="arrowRight" size={14} /></Link></div>
      </div>

      <div className="stat-grid">
        <Metric icon="users" tone="blue" label="Total students" value={totals.totalStudents} note={`${totals.activeStudents} active`} />
        <Metric icon="cap" tone="teal" label="Teachers" value={totals.totalTeachers} note={`${totals.activeTeachers} active`} />
        <Metric icon="book" tone="violet" label="Active classes" value={totals.activeClasses} note={`${totals.activeEnrollments} active enrollments`} />
        <Metric icon="check" tone="green" label="Class attendance today" value={totals.classAttendanceToday} note="Student-class attendance records" />
        <Metric icon="award" tone="gold" label="Results recorded" value={totals.resultCount} note={`Average coursework marks: ${Number(totals.averageCourseworkMarks || 0).toFixed(1)}`} />
        <Metric icon="megaphone" tone="blue" label="Published notices" value={totals.noticeCount} />
        <Metric icon="bell" tone="red" label="Unread notifications" value={totals.unreadNotifications} />
        <Metric icon="calendar" tone="teal" label="Scheduled classes" value={totals.scheduledEntries} note={`${totals.totalStaff} staff members`} />
      </div>

      <div className="intelligence-chart-grid">
        <TrendChart title="Attendance activity" subtitle="Daily class-attendance records · last 14 campus days" rows={data.attendanceTrend || []} color="teal" />
        <TrendChart title="Results activity" subtitle="Results entered per day · last 14 campus days" rows={data.resultsTrend || []} color="brand" />
      </div>

      <div className="intelligence-detail-grid">
        <section className="card">
          <div className="card-head"><div><h2>Department distribution</h2><p className="sub">Students and teachers by recorded department.</p></div></div>
          {data.departmentBreakdown?.length ? <div className="table-wrap"><table><thead><tr><th>Department</th><th>Students</th><th>Teachers</th></tr></thead><tbody>
            {data.departmentBreakdown.map((d) => <tr key={d.department}><td><strong>{d.department || "Unassigned"}</strong></td><td>{d.students}</td><td>{d.teachers}</td></tr>)}
          </tbody></table></div> : <p className="muted">No department data is available yet.</p>}
        </section>

        <section className="card">
          <div className="card-head"><div><h2>System health</h2><p className="sub">A quick check of your active campus records.</p></div><span className="pill green">Live data</span></div>
          <div className="intelligence-health-list">
            <div><span>Active users</span><strong>{totals.activeUsers} / {totals.totalUsers}</strong></div>
            <div className="intelligence-meter"><span style={{ width: `${totals.totalUsers ? Math.min(100, (totals.activeUsers / totals.totalUsers) * 100) : 0}%` }} /></div>
            <div><span>Active students</span><strong>{totals.activeStudents} / {totals.totalStudents}</strong></div>
            <div className="intelligence-meter"><span style={{ width: `${totals.totalStudents ? Math.min(100, (totals.activeStudents / totals.totalStudents) * 100) : 0}%` }} /></div>
            <div className="intelligence-health-foot"><span>Admin dashboard overview</span><strong>{new Date(data.generatedAt).toLocaleString()}</strong></div>
          </div>
          <p className="muted small-note" style={{ marginBottom: 0, marginTop: 12 }}>These indicators describe record status, not a security or uptime audit.</p>
        </section>
      </div>

      <section className="card">
        <div className="card-head"><div><h2>Recent system activity</h2><p className="sub">Latest actions recorded in the audit log.</p></div><Link to="/audit-log" className="btn-secondary btn-sm">Open audit log <Icon name="arrowRight" size={14} /></Link></div>
        {data.recentActivity?.length ? <div className="table-wrap"><table><thead><tr><th>Actor</th><th>Action</th><th>Details</th><th>Time</th></tr></thead><tbody>
          {data.recentActivity.map((a) => <tr key={a.id}><td><strong>{a.actorName || "System"}</strong><div className="muted small-note">{a.actorRole || "—"}</div></td><td>{a.action}</td><td>{a.details || "—"}</td><td className="nowrap">{new Date(a.timestamp).toLocaleString()}</td></tr>)}
        </tbody></table></div> : <p className="muted">No audit activity recorded yet.</p>}
      </section>
    </>}
  </div>;
}
