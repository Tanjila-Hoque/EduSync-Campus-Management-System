import { useEffect, useState } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext.jsx";
import PageHeader from "../components/PageHeader.jsx";
import Icon from "../components/Icon.jsx";

const tone = (level) => level === "At risk" ? "#d64545" : level === "Needs attention" ? "#d9922b" : "#1f9d55";
function Metric({ label, value, note }) { return <div className="card" style={{ margin: 0, minWidth: 140, flex: "1 1 150px" }}><div className="muted small-note">{label}</div><div style={{ fontSize: 27, fontWeight: 750 }}>{value}</div><div className="muted small-note">{note}</div></div>; }

export default function StudentSuccessRadar() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const load = () => { setLoading(true); api.get("/student-success/radar").then(r => { setData(r.data); setError(""); }).catch(e => setError(e.response?.data?.message || "Unable to load student-success insights. Check your access and database connection.")).finally(() => setLoading(false)); };
  useEffect(() => { load(); }, []);
  async function notify() {
    setBusy(true);
    try { const r = await api.post("/student-success/notify"); window.alert(r.data.message); }
    catch (e) { window.alert(e.response?.data?.message || "Could not create notifications."); }
    finally { setBusy(false); }
  }
  return <div className="page">
    <PageHeader icon="chart" title="AI Student Success Radar" subtitle="Explainable early-warning signals from live attendance and academic records." />
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 16 }}>
      <Metric label="Students assessed" value={data?.totalStudents ?? "—"} note="Active student records" />
      <Metric label="At risk" value={data?.atRisk ?? "—"} note="Needs timely support" />
      <Metric label="Needs attention" value={data?.needsAttention ?? "—"} note="Monitor closely" />
      <Metric label="Average attendance" value={data ? `${data.averageAttendance}%` : "—"} note="From recorded sessions" />
      <Metric label="Academic average" value={data ? `${data.averageAcademic}%` : "—"} note="Students with results" />
    </div>
    {error && <div className="auth-error">{error}</div>}
    {loading && <div className="card">Analyzing PostgreSQL records…</div>}
    {data && user.role === "Student" && <section className="card">
      <h2>Your personalized study plan</h2>
      <p className="muted">Based on your recorded attendance and result records. AI advice can be unavailable if Gemini is not configured.</p>
      <div style={{ whiteSpace: "pre-wrap", lineHeight: 1.7 }}>{data.personalizedPlan || data.students[0]?.recommendation || "Keep attending classes and review your latest results."}</div>
      {!data.aiGenerated && <p className="muted small-note">Rule-based fallback shown; Gemini did not generate this plan.</p>}
    </section>}
    {data && user.role !== "Student" && <section className="card">
      <div className="card-head"><div><h2>Risk distribution</h2><p className="sub">Counts are computed from current database records, not sample data.</p></div>
        {user.role === "Admin" || user.role === "Teacher" ? <button className="btn-primary btn-sm" disabled={busy} onClick={notify}><Icon name="bell" size={15}/> {busy ? "Creating…" : "Notify at-risk students"}</button> : null}
      </div>
      {["At risk","Needs attention","On track"].map(level => {
        const count = data.students.filter(s => s.riskLevel === level).length;
        const pct = data.totalStudents ? count / data.totalStudents * 100 : 0;
        return <div key={level} style={{ margin: "14px 0" }}><div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}><strong>{level}</strong><span>{count} ({Math.round(pct)}%)</span></div><div style={{ height:10, background:"var(--border)", borderRadius:8, overflow:"hidden" }}><div style={{ height:"100%", width:`${pct}%`, background:tone(level), borderRadius:8 }}/></div></div>;
      })}
    </section>}
    {data && <section className="card">
      <div className="card-head"><div><h2>{user.role === "Student" ? "Your risk signals" : "Student support queue"}</h2><p className="sub">Every signal includes the underlying reason and a practical next step.</p></div><button className="btn-secondary btn-sm" onClick={load}>Refresh</button></div>
      {data.students.length === 0 ? <p className="muted">No eligible student records found for your role.</p> : data.students.map(s => <article key={s.studentId} style={{ borderTop:"1px solid var(--border)", padding:"16px 0" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:12, flexWrap:"wrap" }}>
          <div><h3 style={{margin:"0 0 4px"}}>{s.name}</h3><div className="muted small-note">{s.studentNumber || `Student #${s.studentId}`}</div></div>
          <span style={{ background:tone(s.riskLevel), color:"white", borderRadius:99, padding:"4px 10px", fontSize:12, fontWeight:700 }}>{s.riskLevel} · score {s.riskScore}</span>
        </div>
        <div style={{display:"flex", gap:18, flexWrap:"wrap", margin:"12px 0"}}><span>Attendance <strong>{s.attendanceSessions ? `${s.attendancePercent}%` : "No data"}</strong></span><span>Academic average <strong>{s.resultCount ? `${s.academicAverage}%` : "No results"}</strong></span><span>Result records <strong>{s.resultCount}</strong></span></div>
        <div style={{background:"var(--surface-muted, rgba(127,140,160,.08))", borderRadius:10, padding:12}}><strong>Why this student is flagged</strong><ul style={{marginBottom:8}}>{s.reasons.map((r,i)=><li key={i}>{r}</li>)}</ul><strong>Recommended next step:</strong> {s.recommendation}</div>
      </article>)}
    </section>}
  </div>;
}
