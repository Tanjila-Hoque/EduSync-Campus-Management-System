import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext.jsx";
import PageHeader from "../components/PageHeader.jsx";

// Quick-start questions per role. Clicking one sends it straight away.
const SUGGESTIONS = {
  Student: [
    "আমার attendance কেমন? কোন class এ risk আছে?",
    "Amar result gulo ar grade bolo",
    "Aj amar koita class ache?",
    "Make me a study plan for this week",
    "How many marks do I need in the final to get an A?",
    "Explain recursion with a simple example",
  ],
  Teacher: [
    "Which students are below 75% in my classes?",
    "Show today's attendance for my first class",
    "Give me a results summary of my class",
    "What is my routine today?",
    "Suggest a 10-question quiz on binary trees",
  ],
  Admin: [
    "Give me a campus summary",
    "Which teachers have not checked in today?",
    "Show students below 75% attendance across campus",
    "What happened recently in the audit log?",
    "List all teachers with their departments",
  ],
  Staff: [
    "What are the latest notices?",
    "Which classes run on Sunday?",
    "Explain how the attendance system works",
  ],
};

const STORAGE_KEY = "aiChatMessages";

function loadMessages() {
  try { return JSON.parse(sessionStorage.getItem(STORAGE_KEY) || "[]"); } catch { return []; }
}

export default function AIPage() {
  const { user } = useAuth();
  const canNotice = ["Admin", "Teacher"].includes(user.role);
  const [tab, setTab] = useState(canNotice ? "notice" : "chat");
  const [topic, setTopic] = useState("");
  const [language, setLanguage] = useState("English");
  const [draft, setDraft] = useState("");
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState(loadMessages);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const endRef = useRef(null);

  useEffect(() => {
    try { sessionStorage.setItem(STORAGE_KEY, JSON.stringify(messages.slice(-40))); } catch { /* ignore */ }
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, busy]);

  async function generate() {
    setBusy(true); setError("");
    try { const { data } = await api.post("/ai/notice", { topic, language }); setDraft(data.text); }
    catch (e) { setError(e.response?.data?.message || "Could not generate notice."); }
    finally { setBusy(false); }
  }

  async function send(text) {
    const q = (text ?? question).trim();
    if (!q || busy) return;
    const history = messages.filter(m => !m.error).map(m => ({ role: m.role, text: m.text }));
    setQuestion(""); setError(""); setBusy(true);
    setMessages(m => [...m, { role: "user", text: q }]);
    try {
      const { data } = await api.post("/ai/chat", { question: q, history });
      setMessages(m => [...m, { role: "model", text: data.text }]);
    } catch (e) {
      setMessages(m => [...m, { role: "model", error: true, text: e.response?.data?.message || "Could not contact the AI. Please try again." }]);
    } finally { setBusy(false); }
  }

  function onKeyDown(e) {
    // Enter sends, Shift+Enter makes a new line. Ignore Enter while a Bangla/IME composition is active.
    if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); send(); }
  }

  function clearChat() { setMessages([]); setError(""); }

  function toNotices() {
    sessionStorage.setItem("aiNoticeDraft", draft);
    window.location.assign("/notices");
  }

  const suggestions = SUGGESTIONS[user.role] || SUGGESTIONS.Staff;

  return <div className="page">
    <PageHeader icon="chart" title="Gemini AI Assistant" subtitle="Ask about your campus data, get study help, or ask anything" />
    <div className="card" style={{ padding: 22 }}>
      <div className="row" style={{ marginBottom: 18 }}>
        {canNotice && <button type="button" className={tab === "notice" ? "btn-primary" : "btn-secondary"} onClick={() => setTab("notice")}>AI Notice Generator</button>}
        <button type="button" className={tab === "chat" ? "btn-primary" : "btn-secondary"} onClick={() => setTab("chat")}>Campus Chatbot</button>
      </div>
      {error && <div className="auth-error">{error}</div>}

      {tab === "notice" && canNotice ? <div>
        <label>Notice topic</label><textarea rows={3} value={topic} onChange={e => setTopic(e.target.value)} placeholder="Describe the notice" maxLength={2000}/>
        <div className="row"><select value={language} onChange={e => setLanguage(e.target.value)}><option>English</option><option>Bangla</option></select>
        <button type="button" className="btn-primary" disabled={busy || !topic.trim()} onClick={generate}>{busy ? "Generating…" : "Generate Notice"}</button></div>
        {draft && <div style={{ marginTop: 20 }}><label>Review and edit before publishing</label><textarea rows={12} value={draft} onChange={e => setDraft(e.target.value)} />
          <div className="row"><button type="button" onClick={() => navigator.clipboard.writeText(draft)}>Copy</button><button type="button" className="btn-primary" onClick={toNotices}>Use in Notice Composer</button></div></div>}
      </div> : <div>
        <p className="sub">Ask about your courses, attendance, results, routine and notices — or any study or general question. Campus answers use only the records your role is allowed to see.</p>

        <div className="ai-thread" aria-live="polite">
          {messages.length === 0 && <div className="ai-empty">
            <strong>Try asking:</strong>
            <div className="ai-chips">
              {suggestions.map(s => <button key={s} type="button" className="ai-chip" onClick={() => send(s)} disabled={busy}>{s}</button>)}
            </div>
          </div>}
          {messages.map((m, i) => <div key={i} className={`ai-msg ${m.role === "user" ? "ai-user" : "ai-bot"}${m.error ? " ai-error" : ""}`}>
            <div className="ai-who">{m.role === "user" ? "You" : "Assistant"}</div>
            {m.role === "user"
              ? <div className="ai-text">{m.text}</div>
              : <div className="ai-text ai-md"><ReactMarkdown remarkPlugins={[remarkGfm]}>{m.text}</ReactMarkdown></div>}
          </div>)}
          {busy && <div className="ai-msg ai-bot"><div className="ai-who">Assistant</div><div className="ai-text ai-typing"><span/><span/><span/></div></div>}
          <div ref={endRef} />
        </div>

        <div className="ai-input">
          <textarea rows={2} value={question} onChange={e => setQuestion(e.target.value)} onKeyDown={onKeyDown} maxLength={1000}
            placeholder="Ask anything — campus data, study help, general questions…  (Enter to send, Shift+Enter for new line)" />
          <div className="ai-actions">
            <button type="button" className="btn-secondary" onClick={clearChat} disabled={busy || messages.length === 0}>Clear chat</button>
            <button type="button" className="btn-primary" disabled={busy || !question.trim()} onClick={() => send()}>{busy ? "Thinking…" : "Send"}</button>
          </div>
        </div>
        {messages.length > 0 && <div className="ai-chips" style={{ marginTop: 12 }}>
          {suggestions.slice(0, 3).map(s => <button key={s} type="button" className="ai-chip" onClick={() => send(s)} disabled={busy}>{s}</button>)}
        </div>}
        <p className="sub" style={{ marginTop: 12, fontSize: 12 }}>AI can make mistakes. Check important marks and dates in the Results, Attendance and Routine pages.</p>
      </div>}
    </div>
  </div>;
}
