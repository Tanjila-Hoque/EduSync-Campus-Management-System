import { useEffect, useState } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext.jsx";
import PageHeader from "../components/PageHeader.jsx";
import EmptyState from "../components/EmptyState.jsx";
import Avatar from "../components/Avatar.jsx";
import Icon from "../components/Icon.jsx";

const ROLES_ALL = ["Student", "Teacher", "Staff", "Admin"];
const ROLE_LABEL = { Student: "Students", Teacher: "Teachers", Staff: "Staff", Admin: "Admins" };

/// Admin: can browse any role, and create/edit/deactivate/delete accounts.
/// Teacher: Students only, read-only (enforced by the backend too) - matches the
/// requirement that Staff never sees Teacher/Student personal details, and that
/// Teacher's own visibility is limited to Students.
export default function People() {
  const { user } = useAuth();
  const isAdmin = user.role === "Admin";

  const [role, setRole] = useState("Student");
  const [q, setQ] = useState("");
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [error, setError] = useState("");
  const [banner, setBanner] = useState(null); // { type: "ok" | "error", text }
  const [resetCode, setResetCode] = useState(null);

  const [qrFor, setQrFor] = useState(null); // the person whose QR modal is open
  const [editing, setEditing] = useState(null); // null closed · new-teacher/new-staff create · person = edit

  function load() {
    setLoading(true);
    api
      .get("/people", { params: { role, q: q || undefined, page, pageSize } })
      .then(({ data }) => {
        // Accept both the paged API response and legacy list responses.
        if (Array.isArray(data)) { setItems(data); setTotalCount(data.length); setTotalPages(1); }
        else { setItems(data.items || []); setTotalCount(data.totalCount || 0); setTotalPages(data.totalPages || 0); }
      })
      .catch((err) => setError(err.response?.data?.message || "Could not load people."))
      .finally(() => setLoading(false));
  }

  useEffect(() => { setPage(1); }, [role, q, pageSize]);
  useEffect(load, [role, q, page, pageSize]);

  async function handleToggleActive(person) {
    try {
      await api.put(`/people/${person.id}`, {
        fullName: person.fullName,
        email: person.email,
        phone: person.phone,
        role: person.role,
        idNumber: person.idNumber,
        department: person.department,
        isActive: !person.isActive
      });
      setBanner({ type: "ok", text: `${person.fullName} is now ${!person.isActive ? "active" : "inactive"}.` });
      load();
    } catch (err) {
      setBanner({ type: "error", text: err.response?.data?.message || "Could not update this account." });
    }
  }

  async function generateResetCode(person) {
    try {
      const { data } = await api.post("/people/password-reset-code", { userId: person.id });
      setResetCode({ person, code: data.code, expiresAt: data.expiresAt });
    } catch (err) {
      setBanner({ type: "error", text: err.response?.data?.message || "Could not generate a reset code." });
    }
  }

  async function handleDelete(person) {
    if (!confirm(`Permanently delete ${person.fullName}'s account? This cannot be undone.`)) return;
    try {
      await api.delete(`/people/${person.id}`);
      setBanner({ type: "ok", text: `${person.fullName}'s account was deleted.` });
      load();
    } catch (err) {
      setBanner({ type: "error", text: err.response?.data?.message || "Could not delete this account." });
    }
  }

  return (
    <div className="page">
      <PageHeader
        icon="users"
        title="People"
        subtitle="Manage the people and role-based access available in EduSync."
        actions={isAdmin && (
          <>
            <button className="btn-primary" onClick={() => setEditing("new-teacher")} type="button"><Icon name="plus" size={16} /> Add Teacher</button>
            <button className="btn-secondary" onClick={() => setEditing("new-staff")} type="button"><Icon name="plus" size={16} /> Add Staff</button>
            <button className="btn-secondary" onClick={() => setEditing("new-admin")} type="button"><Icon name="plus" size={16} /> Add Admin</button>
          </>
        )}
      />

      {banner && (
        <div className={banner.type === "ok" ? "auth-success" : "auth-error"}>
          <Icon name={banner.type === "ok" ? "checkCircle" : "alert"} size={16} /> {banner.text}
        </div>
      )}
      {error && <div className="auth-error"><Icon name="alert" size={16} /> {error}</div>}

      <div className="card flush">
        <div className="table-toolbar">
          {isAdmin ? (
            <div className="seg">
              {ROLES_ALL.map((r) => (
                <button key={r} type="button" className={role === r ? "on" : ""} onClick={() => setRole(r)}>{ROLE_LABEL[r]}</button>
              ))}
            </div>
          ) : (
            <span className="pill violet">Students</span>
          )}
          <div className="search-box">
            <Icon name="search" size={16} />
            <input placeholder="Search name / username / ID" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <div className="datatable-toolbar-right">
            <label className="datatable-size-label">Rows
              <select value={pageSize} onChange={e => setPageSize(Number(e.target.value))} aria-label="Rows per page">
                <option value={10}>10</option><option value={25}>25</option><option value={50}>50</option>
              </select>
            </label>
            <span className="muted">{totalCount} {totalCount === 1 ? "person" : "people"}</span>
          </div>
        </div>

        {loading ? (
          <p className="muted" style={{ padding: 24 }}>Loading…</p>
        ) : items.length === 0 ? (
          <EmptyState icon="users" title="No one found">Try a different search{isAdmin ? " or role" : ""}.</EmptyState>
        ) : (
          <div className="table-wrap datatable-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th><th>Username</th><th>ID</th><th>Department</th><th>Status</th><th>QR</th>
                  {isAdmin && <th></th>}
                </tr>
              </thead>
              <tbody>
                {items.map((p) => (
                  <tr key={p.id}>
                    <td>
                      <div className="cell-person">
                        <Avatar name={p.fullName} role={p.role} size={38} />
                        <div>
                          <div className="name">{p.fullName}</div>
                          <div className="sub">{p.email || p.role}</div>
                        </div>
                      </div>
                    </td>
                    <td>{p.username}</td>
                    <td>{p.idNumber || <span className="muted">—</span>}</td>
                    <td>{p.department || <span className="muted">—</span>}</td>
                    <td>{p.isActive ? <span className="pill green">Active</span> : <span className="pill gray">Inactive</span>}</td>
                    <td><button className="btn-secondary btn-sm" onClick={() => setQrFor(p)}><Icon name="qr" size={14} /> View QR</button></td>
                    {isAdmin && (
                      <td>
                        <div className="row-actions">
                          <button className="icon-btn" title="Edit" aria-label="Edit" onClick={() => setEditing(p)}><Icon name="edit" size={16} /></button>
                          <button className="btn-secondary btn-sm" onClick={() => handleToggleActive(p)}>{p.isActive ? "Deactivate" : "Activate"}</button>
                          <button className="icon-btn violet" title="Generate password reset code" aria-label="Reset code" onClick={() => generateResetCode(p)}><Icon name="key" size={16} /></button>
                          <button className="icon-btn danger" title="Delete" aria-label="Delete" onClick={() => handleDelete(p)}><Icon name="trash" size={16} /></button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="datatable-footer">
              <span className="muted">Showing {totalCount === 0 ? 0 : (page - 1) * pageSize + 1}–{Math.min(page * pageSize, totalCount)} of {totalCount}</span>
              <div className="datatable-pagination">
                <button type="button" className="btn-secondary btn-sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page <= 1 || loading}>Previous</button>
                <span className="datatable-page-indicator">Page {Math.min(page, Math.max(totalPages, 1))} of {Math.max(totalPages, 1)}</span>
                <button type="button" className="btn-secondary btn-sm" onClick={() => setPage(p => Math.min(Math.max(totalPages, 1), p + 1))} disabled={page >= totalPages || loading || totalPages === 0}>Next</button>
              </div>
            </div>
          </div>
        )}
      </div>

      {qrFor && <QrModal person={qrFor} isAdmin={isAdmin} onClose={() => setQrFor(null)} />}
      {resetCode && (
        <div className="modal-backdrop" onClick={() => setResetCode(null)}>
          <div className="modal-card reset-code-modal" onClick={(e) => e.stopPropagation()}>
            <div className="reset-code-icon"><Icon name="key" size={26} /></div>
            <h3>Verification code generated</h3>
            <p className="muted">Give this one-time code to <strong>{resetCode.person.fullName}</strong>. It expires in 15 minutes.</p>
            <div className="reset-code-value">{resetCode.code}</div>
            <p className="small-note muted">The code is shown only here and is stored securely as a hash.</p>
            <button className="btn-primary btn-lg" onClick={() => { navigator.clipboard?.writeText(resetCode.code); setResetCode(null); }}>
              <Icon name="copy" size={16} /> Copy &amp; close
            </button>
          </div>
        </div>
      )}
      {editing && (
        <PersonFormModal
          person={typeof editing === "string" ? null : editing}
          initialRole={editing === "new-staff" ? "Staff" : editing === "new-admin" ? "Admin" : "Teacher"}
          onClose={() => setEditing(null)}
          onSaved={(msg) => {
            setEditing(null);
            setBanner({ type: "ok", text: msg });
            load();
          }}
        />
      )}
    </div>
  );
}

/* ---------------- Admin: create a new account, or edit/reset-password an existing one ---------------- */

function PersonFormModal({ person, initialRole = "Teacher", onClose, onSaved }) {
  const isNew = !person;
  const [form, setForm] = useState({
    fullName: person?.fullName || "",
    username: person?.username || "",
    email: person?.email || "",
    phone: person?.phone || "",
    role: person?.role || initialRole,
    idNumber: person?.idNumber || "",
    department: person?.department || "",
    isActive: person?.isActive ?? true,
    password: ""
  });
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function firstValidationError(data) {
    if (!data?.errors) return null;
    const firstKey = Object.keys(data.errors)[0];
    return data.errors[firstKey]?.[0];
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    // Admin-set passwords have no restrictions: any characters, any length.
    setSaving(true);
    try {
      if (isNew) {
        await api.post("/people", {
          fullName: form.fullName.trim(),
          username: form.username.trim(),
          email: form.email || null,
          phone: form.phone || null,
          role: form.role,
          idNumber: form.idNumber || null,
          department: form.department || null,
          password: form.password,
          isActive: form.isActive
        });
        onSaved(`${form.fullName} (${form.role}) account created.`);
      } else {
        const payload = {
          fullName: form.fullName.trim(),
          email: form.email || null,
          phone: form.phone || null,
          role: form.role,
          idNumber: form.idNumber || null,
          department: form.department || null,
          isActive: form.isActive
        };
        if (form.password) payload.password = form.password;
        await api.put(`/people/${person.id}`, payload);
        onSaved(`${form.fullName}'s account was updated.`);
      }
    } catch (err) {
      const data = err.response?.data;
      setError(data?.message || firstValidationError(data) || "Could not save this account.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card wide" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" type="button" onClick={onClose} aria-label="Close"><Icon name="x" size={18} /></button>
        <form onSubmit={handleSubmit} className="modal-form">
          <div className="modal-head">
            <h3>{isNew ? `Add ${form.role}` : `Edit ${person.fullName}`}</h3>
            <p className="muted">
              {isNew ? "Create a Teacher, Staff, Student or Admin account." : "Username cannot be changed after an account is created."}
            </p>
          </div>

          <div className="modal-body">
            <div className="form-grid two">
              <div className="auth-field span-2">
                <label>Full name</label>
                <input value={form.fullName} onChange={(e) => update("fullName", e.target.value)} required />
              </div>

              {isNew && (
                <div className="auth-field">
                  <label>Username</label>
                  <input value={form.username} onChange={(e) => update("username", e.target.value)} required />
                </div>
              )}

              <div className="auth-field">
                <label>Account role</label>
                {isNew ? (
                  <div className="role-lock"><span className={`badge role-${form.role}`}>{form.role}</span><small>Created by Admin</small></div>
                ) : (
                  <select value={form.role} onChange={(e) => update("role", e.target.value)}>
                    {ROLES_ALL.map((r) => <option key={r} value={r}>{r}</option>)}
                  </select>
                )}
              </div>

              <div className="auth-field">
                <label>Email (optional)</label>
                <input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} />
              </div>

              <div className="auth-field">
                <label>Phone (optional)</label>
                <input value={form.phone} onChange={(e) => update("phone", e.target.value)} />
              </div>

              <div className="auth-field">
                <label>Roll / employee ID (optional)</label>
                <input value={form.idNumber} onChange={(e) => update("idNumber", e.target.value)} />
              </div>

              <div className="auth-field">
                <label>Department (optional)</label>
                <input value={form.department} onChange={(e) => update("department", e.target.value)} />
              </div>

              <div className="auth-field span-2">
                <label>{isNew ? "Password" : "Reset password (optional)"}</label>
                <input
                  type="password"
                  autoComplete="new-password"
                  value={form.password}
                  onChange={(e) => update("password", e.target.value)}
                  required={isNew}
                />
              </div>
            </div>

            <label className="check" style={{ marginTop: 6 }}>
              <input type="checkbox" checked={form.isActive} onChange={(e) => update("isActive", e.target.checked)} />
              <span>Account is active</span>
            </label>
          </div>

          <div className="modal-foot">
            {error && <div className="auth-error"><Icon name="alert" size={16} /> {error}</div>}
            <button className="btn-secondary" type="button" onClick={onClose}>Cancel</button>
            <button className="btn-primary" type="submit" disabled={saving}>
              {saving ? "Saving…" : isNew ? "Create account" : "Save changes"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* ---------------- QR code modal: view, print, regenerate ---------------- */

function QrModal({ person, isAdmin, onClose }) {
  const [imageBase64, setImageBase64] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [regenerating, setRegenerating] = useState(false);

  function load() {
    setLoading(true);
    setError("");
    api
      .get(`/people/${person.id}/qr`)
      .then(({ data }) => setImageBase64(data.imageBase64))
      .catch((err) => setError(err.response?.data?.message || "Could not load this QR code."))
      .finally(() => setLoading(false));
  }

  useEffect(load, [person.id]);

  function handlePrint() {
    const w = window.open("", "_blank", "width=420,height=560");
    w.document.write(`
      <html>
        <head><title>${person.fullName} - ID Card</title></head>
        <body style="font-family: sans-serif; text-align:center; padding:24px;">
          <h3>${person.fullName}</h3>
          <p style="color:#666;">${person.role}${person.idNumber ? " · " + person.idNumber : ""}</p>
          <img src="data:image/png;base64,${imageBase64}" style="width:220px;height:220px;" />
        </body>
      </html>
    `);
    w.document.close();
    w.focus();
    w.print();
  }

  async function handleRegenerate() {
    if (!confirm(`Issue a brand-new QR code for ${person.fullName}? The old one will stop working (e.g. for a lost ID card).`)) return;
    setRegenerating(true);
    try {
      await api.post(`/people/${person.id}/qr/regenerate`);
      load();
    } catch (err) {
      setError(err.response?.data?.message || "Could not regenerate the QR code.");
    } finally {
      setRegenerating(false);
    }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" type="button" onClick={onClose} aria-label="Close"><Icon name="x" size={18} /></button>
        <div className="qr-person">
          <Avatar name={person.fullName} role={person.role} size={56} />
          <h3>{person.fullName}</h3>
          <p className="muted">{person.role}{person.idNumber ? ` · ${person.idNumber}` : ""}</p>
        </div>

        {error && <div className="auth-error">{error}</div>}

        {loading ? (
          <p className="muted">Loading…</p>
        ) : imageBase64 ? (
          <>
            <img src={`data:image/png;base64,${imageBase64}`} alt="QR code" className="qr-image" />
            <div className="modal-actions">
              <button className="btn-primary" onClick={handlePrint}><Icon name="printer" size={16} /> Print ID card</button>
              {isAdmin && (
                <button className="btn-secondary" onClick={handleRegenerate} disabled={regenerating}>
                  <Icon name="refresh" size={16} /> {regenerating ? "Regenerating…" : "Regenerate"}
                </button>
              )}
            </div>
          </>
        ) : null}
      </div>
    </div>
  );
}


