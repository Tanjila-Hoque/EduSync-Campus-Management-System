// Short, general lines shown on the login screen and the dashboard footer. Edit freely.
export const QUOTES = [
  "Every great journey begins with a single class.",
  "Learn today. Lead tomorrow.",
  "Curious minds build better campuses.",
  "Show up. Learn. Grow.",
  "Small steps every day become big results.",
  "Knowledge shared is knowledge multiplied.",
  "A good campus is built by good habits.",
  "Ask questions. Stay curious. Keep going.",
  "Consistency beats intensity.",
  "Your effort today shapes your future."
];

export function quoteOfTheDay(date = new Date()) {
  const dayNumber = Math.floor(date.getTime() / 86400000);
  return QUOTES[dayNumber % QUOTES.length];
}
