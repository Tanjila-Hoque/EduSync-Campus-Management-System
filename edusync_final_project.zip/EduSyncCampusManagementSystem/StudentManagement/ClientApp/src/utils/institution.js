// Central place for app + campus branding. Put YOUR campus name here and it updates everywhere
// (login/signup, top bar, printed check-in sheets).
export const APP_NAME = "EduSync";
export const APP_SHORT_NAME = "EduSync";

export const INSTITUTION = {
  name: "EduSync Campus",
  shortName: "EduSync",
  tagline: "Learn. Connect. Grow."
};
