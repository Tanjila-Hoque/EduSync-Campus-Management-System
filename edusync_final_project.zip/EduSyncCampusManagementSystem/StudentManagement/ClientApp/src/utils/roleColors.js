// Consistent color per role, used for badges and the navbar avatar.
export const ROLE_COLORS = {
  Admin: { bg: "#fdeee0", fg: "#a5560c", solid: "#e0821f" },
  Teacher: { bg: "#e6f0fb", fg: "#1d4d85", solid: "#2f6feb" },
  Staff: { bg: "#eaf7ee", fg: "#1f7a41", solid: "#2fa860" },
  Student: { bg: "#f2ecfb", fg: "#5b3aa8", solid: "#7c5cd6" }
};

export function roleColor(role) {
  return ROLE_COLORS[role] || { bg: "#eef3fb", fg: "#163a63", solid: "#2f6feb" };
}

export function initials(name = "") {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
}
