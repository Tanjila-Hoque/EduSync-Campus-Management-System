import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

/**
 * A right-swipe-to-go-back gesture, like a phone's native back gesture.
 * Starting a touch within EDGE_ZONE px of the left edge and dragging right by more
 * than THRESHOLD px (without much vertical movement) navigates back one page.
 * Only touch input triggers it, so it does nothing on desktop with a mouse.
 */
const EDGE_ZONE = 28;
const THRESHOLD = 80;
const MAX_VERTICAL = 60;

export default function useSwipeBack() {
  const navigate = useNavigate();

  useEffect(() => {
    let startX = 0;
    let startY = 0;
    let tracking = false;

    function onTouchStart(e) {
      const t = e.touches[0];
      if (!t) return;
      tracking = t.clientX <= EDGE_ZONE;
      startX = t.clientX;
      startY = t.clientY;
    }

    function onTouchEnd(e) {
      if (!tracking) return;
      tracking = false;
      const t = e.changedTouches[0];
      if (!t) return;
      const dx = t.clientX - startX;
      const dy = Math.abs(t.clientY - startY);
      if (dx > THRESHOLD && dy < MAX_VERTICAL) {
        navigate(-1);
      }
    }

    window.addEventListener("touchstart", onTouchStart, { passive: true });
    window.addEventListener("touchend", onTouchEnd, { passive: true });
    return () => {
      window.removeEventListener("touchstart", onTouchStart);
      window.removeEventListener("touchend", onTouchEnd);
    };
  }, [navigate]);
}
