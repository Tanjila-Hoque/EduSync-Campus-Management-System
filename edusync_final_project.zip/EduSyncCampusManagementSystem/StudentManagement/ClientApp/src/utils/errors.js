// Turns any failed API call into a readable message.
// Handles our own { message }, ASP.NET validation errors ({ errors: { Field: [..] } }),
// plain 403/404/500 with no body, and "server not reachable" (no response at all).
export function errMsg(err, fallback = "Something went wrong.") {
  const res = err?.response;
  if (!res) return "Cannot reach the server. Is the API running (dotnet run) and are you online?";
  const d = res.data;
  if (d?.message) return d.message;
  if (d?.errors && typeof d.errors === "object") {
    const first = Object.values(d.errors).flat().filter(Boolean)[0];
    if (first) return String(first);
  }
  if (res.status === 403) return "You don't have permission to do that.";
  if (res.status === 401) return "Your session expired. Please sign in again.";
  if (res.status >= 500) return "Server error (" + res.status + "). Check the API console for details.";
  return d?.title || fallback;
}

// Local calendar date as YYYY-MM-DD (toISOString() gives the UTC date, which is
// *yesterday* in Bangladesh between 12:00am and 6:00am).
export function localDateIso(d = new Date()) {
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
