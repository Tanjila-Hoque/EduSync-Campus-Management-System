import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import Login from "./pages/Login.jsx";
import Signup from "./pages/Signup.jsx";
import ForgotPassword from "./pages/ForgotPassword.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import People from "./pages/People.jsx";
import Notices from "./pages/Notices.jsx";
import Routine from "./pages/Routine.jsx";
import Results from "./pages/Results.jsx";
import Attendance from "./pages/Attendance.jsx";
import AuditLog from "./pages/AuditLog.jsx";
import Classes from "./pages/Classes.jsx";
import Insights from "./pages/Insights.jsx";
import AIPage from "./pages/AIPage.jsx";
import StudentSuccessRadar from "./pages/StudentSuccessRadar.jsx";
import CampusIntelligence from "./pages/CampusIntelligence.jsx";
import Notifications from "./pages/Notifications.jsx";
import Shell from "./components/Shell.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";
import { useAuth } from "./context/AuthContext.jsx";
import useSwipeBack from "./utils/useSwipeBack.js";

export default function App() {
  const { user } = useAuth();
  const location = useLocation();
  useSwipeBack(); // swipe right from the left edge (phones) to go back a page

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/dashboard" /> : <Login />} />
      <Route path="/signup" element={user ? <Navigate to="/dashboard" /> : <Signup />} />
      <Route path="/forgot-password" element={user ? <Navigate to="/dashboard" /> : <ForgotPassword />} />

      {/* Everything below lives inside the app shell (sidebar + top bar) and needs a signed-in user. */}
      <Route element={<Shell />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/notices" element={<Notices />} />
        <Route path="/ai" element={<AIPage />} />
        <Route path="/success-radar" element={<ProtectedRoute roles={["Admin", "Teacher", "Student"]}><StudentSuccessRadar /></ProtectedRoute>} />
        <Route path="/campus-intelligence" element={<ProtectedRoute roles={["Admin"]}><CampusIntelligence /></ProtectedRoute>} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/routine" element={<Routine />} />
        <Route path="/insights" element={<ProtectedRoute roles={["Admin", "Teacher", "Student"]}><Insights /></ProtectedRoute>} />
        <Route path="/classes" element={<ProtectedRoute roles={["Admin", "Teacher", "Student"]}><Classes /></ProtectedRoute>} />

        {/* Staff is deliberately excluded from Results and People - see backend
            ResultController / PeopleController. Staff IS included in Attendance so they
            can self check-in via the entrance QR (see Attendance.jsx / AttendanceController). */}
        <Route path="/attendance" element={<ProtectedRoute roles={["Admin", "Teacher", "Staff", "Student"]}><Attendance /></ProtectedRoute>} />
        <Route path="/results" element={<ProtectedRoute roles={["Admin", "Teacher", "Student"]}><Results /></ProtectedRoute>} />
        <Route path="/people" element={<ProtectedRoute roles={["Admin", "Teacher"]}><People /></ProtectedRoute>} />
        <Route path="/audit-log" element={<ProtectedRoute roles={["Admin"]}><AuditLog /></ProtectedRoute>} />
      </Route>

      <Route path="/" element={<Navigate to={user ? "/dashboard" : "/login"} replace state={{ from: location }} />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
