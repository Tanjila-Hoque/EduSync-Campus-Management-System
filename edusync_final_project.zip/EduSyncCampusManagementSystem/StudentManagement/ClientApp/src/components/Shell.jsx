import { useEffect, useState } from "react";
import { Navigate, NavLink, Outlet, useLocation, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { roleColor } from "../utils/roleColors.js";
import { APP_SHORT_NAME, INSTITUTION } from "../utils/institution.js";
import { longDate } from "../utils/format.js";
import Icon from "./Icon.jsx";
import Avatar from "./Avatar.jsx";
import PhotoBackdrop from "./PhotoBackdrop.jsx";

function navFor(role) {
  const all = ["Admin", "Teacher", "Staff", "Student"];
  const academic = ["Admin", "Teacher", "Student"];
  const groups = [
    {
      label: "Overview",
      items: [{ to: "/dashboard", label: "Dashboard", icon: "dashboard", roles: all },
        { to: "/campus-intelligence", label: "Campus Intelligence", icon: "chart", roles: ["Admin"] }]
    },
    {
      label: "Academics",
      items: [
        { to: "/classes", label: "Classes", icon: "book", roles: academic },
        { to: "/attendance", label: "Attendance", icon: "check", roles: all },
        { to: "/routine", label: "Routine", icon: "calendar", roles: all },
        { to: "/results", label: "Results", icon: "award", roles: academic },
        { to: "/insights", label: "Insights", icon: "chart", roles: academic },
        { to: "/success-radar", label: "Student Success Radar", icon: "chart", roles: academic }
      ]
    },
    {
      label: "Communication",
      items: [{ to: "/notices", label: "Notices", icon: "megaphone", roles: all }, { to: "/notifications", label: "Notifications", icon: "bell", roles: all }, { to: "/ai", label: "AI Assistant", icon: "chart", roles: all }]
    },
    {
      label: "Administration",
      items: [
        { to: "/people", label: "People", icon: "users", roles: ["Admin", "Teacher"] },
        { to: "/audit-log", label: "Audit Log", icon: "shield", roles: ["Admin"] }
      ]
    }
  ];
  return groups
    .map((g) => ({ ...g, items: g.items.filter((i) => i.roles.includes(role)) }))
    .filter((g) => g.items.length > 0);
}

export default function Shell() {
  const { user, loading, logout } = useAuth();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [unread, setUnread] = useState(0);

  useEffect(() => setOpen(false), [location.pathname]);

  useEffect(() => {
    if (!user) return;
    function fetchUnread() { import("../api/axios").then(({ default: api }) => api.get("/notifications?page=1&pageSize=1").then(r => setUnread(r.data.unread || 0)).catch(() => {})); }
    fetchUnread();
    const timer = window.setInterval(fetchUnread, 60000);
    return () => window.clearInterval(timer);
  }, [user, location.pathname]);

  if (loading) return <div className="page-loading"><span className="spinner" /> Loading…</div>;
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;

  const color = roleColor(user.role);
  const groups = navFor(user.role);

  return (
    <div className="shell">
      <PhotoBackdrop variant="app" />
      <aside className={`sidebar ${open ? "open" : ""}`}>
        <div className="sidebar-brand">
          <span className="brand-mark"><Icon name="cap" size={20} /></span>
          <div>
            <div className="brand-name">{APP_SHORT_NAME}</div>
          </div>
          <button className="sidebar-close" type="button" onClick={() => setOpen(false)} aria-label="Close menu">
            <Icon name="x" />
          </button>
        </div>

        <nav className="sidebar-nav">
          {groups.map((g) => (
            <div key={g.label} className="nav-group">
              <div className="nav-group-label">{g.label}</div>
              {g.items.map((i) => (
                <NavLink key={i.to} to={i.to} className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}>
                  <Icon name={i.icon} size={18} />
                  <span>{i.label}</span>
                </NavLink>
              ))}
            </div>
          ))}
        </nav>

        <div className="sidebar-user">
          <Avatar name={user.fullName} role={user.role} size={38} />
          <div className="sidebar-user-text">
            <div className="sidebar-user-name">{user.fullName}</div>
            <span className="role-chip" style={{ background: color.bg, color: color.fg }}>{user.role}</span>
          </div>
          <button className="icon-btn" type="button" onClick={logout} title="Log out" aria-label="Log out">
            <Icon name="logout" size={18} />
          </button>
        </div>
      </aside>

      {open && <div className="sidebar-backdrop" onClick={() => setOpen(false)} />}

      <div className="shell-main">
        <header className="topbar">
          <button className="icon-btn menu-btn" type="button" onClick={() => setOpen(true)} aria-label="Open menu">
            <Icon name="menu" size={20} />
          </button>
          <div className="topbar-institution">
            <Icon name="building" size={16} />
            <span>{INSTITUTION.name}</span>
          </div>
          <div className="topbar-right">
            <span className="topbar-date">{longDate()}</span>
            <div className="topbar-user">
              <Avatar name={user.fullName} role={user.role} size={32} />
              <div className="topbar-user-text">
                <strong>{user.fullName}</strong>
                <span>{user.role}</span>
              </div>
            </div>
          </div>
        </header>

        <main className="shell-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
