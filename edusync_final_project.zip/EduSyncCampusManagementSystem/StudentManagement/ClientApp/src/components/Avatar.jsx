import { roleColor, initials } from "../utils/roleColors.js";

export default function Avatar({ name, role, size = 36 }) {
  const color = roleColor(role);
  return (
    <span
      className="avatar"
      style={{ width: size, height: size, fontSize: Math.round(size * 0.38), background: color.bg, color: color.fg }}
      title={name}
    >
      {initials(name)}
    </span>
  );
}
