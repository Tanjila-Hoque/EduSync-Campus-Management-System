import { useEffect, useState } from "react";
import { QUOTES } from "../utils/quotes.js";
import { APP_NAME } from "../utils/institution.js";
import Icon from "./Icon.jsx";

// Real campus photographs from Wikimedia Commons (free licences, credit shown on screen).
// Each photo is looked for as a LOCAL file first (public/photos/campus-N.jpg - created by download-photos.bat),
// and only if that file is missing is the online copy used. Your own photo wins over all of them:
// save it as  public/campus.jpg  and ONLY that photo is used.
const commons = (file, width = 1600) => `https://commons.wikimedia.org/wiki/Special:FilePath/${file}?width=${width}`;

export const PHOTOS = [
  { id: "own", files: ["/campus.jpg"], credit: null },
  { id: "p1", files: ["/photos/campus-1.jpg", commons("Main_Building_at_the_University_of_Notre_Dame.jpg")], credit: "Matthew Rice · Wikimedia Commons" },
  { id: "p2", files: ["/photos/campus-2.jpg", commons("Main_Building_-_Drexel_University_%2853590618820%29.jpg")], credit: "ajay_suresh · CC BY 2.0 · Wikimedia Commons" },
  { id: "p3", files: ["/photos/campus-3.jpg", commons("University_of_Mary_Main_Campus.jpg")], credit: "Jerry Anderson · CC BY-SA 4.0 · Wikimedia Commons" },
  { id: "p4", files: ["/photos/campus-4.jpg", commons("Whitman_College_Lawn.jpg")], credit: "Suzanne Shaw · CC BY 2.0 · Wikimedia Commons" }
];

// Resolves with the first address that really loads as an image (or null).
function loadFirst(files) {
  return new Promise((resolve) => {
    let i = 0;
    const next = () => {
      if (i >= files.length) return resolve(null);
      const src = files[i++];
      const img = new Image();
      img.onload = () => (img.naturalWidth ? resolve(src) : next());
      img.onerror = next;
      img.src = src;
    };
    next();
  });
}

/**
 * Full-screen campus photo behind the page. Only photos that really loaded are used, so a blocked or
 * missing picture can never leave a blank/broken background - the navy gradient shows instead.
 *  variant="auth": dark photo + brand + rotating lines (login / signup / forgot password)
 *  variant="app" : soft, light photo behind the signed-in workspace
 */
export default function PhotoBackdrop({ variant = "app" }) {
  const [loaded, setLoaded] = useState([]);
  const [active, setActive] = useState(0);
  const [quoteIndex, setQuoteIndex] = useState(() => Math.floor(Math.random() * QUOTES.length));

  useEffect(() => {
    let alive = true;
    PHOTOS.forEach((photo) => {
      loadFirst(photo.files).then((src) => {
        if (!alive || !src) return;
        setLoaded((list) =>
          list.some((p) => p.id === photo.id)
            ? list
            : [...list, { id: photo.id, src, credit: photo.credit }].sort(
                (x, y) => PHOTOS.findIndex((p) => p.id === x.id) - PHOTOS.findIndex((p) => p.id === y.id)
              )
        );
      });
    });
    return () => { alive = false; };
  }, []);

  const own = loaded.find((p) => p.id === "own");
  const slides = own ? [own] : loaded;
  const current = slides.length ? slides[active % slides.length] : null;

  useEffect(() => {
    if (slides.length < 2) return undefined;
    const t = setInterval(() => setActive((i) => i + 1), 9000);
    return () => clearInterval(t);
  }, [slides.length]);

  useEffect(() => {
    if (variant !== "auth") return undefined;
    const t = setInterval(() => setQuoteIndex((i) => (i + 1) % QUOTES.length), 6000);
    return () => clearInterval(t);
  }, [variant]);

  return (
    <div className={`backdrop ${variant}`} aria-hidden={variant === "app" ? "true" : undefined}>
      {slides.map((p) => (
        <div key={p.id} className={`backdrop-slide ${p === current ? "on" : ""}`} style={{ backgroundImage: `url("${p.src}")` }} />
      ))}
      <div className="backdrop-wash" />

      {variant === "auth" && (
        <>
          <div className="auth-brand">
            <span className="brand-mark light"><Icon name="cap" size={20} /></span>
            <div>
              <div className="brand-name">{APP_NAME}</div>
              <div className="brand-sub">Campus workspace</div>
            </div>
          </div>
          <div className="auth-quote">
            <span className="quote-dot" />
            <span key={quoteIndex} className="quote-line">{QUOTES[quoteIndex]}</span>
          </div>
        </>
      )}

      {current?.credit && <span className="backdrop-credit">Photo: {current.credit}</span>}
    </div>
  );
}
