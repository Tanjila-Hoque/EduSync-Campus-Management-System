import Icon from "./Icon.jsx";

/** Consistent page title block used at the top of every page. */
export default function PageHeader({ title, subtitle, icon, actions }) {
  return (
    <div className="page-header">
      <div className="page-header-main">
        {icon && (
          <span className="page-header-icon">
            <Icon name={icon} size={22} />
          </span>
        )}
        <div>
          <h1>{title}</h1>
          {subtitle && <p>{subtitle}</p>}
        </div>
      </div>
      {actions && <div className="page-header-actions">{actions}</div>}
    </div>
  );
}
