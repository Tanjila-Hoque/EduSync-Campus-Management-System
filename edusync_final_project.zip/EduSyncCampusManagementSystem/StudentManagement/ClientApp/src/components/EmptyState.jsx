import Icon from "./Icon.jsx";

export default function EmptyState({ icon = "info", title, children }) {
  return (
    <div className="empty-state">
      <span className="empty-icon"><Icon name={icon} size={22} /></span>
      <strong>{title}</strong>
      {children && <p>{children}</p>}
    </div>
  );
}
