import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import basicSsl from "@vitejs/plugin-basic-ssl";

export default defineConfig({
  // basicSsl gives the dev server a self-signed HTTPS certificate. Browsers only allow
  // camera access (for QR scanning) on "secure" origins - localhost counts automatically,
  // but a phone hitting this PC's LAN IP (e.g. https://192.168.1.23:5173) needs HTTPS.
  plugins: [react(), basicSsl()],
  server: {
    host: true, // listen on 0.0.0.0 so other devices on the same WiFi/LAN can reach it
    port: 5173,
    proxy: {
      // so the React app can call "/api/..." and it's forwarded to the ASP.NET Core API
      "/api": {
        target: "http://localhost:5100",
        changeOrigin: true
      },
      "/uploads": {
        target: "http://localhost:5100",
        changeOrigin: true
      }
    }
  }
});
