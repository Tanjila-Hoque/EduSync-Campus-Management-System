using System.ComponentModel.DataAnnotations;

namespace StudentManagement.Models;

public class InAppNotification
{
    public long Id { get; set; }
    public int UserId { get; set; }
    public User User { get; set; } = null!;
    [Required, StringLength(120)] public string Title { get; set; } = "";
    [Required, StringLength(1200)] public string Message { get; set; } = "";
    [Required, StringLength(40)] public string Kind { get; set; } = "info";
    public string? Link { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ReadAt { get; set; }
}
