namespace StudentManagement.Models;

/// <summary>Append-only trail of who-did-what, viewable by Admin only (AuditLogController).</summary>
public class AuditLog
{
    public int Id { get; set; }

    public int ActorUserId { get; set; }
    public string ActorName { get; set; } = "";
    public string ActorRole { get; set; } = "";

    public string Action { get; set; } = "";       // e.g. "Person.Create", "Attendance.Mark"
    public string Details { get; set; } = "";       // short human-readable summary

    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}
