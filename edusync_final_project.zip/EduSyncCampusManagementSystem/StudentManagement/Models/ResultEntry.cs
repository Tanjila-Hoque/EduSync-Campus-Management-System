using System.ComponentModel.DataAnnotations.Schema;

namespace StudentManagement.Models;

public class ResultEntry
{
    public int Id { get; set; }

    public int StudentId { get; set; }
    public User Student { get; set; } = null!;

    public string CourseName { get; set; } = "";

    public double Mid { get; set; }
    public double Final { get; set; }
    public double Assignment { get; set; }

    /// <summary>Attendance contributes up to 10 marks and is calculated from class attendance.</summary>
    [NotMapped]
    public double AttendanceMarks { get; set; }

    /// <summary>Coursework marks + attendance marks. Base coursework is kept backward compatible.</summary>
    [NotMapped]
    public double Total => Math.Round(Mid + Final + Assignment + AttendanceMarks, 2);

    /// <summary>Grade is based on the percentage of the 110-mark maximum.</summary>
    [NotMapped]
    public string Grade
    {
        get
        {
            var percentage = Total / 110.0 * 100.0;
            return percentage switch
            {
                >= 80 => "A+",
                >= 75 => "A",
                >= 70 => "A-",
                >= 65 => "B+",
                >= 60 => "B",
                >= 55 => "B-",
                >= 50 => "C",
                >= 40 => "D",
                _ => "F"
            };
        }
    }

    public int EnteredByUserId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
