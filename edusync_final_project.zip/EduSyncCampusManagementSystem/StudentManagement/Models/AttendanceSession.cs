namespace StudentManagement.Models;

/// <summary>A time-limited window (e.g. 10 minutes) a Teacher opens for one course+section.
/// Scanning a student's personal QR (see AttendanceController.Scan) only counts while a
/// session is active - EndedEarly is false and ExpiresAt is still in the future.</summary>
public class AttendanceSession
{
    public int Id { get; set; }

    public int? ClassId { get; set; }
    public AcademicClass? Class { get; set; }

    public string CourseName { get; set; } = "";
    public string Section { get; set; } = "";

    public int TeacherId { get; set; }
    public User Teacher { get; set; } = null!;

    public DateTime StartedAt { get; set; }
    public DateTime ExpiresAt { get; set; }

    /// <summary>True if the Teacher stopped it before ExpiresAt was reached.</summary>
    public bool EndedEarly { get; set; }
}
