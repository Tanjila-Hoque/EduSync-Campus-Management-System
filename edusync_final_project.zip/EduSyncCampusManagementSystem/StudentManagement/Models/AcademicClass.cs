namespace StudentManagement.Models;

/// <summary>A teachable course/section owned by one Teacher. Students are explicitly enrolled.</summary>
public class AcademicClass
{
    public int Id { get; set; }
    public string CourseName { get; set; } = "";
    public string Section { get; set; } = "";
    public string Department { get; set; } = "";
    public string Room { get; set; } = "";
    public int TeacherId { get; set; }
    public User Teacher { get; set; } = null!;
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
