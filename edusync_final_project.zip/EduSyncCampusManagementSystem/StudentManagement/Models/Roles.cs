namespace StudentManagement.Models;

public static class Roles
{
    public const string Admin = "Admin";
    public const string Teacher = "Teacher";
    public const string Staff = "Staff";
    public const string Student = "Student";

    public static readonly string[] All = { Admin, Teacher, Staff, Student };
}

/// <summary>Names of the custom authorization policies (registered in Program.cs).</summary>
public static class Policies
{
    public const string AdminOnly = "AdminOnly";
    public const string StaffOrAdmin = "StaffOrAdmin";
    public const string TeacherStaffAdmin = "TeacherStaffAdmin";

    /// <summary>Admin manages everyone; Teacher may view/enter marks only for Students.
    /// Staff is deliberately NOT included - staff cannot see Teacher/Student personal
    /// details or results (see PeopleController / ResultsController).</summary>
    public const string TeacherOrAdmin = "TeacherOrAdmin";
}
