namespace StudentManagement.Models;

public class AttendanceRecord
{
    public int Id { get; set; }

    public int UserId { get; set; }
    public User User { get; set; } = null!;

    public DateOnly Date { get; set; }

    /// <summary>Null for the once-a-day Teacher/Staff gate check-in; set for class attendance.</summary>
    public int? ClassId { get; set; }
    public AcademicClass? Class { get; set; }
    public DateTime CheckInTime { get; set; }

    /// <summary>Who scanned the QR (teacher / staff / admin).</summary>
    public int MarkedByUserId { get; set; }

    /// <summary>True when this record wasn't created by a QR scan but by a Teacher/Admin
    /// correcting a wrongly-marked Absent (e.g. the QR scan failed). Required whenever
    /// IsCorrected is true - kept for the Audit Log / report to explain the entry.</summary>
    public bool IsCorrected { get; set; }
    public string? CorrectionReason { get; set; }
}
