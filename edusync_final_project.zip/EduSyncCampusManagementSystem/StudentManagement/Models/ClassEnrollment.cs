namespace StudentManagement.Models;

/// <summary>Connects a Student to one AcademicClass. A student may be enrolled in many classes.</summary>
public class ClassEnrollment
{
    public int Id { get; set; }
    public int ClassId { get; set; }
    public AcademicClass Class { get; set; } = null!;
    public int StudentId { get; set; }
    public User Student { get; set; } = null!;
    public DateTime EnrolledAt { get; set; } = DateTime.UtcNow;
}
