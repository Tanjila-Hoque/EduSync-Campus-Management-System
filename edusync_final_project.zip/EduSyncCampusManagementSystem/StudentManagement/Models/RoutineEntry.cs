namespace StudentManagement.Models;

public class RoutineEntry
{
    public int Id { get; set; }

    /// <summary>Sunday..Saturday.</summary>
    public string Day { get; set; } = "";
    public string StartTime { get; set; } = ""; // "10:00"
    public string EndTime { get; set; } = "";   // "11:00"

    public string CourseName { get; set; } = "";
    public string Room { get; set; } = "";
    public string Department { get; set; } = "";

    public int? TeacherId { get; set; }
    public User? Teacher { get; set; }
}
