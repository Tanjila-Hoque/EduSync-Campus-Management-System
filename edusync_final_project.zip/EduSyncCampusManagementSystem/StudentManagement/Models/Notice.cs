namespace StudentManagement.Models;

public class Notice
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string Body { get; set; } = "";

    /// <summary>Role-wide audience for Admin notices. Teacher notices use TargetClassId.</summary>
    public string? AudienceRole { get; set; }

    /// <summary>When set by a Teacher, only enrolled students in this class can see the notice.</summary>
    public int? TargetClassId { get; set; }
    public AcademicClass? TargetClass { get; set; }

    public int CreatedByUserId { get; set; }
    public User CreatedBy { get; set; } = null!;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
