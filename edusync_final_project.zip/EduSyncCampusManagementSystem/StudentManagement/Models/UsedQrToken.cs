namespace StudentManagement.Models;

/// <summary>Records a student's personal rotating-QR code the instant it's successfully
/// scanned, keyed by (UserId, Bucket) where Bucket is the 30-second time window the code
/// was valid for. Once recorded, that exact code can never be accepted again - even if
/// it's screenshotted and re-shown before its 30 seconds are up, or scanned twice by
/// mistake, it only counts once.</summary>
public class UsedQrToken
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public long Bucket { get; set; }
    public DateTime UsedAt { get; set; }
}
