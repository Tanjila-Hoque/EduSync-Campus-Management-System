using System.ComponentModel.DataAnnotations;

namespace StudentManagement.Models;

/// <summary>
/// One table for every person in the system. Role decides what they can do.
/// (Admin / Teacher / Staff / Student)
/// </summary>
public class User
{
    public int Id { get; set; }

    [Required, StringLength(100)]
    public string FullName { get; set; } = "";

    [Required, StringLength(50)]
    public string Username { get; set; } = "";

    public string? Email { get; set; }
    public string? Phone { get; set; }

    [Required]
    public string PasswordHash { get; set; } = "";

    [Required]
    public string Role { get; set; } = Roles.Student;

    /// <summary>Roll number for students, employee id for teachers/staff.</summary>
    public string? IdNumber { get; set; }
    public string? Department { get; set; }
    public string? PhotoPath { get; set; }

    /// <summary>Random secret that goes inside the QR code. Can be regenerated if an ID card is lost.</summary>
    [Required]
    public string QrToken { get; set; } = Guid.NewGuid().ToString("N");

    public bool IsActive { get; set; } = true;

    // Login protection
    public int FailedLoginCount { get; set; }
    public DateTime? LockoutEnd { get; set; }

    // Refresh token (custom, no ASP.NET Identity) - lets the React app silently renew
    // its access token without asking the user to log in again every hour.
    public string? RefreshToken { get; set; }
    public DateTime? RefreshTokenExpiresAt { get; set; }

    // Admin-assisted password recovery. The plaintext code is never stored.
    public string? PasswordResetCodeHash { get; set; }
    public DateTime? PasswordResetCodeExpiresAt { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
