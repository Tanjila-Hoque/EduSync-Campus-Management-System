$ErrorActionPreference = "Stop"
$project = Get-ChildItem -Path $PSScriptRoot -Filter "*.csproj" | Select-Object -First 1
if (-not $project) { throw "Could not find StudentManagement.csproj in $PSScriptRoot" }
$projectXml = Get-Content -Raw $project.FullName
if ($projectXml -notmatch '<UserSecretsId>([^<]+)</UserSecretsId>') {
    throw "StudentManagement.csproj must define UserSecretsId."
}
$id = $Matches[1]
$secretDir = Join-Path $env:APPDATA ("Microsoft\UserSecrets\" + $id)
New-Item -ItemType Directory -Force -Path $secretDir | Out-Null
$secretFile = Join-Path $secretDir "secrets.json"
if (Test-Path $secretFile) {
    $json = Get-Content -Raw $secretFile
    if ([string]::IsNullOrWhiteSpace($json)) { $settings = [pscustomobject]@{} } else { $settings = ConvertFrom-Json $json }
} else { $settings = [pscustomobject]@{} }
$property = $settings.PSObject.Properties["Gemini"]
if ($null -eq $property -or $null -eq $property.Value) {
    $settings | Add-Member -MemberType NoteProperty -Name Gemini -Value ([pscustomobject]@{})
}
$gemini = $settings.Gemini
$secure = Read-Host "Gemini API key (hidden; leave blank to keep existing key)" -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try { $key = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
if (-not [string]::IsNullOrWhiteSpace($key)) {
    $p = $gemini.PSObject.Properties["ApiKey"]
    if ($null -eq $p) { $gemini | Add-Member -MemberType NoteProperty -Name ApiKey -Value $key }
    else { $gemini.ApiKey = $key }
}
$p = $gemini.PSObject.Properties["Model"]
if ($null -eq $p -or [string]::IsNullOrWhiteSpace([string]$gemini.Model)) {
    if ($null -eq $p) { $gemini | Add-Member -MemberType NoteProperty -Name Model -Value "gemini-3.5-flash-lite" }
    else { $gemini.Model = "gemini-3.5-flash-lite" }
}
[System.IO.File]::WriteAllText($secretFile, (ConvertTo-Json -InputObject $settings -Depth 20), ([System.Text.UTF8Encoding]::new($false)))
$key = $null
Write-Host "Gemini configuration saved to .NET User Secrets. No API key was printed." -ForegroundColor Green
Write-Host "Restart the backend to apply it."
