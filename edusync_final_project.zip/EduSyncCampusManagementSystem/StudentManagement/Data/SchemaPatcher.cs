using System.Data;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace StudentManagement.Data;

/// <summary>
/// WHY THIS EXISTS (root cause of Audit Log / Notices / Attendance sessions failing):
/// Database.EnsureCreated() only builds tables when the database is EMPTY. If
/// "student_management" was created by an older build of this project, tables added later
/// (AttendanceSessions, UsedQrTokens, AuditLogs, Notices, ...) were never created, so every
/// endpoint touching them returned HTTP 500 - e.g. a notice got saved and then the audit
/// write blew up, or the Audit Log page could not load at all.
///
/// This runs on startup, asks EF for the full CREATE script of the current model and runs it
/// statement by statement, silently skipping whatever already exists. It is idempotent and
/// never drops or alters existing data. (For a real production system, move to EF migrations.)
/// </summary>
public static class SchemaPatcher
{
    public static void Apply(AppDbContext db, ILogger logger)
    {
        var conn = db.Database.GetDbConnection();
        if (conn.State != ConnectionState.Open) conn.Open();

        // Legacy columns must exist before EF's generated script tries to create
        // foreign keys/indexes that reference them.
        var columnPatches = new[]
        {
            "ALTER TABLE \"Attendance\" ADD COLUMN IF NOT EXISTS \"IsCorrected\" boolean NOT NULL DEFAULT FALSE",
            "ALTER TABLE \"Attendance\" ADD COLUMN IF NOT EXISTS \"CorrectionReason\" text NULL",
            "ALTER TABLE \"Attendance\" ADD COLUMN IF NOT EXISTS \"MarkedByUserId\" integer NOT NULL DEFAULT 0",
            "ALTER TABLE \"Attendance\" ADD COLUMN IF NOT EXISTS \"ClassId\" integer NULL",
            "ALTER TABLE \"AttendanceSessions\" ADD COLUMN IF NOT EXISTS \"ClassId\" integer NULL",
            "ALTER TABLE \"Users\" ADD COLUMN IF NOT EXISTS \"FailedLoginCount\" integer NOT NULL DEFAULT 0",
            "ALTER TABLE \"Users\" ADD COLUMN IF NOT EXISTS \"LockoutEnd\" timestamp with time zone NULL",
            "ALTER TABLE \"Users\" ADD COLUMN IF NOT EXISTS \"RefreshToken\" text NULL",
            "ALTER TABLE \"Users\" ADD COLUMN IF NOT EXISTS \"RefreshTokenExpiresAt\" timestamp with time zone NULL",
            "ALTER TABLE \"Users\" ADD COLUMN IF NOT EXISTS \"PasswordResetCodeHash\" text NULL",
            "ALTER TABLE \"Users\" ADD COLUMN IF NOT EXISTS \"PasswordResetCodeExpiresAt\" timestamp with time zone NULL",
            "ALTER TABLE \"Notices\" ADD COLUMN IF NOT EXISTS \"TargetClassId\" integer NULL",
        };
        foreach (var patch in columnPatches) RunQuietly(conn, patch, logger);

        // Older versions allowed only one attendance record per person/day.
        // Remove that legacy unique index so one student can attend many classes on the same day.
        RunQuietly(conn, "DROP INDEX IF EXISTS \"IX_Attendance_UserId_Date\"", logger);

        var script = db.Database.GenerateCreateScript();
        var statements = Regex.Split(script, @";\s*\r?\n")
            .Select(s => s.Trim().TrimEnd(';').Trim())
            .Where(s => s.Length > 0);

        var created = 0;
        foreach (var statement in statements)
        {
            if (RunQuietly(conn, statement, logger)) created++;
        }

        // Older builds left other unique indexes on Attendance (e.g. "one record per person per day",
        // with or without a filter). Any of them blocks a student from attending a 2nd class on the
        // same day (or even a 1st one) and the scan then fails with "already recorded". Drop every
        // unique index on Attendance except the primary key and the two we actually want.
        RunQuietly(conn, @"DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT indexname FROM pg_indexes
    WHERE schemaname = current_schema()
      AND tablename = 'Attendance'
      AND indexdef ILIKE 'CREATE UNIQUE INDEX%'
      AND indexname NOT LIKE 'PK%'
      AND indexname NOT IN ('IX_Attendance_UserId_ClassId_Date', 'UX_Attendance_Gate_Daily')
  LOOP
    EXECUTE format('DROP INDEX %I', r.indexname);
  END LOOP;
END $$;", logger);

        RunQuietly(conn, "CREATE UNIQUE INDEX IF NOT EXISTS \"UX_Attendance_Gate_Daily\" ON \"Attendance\" (\"UserId\", \"Date\") WHERE \"ClassId\" IS NULL", logger);

        // Re-create the class attendance uniqueness explicitly after the legacy index is gone.
        RunQuietly(conn, "CREATE UNIQUE INDEX IF NOT EXISTS \"IX_Attendance_UserId_ClassId_Date\" ON \"Attendance\" (\"UserId\", \"ClassId\", \"Date\")", logger);

        // Existing tables need these new foreign keys added explicitly because EnsureCreated
        // does not alter an already-existing table. DO blocks make the operation idempotent.
        RunQuietly(conn, "DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'FK_Attendance_AcademicClasses_ClassId') THEN ALTER TABLE \"Attendance\" ADD CONSTRAINT \"FK_Attendance_AcademicClasses_ClassId\" FOREIGN KEY (\"ClassId\") REFERENCES \"AcademicClasses\" (\"Id\") ON DELETE SET NULL; END IF; END $$;", logger);
        RunQuietly(conn, "DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'FK_AttendanceSessions_AcademicClasses_ClassId') THEN ALTER TABLE \"AttendanceSessions\" ADD CONSTRAINT \"FK_AttendanceSessions_AcademicClasses_ClassId\" FOREIGN KEY (\"ClassId\") REFERENCES \"AcademicClasses\" (\"Id\") ON DELETE RESTRICT; END IF; END $$;", logger);
        RunQuietly(conn, "DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'FK_Notices_AcademicClasses_TargetClassId') THEN ALTER TABLE \"Notices\" ADD CONSTRAINT \"FK_Notices_AcademicClasses_TargetClassId\" FOREIGN KEY (\"TargetClassId\") REFERENCES \"AcademicClasses\" (\"Id\") ON DELETE SET NULL; END IF; END $$;", logger);

        if (created > 0)
            logger.LogWarning("SchemaPatcher: created {Count} missing database object(s) (tables/indexes).", created);
    }

    private static bool RunQuietly(System.Data.Common.DbConnection conn, string sql, ILogger logger)
    {
        try
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            cmd.ExecuteNonQuery();
            return true;
        }
        catch (PostgresException ex) when (ex.SqlState is "42P07" or "42710" or "42701" or "42P01")
        {
            return false; // already exists - exactly what we expect on a healthy database
        }
        catch (PostgresException ex)
        {
            logger.LogWarning("SchemaPatcher skipped a statement ({State}): {Message}", ex.SqlState, ex.MessageText);
            return false;
        }
    }
}
