using Microsoft.EntityFrameworkCore;
using StudentManagement.Models;

namespace StudentManagement.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<AttendanceRecord> Attendance => Set<AttendanceRecord>();
    public DbSet<AcademicClass> AcademicClasses => Set<AcademicClass>();
    public DbSet<ClassEnrollment> ClassEnrollments => Set<ClassEnrollment>();
    public DbSet<Notice> Notices => Set<Notice>();
    public DbSet<RoutineEntry> RoutineEntries => Set<RoutineEntry>();
    public DbSet<ResultEntry> ResultEntries => Set<ResultEntry>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<AttendanceSession> AttendanceSessions => Set<AttendanceSession>();
    public DbSet<UsedQrToken> UsedQrTokens => Set<UsedQrToken>();
    public DbSet<InAppNotification> Notifications => Set<InAppNotification>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<InAppNotification>().HasIndex(n => new { n.UserId, n.ReadAt, n.CreatedAt });
        b.Entity<InAppNotification>().HasOne(n => n.User).WithMany().HasForeignKey(n => n.UserId).OnDelete(DeleteBehavior.Cascade);

        b.Entity<User>().HasIndex(u => u.Username).IsUnique();
        b.Entity<User>().HasIndex(u => u.QrToken).IsUnique();
        b.Entity<User>().HasIndex(u => u.IdNumber).IsUnique();

        // Class attendance is unique per student + class + day. Gate check-ins have ClassId=null
        // and are guarded separately in the controller so Teachers/Staff can still check in only once.
        b.Entity<AttendanceRecord>().HasIndex(a => new { a.UserId, a.ClassId, a.Date }).IsUnique();
        // Teacher/Staff gate check-in (ClassId is null): one per person per day, enforced by the database too.
        b.Entity<AttendanceRecord>()
            .HasIndex(a => new { a.UserId, a.Date })
            .IsUnique()
            .HasFilter("\"ClassId\" IS NULL")
            .HasDatabaseName("UX_Attendance_Gate_Daily");
        b.Entity<AttendanceRecord>()
            .HasOne(a => a.Class)
            .WithMany()
            .HasForeignKey(a => a.ClassId)
            .OnDelete(DeleteBehavior.SetNull);
        b.Entity<AttendanceRecord>()
            .HasOne(a => a.User)
            .WithMany()
            .HasForeignKey(a => a.UserId)
            .OnDelete(DeleteBehavior.Cascade);

        b.Entity<Notice>()
            .HasOne(n => n.CreatedBy)
            .WithMany()
            .HasForeignKey(n => n.CreatedByUserId)
            .OnDelete(DeleteBehavior.Restrict);

        b.Entity<Notice>()
            .HasOne(n => n.TargetClass)
            .WithMany()
            .HasForeignKey(n => n.TargetClassId)
            .OnDelete(DeleteBehavior.SetNull);

        b.Entity<RoutineEntry>()
            .HasOne(r => r.Teacher)
            .WithMany()
            .HasForeignKey(r => r.TeacherId)
            .OnDelete(DeleteBehavior.SetNull);

        b.Entity<ResultEntry>()
            .HasOne(r => r.Student)
            .WithMany()
            .HasForeignKey(r => r.StudentId)
            .OnDelete(DeleteBehavior.Cascade);

        b.Entity<ResultEntry>().Ignore(r => r.Total).Ignore(r => r.Grade);


        b.Entity<AcademicClass>()
            .HasOne(c => c.Teacher)
            .WithMany()
            .HasForeignKey(c => c.TeacherId)
            .OnDelete(DeleteBehavior.Restrict);
        b.Entity<AcademicClass>().HasIndex(c => new { c.CourseName, c.Section, c.TeacherId }).IsUnique();

        b.Entity<ClassEnrollment>()
            .HasOne(e => e.Class)
            .WithMany()
            .HasForeignKey(e => e.ClassId)
            .OnDelete(DeleteBehavior.Cascade);
        b.Entity<ClassEnrollment>()
            .HasOne(e => e.Student)
            .WithMany()
            .HasForeignKey(e => e.StudentId)
            .OnDelete(DeleteBehavior.Cascade);
        b.Entity<ClassEnrollment>().HasIndex(e => new { e.ClassId, e.StudentId }).IsUnique();

        b.Entity<AttendanceSession>()
            .HasOne(s => s.Class)
            .WithMany()
            .HasForeignKey(s => s.ClassId)
            .OnDelete(DeleteBehavior.Restrict);

        b.Entity<AttendanceSession>()
            .HasOne(s => s.Teacher)
            .WithMany()
            .HasForeignKey(s => s.TeacherId)
            .OnDelete(DeleteBehavior.Cascade);

        // A given student's code for a given 30-second window can only ever be consumed once.
        b.Entity<UsedQrToken>().HasIndex(t => new { t.UserId, t.Bucket }).IsUnique();
    }
}

