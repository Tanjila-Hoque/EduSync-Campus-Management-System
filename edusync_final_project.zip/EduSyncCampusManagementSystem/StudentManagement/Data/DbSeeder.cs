using StudentManagement.Models;
using StudentManagement.Services;
using Microsoft.EntityFrameworkCore;

namespace StudentManagement.Data;

public static class DbSeeder
{
    public static void Seed(AppDbContext db)
    {
        // Keep this idempotent so an existing student_management database gets the new
        // demo teachers/classes without losing any user data.
        var admin = EnsureUser(db, "System Admin", "admin", "Admin@123", Roles.Admin, "ADM-001", "Administration");
        var teachers = new[]
        {
            ("Dr. Arif Rahman", "teacher1", "TCH-001", "Computer Science"),
            ("Nusrat Jahan", "teacher2", "TCH-002", "Computer Science"),
            ("Tanvir Ahmed", "teacher3", "TCH-003", "Computer Science"),
            ("Farhana Islam", "teacher4", "TCH-004", "Business Administration"),
            ("Saiful Hasan", "teacher5", "TCH-005", "Electrical Engineering"),
            ("Sadia Karim", "teacher6", "TCH-006", "English"),
        };
        var teacherUsers = teachers.Select(t => EnsureUser(db, t.Item1, t.Item2, "Pass@1234", Roles.Teacher, t.Item3, t.Item4)).ToList();

        EnsureUser(db, "Campus Office Staff", "staff1", "Pass@1234", Roles.Staff, "STF-001", "Office");
        EnsureUser(db, "Student Services Staff", "staff2", "Pass@1234", Roles.Staff, "STF-002", "Student Services");
        var demoStudent = EnsureUser(db, "Demo Student", "student1", "Pass@1234", Roles.Student, "STD-001", "Computer Science");
        db.SaveChanges();

        if (!db.Notices.Any())
        {
            db.Notices.Add(new Notice
            {
                Title = "Welcome to the new semester",
                Body = "Check your class routine and attend each class through the Teacher's live QR session.",
                AudienceRole = null,
                CreatedByUserId = admin.Id
            });
        }

        // Six demo classes. A student can be enrolled in all six, and attendance is then
        // unique per class/day rather than one record for the whole day.
        var classSeeds = new[]
        {
            ("CSE-3201", "A", "Computer Science", "301", teacherUsers[0].Id),
            ("CSE-3202", "A", "Computer Science", "205", teacherUsers[1].Id),
            ("CSE-3203", "B", "Computer Science", "402", teacherUsers[2].Id),
            ("BBA-2101", "A", "Business Administration", "401", teacherUsers[3].Id),
            ("EEE-2201", "A", "Electrical Engineering", "Lab-2", teacherUsers[4].Id),
            ("ENG-1101", "B", "English", "103", teacherUsers[5].Id),
        };

        foreach (var seed in classSeeds)
        {
            var c = db.AcademicClasses.FirstOrDefault(x => x.CourseName == seed.Item1 && x.Section == seed.Item2 && x.TeacherId == seed.Item5);
            if (c == null)
            {
                c = new AcademicClass
                {
                    CourseName = seed.Item1, Section = seed.Item2, Department = seed.Item3,
                    Room = seed.Item4, TeacherId = seed.Item5, IsActive = true
                };
                db.AcademicClasses.Add(c);
                db.SaveChanges();
            }
            if (!db.ClassEnrollments.Any(e => e.ClassId == c.Id && e.StudentId == demoStudent.Id))
                db.ClassEnrollments.Add(new ClassEnrollment { ClassId = c.Id, StudentId = demoStudent.Id });
        }

        // Keep the original demo routine/results useful, but add teacher-owned classes to the routine.
        if (!db.RoutineEntries.Any())
        {
            db.RoutineEntries.AddRange(
                new RoutineEntry { Day = "Sunday", StartTime = "10:00", EndTime = "11:00", CourseName = "CSE-3201", Room = "301", Department = "Computer Science", TeacherId = teacherUsers[0].Id },
                new RoutineEntry { Day = "Monday", StartTime = "11:00", EndTime = "12:00", CourseName = "CSE-3202", Room = "205", Department = "Computer Science", TeacherId = teacherUsers[1].Id },
                new RoutineEntry { Day = "Tuesday", StartTime = "09:00", EndTime = "10:00", CourseName = "CSE-3203", Room = "402", Department = "Computer Science", TeacherId = teacherUsers[2].Id },
                new RoutineEntry { Day = "Wednesday", StartTime = "10:00", EndTime = "11:00", CourseName = "BBA-2101", Room = "401", Department = "Business Administration", TeacherId = teacherUsers[3].Id },
                new RoutineEntry { Day = "Thursday", StartTime = "11:00", EndTime = "12:00", CourseName = "EEE-2201", Room = "Lab-2", Department = "Electrical Engineering", TeacherId = teacherUsers[4].Id },
                new RoutineEntry { Day = "Saturday", StartTime = "12:00", EndTime = "13:00", CourseName = "ENG-1101", Room = "103", Department = "English", TeacherId = teacherUsers[5].Id }
            );
        }

        if (!db.ResultEntries.Any())
        {
            db.ResultEntries.Add(new ResultEntry
            {
                StudentId = demoStudent.Id, CourseName = "CSE-3201", Mid = 25, Final = 45, Assignment = 18,
                EnteredByUserId = teacherUsers[0].Id
            });
        }

        if (!db.AuditLogs.Any())
        {
            db.AuditLogs.Add(new AuditLog
            {
                ActorUserId = admin.Id, ActorName = admin.FullName, ActorRole = admin.Role,
                Action = "System.Seed", Details = "Initial demo data and academic classes created"
            });
        }

        db.SaveChanges();
    }

    private static User EnsureUser(AppDbContext db, string name, string username, string password, string role, string idNo, string dept)
    {
        var user = db.Users.FirstOrDefault(u => u.Username == username);
        if (user == null)
        {
            user = Make(name, username, password, role, idNo, dept);
            db.Users.Add(user);
            db.SaveChanges();
        }
        else
        {
            // These are demo accounts; keep the requested role/name/credentials stable.
            user.FullName = name;
            user.Role = role;
            user.IdNumber = idNo;
            user.Department = dept;
            user.IsActive = true;
            user.PasswordHash = PasswordHasher.Hash(password);
            db.SaveChanges();
        }
        return user;
    }

    private static User Make(string name, string username, string password, string role, string idNo, string dept) => new()
    {
        FullName = name,
        Username = username,
        PasswordHash = PasswordHasher.Hash(password),
        Role = role,
        IdNumber = idNo,
        Department = dept,
        IsActive = true
    };
}
