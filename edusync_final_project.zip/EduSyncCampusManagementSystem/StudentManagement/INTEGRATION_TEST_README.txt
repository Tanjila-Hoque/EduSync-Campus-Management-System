EDUSYNC EMAIL + GEMINI TEST (LOCAL ONLY)

1) Save credentials with SETUP_LOCAL_SECRETS.ps1. Do not put credentials in appsettings.json or any ZIP/Git repository.
2) From the StudentManagement folder run:
   powershell -NoProfile -ExecutionPolicy Bypass -File ".\TEST_EMAIL_GEMINI.ps1"
3) The test reads your local .NET User Secrets, makes one Gemini request, and sends one test email to Email:From. It never prints secret values.
4) If you pasted a real API key or Gmail App Password into a chat, document, screenshot, or repository, revoke it and create a replacement before testing.
5) After diagnostics, run `dotnet run`, then run the Vite frontend with `npm run dev` in a separate terminal. Sign into the app to test the authenticated AI and Test Email UI.

Current recommended model: gemini-3.8-flash. If your API key has no access to that model, check the official model list in Google AI Studio and choose a model the key is permitted to call.
