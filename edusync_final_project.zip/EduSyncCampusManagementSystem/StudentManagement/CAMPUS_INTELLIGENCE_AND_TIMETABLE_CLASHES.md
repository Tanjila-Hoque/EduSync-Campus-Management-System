# Added Next-Level Features

This update adds two independent features without adding database tables or deleting existing data.

## 1. Smart Timetable Clash Detector

- Admins see a clash report on **Routine**.
- Detects overlapping sessions that share an assigned teacher and/or the same non-empty room.
- Adjacent intervals (for example 10:00-11:00 and 11:00-12:00) are not considered conflicts.
- New routine entries must use valid 24-hour time values and end after start.
- The API rejects a new entry with HTTP 409 if it conflicts with an existing teacher/room allocation.
- Existing conflicts are reported by `GET /api/routine/conflicts`; only Admin can use this endpoint.
- Uses the existing `RoutineEntries` data. No schema changes or migration are required.

## 2. Campus Intelligence Dashboard

- New Admin-only page: **Overview → Campus Intelligence**.
- Backend endpoint: `GET /api/campus-intelligence/overview`.
- Metrics include user/student/teacher counts, active classes/enrollments, today's class-attendance records, result count and average coursework marks, notices, unread in-app notifications, and scheduled sessions.
- Charts show actual daily class-attendance record counts and result-entry counts for the latest 14 campus calendar days.
- Department distribution and recent audit activity use existing PostgreSQL records.
- Uses existing database entities; no schema changes or migration are required.

## How to run

Backend, from `StudentManagement`:

```cmd
dotnet restore
dotnet run
```

Frontend, from `StudentManagement\ClientApp`:

```cmd
npm install
npm run dev
```

Both new endpoints require the existing JWT authentication. Campus Intelligence and the timetable clash report are Admin-only. Metrics are live aggregates; the dashboard does not fabricate sample values.

## Validation notes

This environment did not provide the .NET SDK, so the ASP.NET Core build could not be executed here. Please run `dotnet build` on the project machine, along with `npm run build` for the frontend. The API calculations and UI wiring were reviewed from source, but live database behavior still needs to be verified in the local environment. The frontend JSX/JavaScript syntax was parsed successfully; the npm build could not be run here because package downloads failed with a registry DNS (`EAI_AGAIN`) error.
