# ECMS — EduSync Campus Management System

A professional academic operations platform for **Students, Teachers, Staff and Admins**, built with ASP.NET Core 8, PostgreSQL and React/Vite.

## Core workflow

- **Students can self-sign up.** Public signup always creates a Student account.
- **Teacher and Staff accounts are not public-signup accounts.** Admin creates them from **People → Add Teacher / Add Staff**.
- **Admin manages classes** from **Classes**: each class has one Teacher and an explicit student roster.
- A Student may be enrolled in **many classes**. Attendance is therefore stored per **Student + Class + Date**, so the same student can attend 5–6 classes on the same day.
- When a Teacher starts a class session, the system shows a **class-specific QR**. Only students enrolled in that exact class can scan it.
- Teachers see only the **students enrolled in their selected class** in the attendance report; the system does not dump every student into a teacher's session.
- Teachers and Staff have a separate **once-a-day gate QR** for their own attendance. Students do not use the gate QR.
- Admin can add/deactivate/delete accounts, create classes, assign students to classes, and review audit logs.

## Demo accounts

### Admin
- Username: `admin`
- Password: `Admin@123`

### Teachers (all use `Pass@1234`)
- `teacher1` — Dr. Arif Rahman
- `teacher2` — Nusrat Jahan
- `teacher3` — Tanvir Ahmed
- `teacher4` — Farhana Islam
- `teacher5` — Saiful Hasan
- `teacher6` — Sadia Karim

### Staff (all use `Pass@1234`)
- `staff1` — Campus Office Staff
- `staff2` — Student Services Staff

### Demo Student
- `student1` — Demo Student
- Password: `Pass@1234`

The seeder is idempotent: an existing `student_management` database is kept and the demo teacher/staff/class data is added if missing.

## Attendance behavior

### Student class attendance
1. Admin assigns the student to one or more classes.
2. Teacher opens **Attendance → Open a QR attendance session**, selects their own class, and chooses any custom duration from 1–180 minutes.
3. Teacher starts the QR session.
4. Students in that class scan the Teacher's QR from their own phone.
5. The API rejects students who are not enrolled in that class.
6. The same student can later scan another Teacher's class QR on the same day because each attendance record belongs to a different class.

### Teacher / Staff daily attendance
- Admin displays/prints the daily gate QR.
- Each Teacher/Staff account scans it **once per day**.
- This daily check-in is separate from class attendance.

## Roles

| Feature | Admin | Teacher | Staff | Student |
|---|---:|---:|---:|---:|
| Public self-signup | ❌ | ❌ | ❌ | ✅ |
| Add Teacher/Staff accounts | ✅ | ❌ | ❌ | ❌ |
| Create/manage classes | ✅ | ❌ | ❌ | ❌ |
| Assign students to classes | ✅ | ❌ | ❌ | ❌ |
| View own teaching classes | — | ✅ | ❌ | — |
| Class attendance session | ✅ | ✅ | ❌ | Scan only |
| Daily gate check-in | ❌ | ✅ | ✅ | ❌ |
| Audit log | ✅ | ❌ | ❌ | ❌ |

## Development

### Backend

```cmd
cd /d E:\ECMS\StudentManagement
dotnet restore
dotnet run
```

The API normally listens on `http://localhost:5100`. Use `SETUP_LOCAL_SECRETS.ps1` to configure the Gemini API key in .NET User Secrets; SMTP/email delivery has been removed. Never save real secrets in `appsettings*.json`.

### Frontend

Open a second terminal:

```cmd
cd /d E:\ECMS\StudentManagement\ClientApp
npm install
npm run dev
```

Vite normally serves the app at `https://localhost:5173/`.

## PostgreSQL

Set the connection string in `appsettings.json` to the local PostgreSQL instance. Example:

```json
"Default": "Host=localhost;Port=1234;Database=student_management;Username=postgres;Password=1234"
```

## Student Success Radar and Smart Notifications

- `/api/student-success/radar` reads current PostgreSQL attendance sessions, attendance records, enrollments and result records. It returns explainable attendance/academic risk signals; students see only their own data, teachers see students enrolled in their taught classes, and Admins see all active students.
- `/api/student-success/notify` (Teacher/Admin) creates deduplicated daily in-app support alerts for students whose recorded attendance is below 75% or whose available coursework average is below 40%.
- `/api/notifications?page=1&pageSize=10` returns the signed-in user's notifications, unread count and pagination. `POST /api/notifications/{id}/read` and `POST /api/notifications/read-all` mark notifications read.
- Students receive a Gemini-generated 7-day study plan based on their own real measured data. If Gemini is unavailable, a transparent rule-based fallback is shown. The dashboard keeps existing features and adds the Student Success Radar and notification center.

Configure `Gemini:ApiKey` via the setup script. The model defaults to `gemini-3.5-flash-lite`. Risk scores are explainable rules, not a diagnosis; missing data is explicitly identified. SchemaPatcher creates the notification table without dropping existing records.

## Main API groups

- `/api/auth` — login, student registration, refresh, logout
- `/api/people` — account management and person records
- `/api/classes` — classes and student enrollment
- `/api/attendance` — daily gate check-in, class sessions, QR attendance and class reports
- `/api/results` — results
- `/api/routine` — routine
- `/api/notices` — notices
- `/api/audit-logs` — Admin audit trail
- `/api/dashboard/summary` — dashboard summary
- `/api/student-success/radar` — explainable student support signals
- `/api/notifications` — in-app notification center

## Important database change

Older builds used one attendance row per person/day. ECMS changes this to **one row per person + class + day** for class attendance, while Teacher/Staff gate check-ins remain one per day. `SchemaPatcher` removes the old unique index and creates the new class-aware index without dropping existing data.

## Latest fixes (attendance)

- **Students join their own classes**: Attendance page → *My classes* (`GET /api/classes/browse`,
  `POST/DELETE /api/classes/{id}/join`). A Teacher's attendance list contains exactly the students who
  joined that class, so new sign-ups no longer sit outside every Teacher's list.
- **Teacher's live list** refreshes every 3 seconds while a session is open and shows *x present / y students*.
- **Admin: Teacher & Staff attendance** (`GET /api/attendance/staff-report`, `POST /api/attendance/correct-daily`):
  see who scanned today's gate QR, and mark someone present by hand with a reason (audited).
- **Database**: `SchemaPatcher` now removes leftover unique indexes on `Attendance` from older builds that
  blocked a 2nd class per day, and adds a one-gate-check-in-per-day index for Teachers/Staff.

## Attendance QR codes (one per day) + Attendance Health

- **One QR per day, valid only on that day** (Bangladesh time, decided by the server). Teachers/Staff scan the
  check-in QR once a day; students scan their class QR while that class's Teacher has attendance open.
- Codes: `EDUSYNC-GATE-yyyyMMdd-<sig>` and `CLASS:<COURSE><SECTION>:yyyyMMdd:<sig>` (e.g. `CLASS:CSE3201A:20261004:...`).
  The signature comes from `Attendance:CheckInSecret` (appsettings.json) + the date. A class is identified by its
  course + section, so QR pictures can be made ahead of time for any day without touching the database.
- Ready-made QR pictures for the next 90 days come as a separate zip (`EduSync-QR-Codes_...zip`). If
  `Attendance:CheckInSecret` is changed, or a class is renamed, those QRs must be regenerated.
- Admin page: today's check-in QR (full screen / print) + Teachers & Staff attendance (search, mark present with a reason, undo).
- Teacher page: pick a class and a time limit -> **Start attendance** -> live QR + live student list; later, class records by date.
- **Attendance Health** (Insights page): Students see per-class % and the 75%-rule maths; Teachers see an early-warning
  list of students below 75%, a trend, and can export CSV. API: `GET /api/analytics/my`, `GET /api/analytics/class/{id}`.


## Final requested enhancements

- **Teacher notices are class-private:** a Teacher selects one of their own classes and the announcement is visible only to students enrolled in that class.
- **Staff notice access is read-only:** Staff can read notices but cannot publish/delete them, and cannot access People/Results/Classes/Insights.
- **Custom attendance duration:** Teachers/Admins can enter any attendance window from **1–180 minutes** instead of choosing fixed 5/10/15-minute buttons.
- **Attendance marks:** Result pages now include **Attendance / 10**. The mark is calculated automatically from held sessions and the student's attendance percentage, and the total is shown out of **110**.
- **Forgot password:** Admins can generate a one-time **6-digit verification code** from People. The code expires in 15 minutes and is never stored in plaintext. The user enters the code on **Forgot password** to set a new password.
- **Remember me:** checked login sessions receive a 30-day refresh lifetime; unchecked sessions receive a shorter session lifetime while still renewing silently during the session.
- **Student privacy:** Student class/routine/attendance-health views no longer expose the Teacher name. Students also cannot open a class roster containing other students.
- **Admin account creation:** Add Teacher and Add Staff use the same simple admin-created account workflow; there is no password restriction for accounts the Admin creates or edits (any characters, any length; only empty is rejected).
- **UI refresh:** login, navigation, dashboard components, notices, forms, tables and cards use a more polished campus-management visual system.
- **Database:** PostgreSQL (Npgsql). The database backup is in the `Database` folder: `EduSyncCampusManagementSystem_DB.sql` (plain SQL: tables, indexes and demo data) and `EduSyncCampusManagementSystem_DB.backup` (pgAdmin Restore). Create a database named `student_management`, then run that file with `psql` or pgAdmin. It is optional - the app also creates and patches the tables itself on startup.


## QR attendance link behavior
- A Teacher generates a time-limited QR for their own class.
- The QR can encode the EduSync Attendance page URL, so a phone camera can open the student panel directly.
- After login, the pending QR scan is preserved and submitted automatically.
- The backend still verifies role, class enrollment, session expiry, duplicate attendance, and QR signature.
- For cross-device testing on a local network, open the Vite frontend using the PC's LAN HTTPS address (for example `https://192.168.x.x:5173`) rather than `https://localhost:5173`, because `localhost` on a student's phone points to the phone itself.

## UI redesign (v3)

Only the look of the app changed - every API call, route, role rule and form behaves exactly as before.

- New app shell: dark sidebar with grouped navigation + top bar (collapses to a drawer on phones).
- Every page redesigned for Admin, Teacher, Staff and Student; the Dashboard now shows a role-specific home
  (stats, today's schedule, latest notices, class tiles, attendance health, latest results) using endpoints that already exist.
- Login / Sign up / Forgot password share a split-screen layout. To show your own campus photo, put it at
  `ClientApp/public/campus.jpg` (it is picked up automatically; a drawn campus illustration is the fallback).
- Run `npm install && npm run dev` in `ClientApp` as before.

- Backgrounds are real campus photos from Wikimedia Commons (credit shown on screen: Matthew Rice; ajay_suresh, CC BY 2.0; Jerry Anderson, CC BY-SA 4.0; Suzanne Shaw, CC BY 2.0). Put your own photo at `ClientApp/public/campus.jpg` to use only that. Branding: `src/utils/institution.js`.

- For offline photos run `download-photos.bat` once (saves the 4 background photos into `ClientApp\public\photos`).


## Next-Level Features: Timetable Clash Detection and Campus Intelligence

### Smart Timetable Clash Detector

- Admins can review existing overlaps from **Routine → Smart Timetable Clash Detector**.
- Detects overlapping entries where the same assigned teacher or the same room is double-booked.
- The API rejects new routine entries with invalid time ranges or resource conflicts before saving them.
- Existing endpoint: `GET /api/routine/conflicts` (Admin only).
- Uses existing routine data; no database migration is required.

### Campus Intelligence Dashboard

- Admin-only page at **Overview → Campus Intelligence**.
- Shows live totals for users, students, teachers, active classes/enrollments, class-attendance records, results, notices, notifications, and routine entries.
- Includes 14-day attendance/result activity charts, student/teacher department distribution, and recent audit activity.
- Endpoint: `GET /api/campus-intelligence/overview` (Admin only).
- All metrics are calculated from existing PostgreSQL records; no mock data or schema changes are added.

See `CAMPUS_INTELLIGENCE_AND_TIMETABLE_CLASHES.md` for implementation notes.
